class ConstantIcons {
  // General
  static const String logo = "assets/icons/logo.svg";
  static const String logoWhite = "assets/icons/logo_white.svg";

  // Face & Gallery
  static const String maleButton = "assets/icons/male_button.svg";
  static const String womanButton = "assets/icons/woman_button.svg";

  // Onboarding
  static const String onboarding1 = "assets/icons/onboarding_1.svg";
  static const String onboarding2 = "assets/icons/onboarding_2.svg";
  static const String onboarding3 = "assets/icons/onboarding_3.svg";
}
