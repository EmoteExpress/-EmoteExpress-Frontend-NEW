class EndPointConstant {
  // Auth
  static const String login = "api/user/login/";
  static const String register = "api/user/register/";
  static const String forgotPassword = "api/user/forget-password/";
  static const String logout = "api/logout/";

  // Home
  static const String home = "api/user/home/";
  static const String searchEmotion = "api/user/search-emotion/";
  static const String emotionRecommendations = "api/user/recommended-emotions/";

  // Menu
  static const String detailUser = 'api/user/detail-user/';
  static const String updateDetailUser = "api/user/update-user/";
  static const String updatePrivacy = "api/user/private-profile/";

  // Posts
  static const String feed = "api/user/feed/";
  static const String posts = "api/user/emotion-user/";
  static const String toggleLikePost = "api/user/toggle-like-post/";
  static const String favoritePost = "api/user/favorite-post/";
  static const String getLikes = "api/user/like-post/";
  static const String follow = "api/user/follow/";
  static const String profileFollowers = "api/user/profile/follow/";
  static const String audios = "api/user/audios/";

  // Calendar
  static const String calendar = "api/user/calender/";
  static const String chart = "api/user/calendar-chart/";
  static const String emotionDescription = "api/user/recommendation-emotion/";
  static const String faceGallery = "api/user/face-gallery/";
  static const String imageSymbols = "api/user/symbol-images/";

  // Activity
  static const String chatbot = "api/user/chatbot/";

  // Comments
  static const String comments = "/api/user/post-comment/";
  static const String toggleLikeComment = "/api/user/toggle-like-comment/";

  // Survey
  static const String feelingsList = "api/user/feel-emotions/";
  static const String emotionsList = "api/user/list-emotions/";
  static const String quiz = "api/user/quiz-user/";
}
