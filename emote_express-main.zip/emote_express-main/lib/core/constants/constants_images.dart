class ConstantImages {
  static const String shape = "assets/images/shape.png";
  static const String imagesGroup = "assets/images/images_group.png";
  static const String surveyFinished = "assets/images/survey_finished.png";

  // Animations, gif
  static const String loadingAnimation = "assets/images/loading_animation.gif";
}
