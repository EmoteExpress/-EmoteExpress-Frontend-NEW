class ConstantApi {
  // Url Prod
  static const String urlBaseProd = "https://emoteexpress.com/prod/";
  // Url Dev
  static const String urlBaseDev = "https://emoteexpress.com/dev/";

  /// url with te current enviroment
  static String url = urlBaseDev;
}
