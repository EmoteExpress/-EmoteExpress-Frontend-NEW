import 'package:flutter/material.dart';

class ConstantColors {
  // HEX
  static const Color white = Color(0xFFFEFEFE);
  static const Color checkboxColor = Color(0xFF141418);

  static const Color cff08080D = Color(0xFF08080D);
  static const Color cff111114 = Color(0xFF111114);
  static const Color cff1F2128 = Color(0xFF1F2128);
  static const Color cff2D3441 = Color(0xFF2D3441);
  static const Color cffFFBE26 = Color(0xFFFFBE26);
  static const Color cffF6912E = Color(0xFFF6912E);
}
