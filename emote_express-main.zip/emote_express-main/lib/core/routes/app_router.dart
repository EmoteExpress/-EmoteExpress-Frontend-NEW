import 'package:emote_express/ui/ui.dart';
import 'package:flutter/material.dart';

class AppRouter {
  static Map<String, Widget Function(BuildContext)> routes = {
    '/': (BuildContext contex) => const App(),

    // On boarding
    OnBoardingView.routeName: (_) => const OnBoardingView(),
    WelcomeView.routeName: (_) => const WelcomeView(),

    // Authenticacion
    LoginView.routeName: (_) => const LoginView(),
    ForgotPasswordView.routeName: (_) => const ForgotPasswordView(),
    RegisterView.routeName: (_) => const RegisterView(),

    // Home
    HomeView.routeName: (_) => const HomeView(),
    HomeDefaultView.routeName: (_) => const HomeDefaultView(),
    RecommendationView.routeName: (_) => const RecommendationView(),
    SearchWordView.routeName: (_) => const SearchWordView(),

    // Menu
    MenuView.routeName: (_) => const MenuView(),
    EditProfileView.routeName: (_) => const EditProfileView(),

    // Posts
    FeedView.routeName: (_) => const FeedView(),
    PostView.routeName: (_) => const PostView(),
    PostsView.routeName: (_) => const PostsView(),
    CreatePostView.routeName: (_) => const CreatePostView(),
    PostLikesView.routeName: (_) => const PostLikesView(),
    FavoritePostsView.routeName: (_) => const FavoritePostsView(),
    PostCommentsView.routeName: (_) => const PostCommentsView(),
    UsersListView.routeName: (_) => const UsersListView(),
    SelectAudioView.routeName: (_) => const SelectAudioView(),

    // Brain Activity
    BrainActivityView.routeName: (_) => const BrainActivityView(),
    AssistantSearchView.routeName: (_) => const AssistantSearchView(),
    AssitantChatView.routeName: (_) => const AssitantChatView(),

    // Calendar
    CalendarView.routeName: (_) => const CalendarView(),
    EmotionDescriptionView.routeName: (_) => const EmotionDescriptionView(),
    FaceAndGalleryView.routeName: (_) => const FaceAndGalleryView(),
    ImageSymbolsView.routeName: (_) => const ImageSymbolsView(),
    SearchImageSymbolView.routeName: (_) => const SearchImageSymbolView(),
    CreateImageSymbolView.routeName: (_) => const CreateImageSymbolView(),

    // Survey
    SurveyView.routeName: (_) => const SurveyView(),
    SurveyFinishedView.routeName: (_) => const SurveyFinishedView(),
  };
}
