part of 'calendar_cubit.dart';

class CalendarState extends Equatable {
  const CalendarState({
    this.errorText = '',
    this.getCalendarStatus = WidgetStatus.initial,
    this.calendarDayList = const [],
    this.dateSelected,
    this.getChartStatus = WidgetStatus.initial,
    this.chartModel,
    this.chartFilter = 0,
    this.coordinates = const [],
    this.descriptionStatus = WidgetStatus.initial,
    this.emotionDescription,
    this.query = "",
    this.moreListStatus = WidgetStatus.initial,
    this.listEmotionsStatus = WidgetStatus.initial,
    this.listEmotions,
    this.faceGalleryStatus = WidgetStatus.initial,
    this.faceGallery,
    this.imageSymbolStatus = WidgetStatus.initial,
    this.imageSymbolList,
    this.imageSymbolSelected,
    this.photo,
  });

  // General
  final String errorText;
  final String query;
  final WidgetStatus moreListStatus;

  final DateTime? dateSelected;
  final WidgetStatus getCalendarStatus;
  final List<CalendarDayModel>? calendarDayList;

  final int chartFilter;
  final List<FlSpot> coordinates;
  final WidgetStatus getChartStatus;
  final CalendarChartResponseModel? chartModel;

  final WidgetStatus descriptionStatus;
  final EmotionDescriptionResponseModel? emotionDescription;

  // Image Symbols
  final WidgetStatus listEmotionsStatus;
  final ListEmotionsResponseModel? listEmotions;
  final WidgetStatus imageSymbolStatus;
  final ImageSymbolListResponseModel? imageSymbolList;
  final ImageSymbolModel? imageSymbolSelected;
  final File? photo;

  // Face Gallery
  final WidgetStatus faceGalleryStatus;
  final FaceGalleryResponseModel? faceGallery;

  @override
  List<Object?> get props => [
        errorText,
        moreListStatus,
        query,
        getCalendarStatus,
        calendarDayList,
        dateSelected,
        getChartStatus,
        chartModel,
        chartFilter,
        coordinates,
        descriptionStatus,
        emotionDescription,
        listEmotionsStatus,
        listEmotions,
        faceGalleryStatus,
        faceGallery,
        imageSymbolStatus,
        imageSymbolList,
        imageSymbolSelected,
        photo,
      ];

  CalendarState copyWith({
    String? errorText,
    WidgetStatus? moreListStatus,
    String? query,
    WidgetStatus? getCalendarStatus,
    Wrapped<List<CalendarDayModel>?>? calendarDayList,
    Wrapped<DateTime?>? dateSelected,
    WidgetStatus? getChartStatus,
    Wrapped<CalendarChartResponseModel?>? chartModel,
    int? chartFilter,
    List<FlSpot>? coordinates,
    WidgetStatus? descriptionStatus,
    Wrapped<EmotionDescriptionResponseModel?>? emotionDescription,
    WidgetStatus? listEmotionsStatus,
    Wrapped<ListEmotionsResponseModel?>? listEmotions,
    WidgetStatus? faceGalleryStatus,
    Wrapped<FaceGalleryResponseModel?>? faceGallery,
    WidgetStatus? imageSymbolStatus,
    Wrapped<ImageSymbolListResponseModel?>? imageSymbolList,
    Wrapped<ImageSymbolModel?>? imageSymbolSelected,
    Wrapped<File?>? photo,
  }) {
    return CalendarState(
      errorText: errorText ?? this.errorText,
      moreListStatus: moreListStatus ?? this.moreListStatus,
      query: query ?? this.query,
      getCalendarStatus: getCalendarStatus ?? this.getCalendarStatus,
      calendarDayList: (calendarDayList != null)
          ? calendarDayList.value
          : this.calendarDayList,
      dateSelected:
          (dateSelected != null) ? dateSelected.value : this.dateSelected,
      getChartStatus: getChartStatus ?? this.getChartStatus,
      chartModel: (chartModel != null) ? chartModel.value : this.chartModel,
      chartFilter: chartFilter ?? this.chartFilter,
      coordinates: coordinates ?? this.coordinates,
      descriptionStatus: descriptionStatus ?? this.descriptionStatus,
      emotionDescription: (emotionDescription != null)
          ? emotionDescription.value
          : this.emotionDescription,
      listEmotionsStatus: listEmotionsStatus ?? this.listEmotionsStatus,
      listEmotions:
          (listEmotions != null) ? listEmotions.value : this.listEmotions,
      faceGalleryStatus: faceGalleryStatus ?? this.faceGalleryStatus,
      faceGallery: (faceGallery != null) ? faceGallery.value : this.faceGallery,
      imageSymbolStatus: imageSymbolStatus ?? this.imageSymbolStatus,
      imageSymbolList: (imageSymbolList != null)
          ? imageSymbolList.value
          : this.imageSymbolList,
      imageSymbolSelected: (imageSymbolSelected != null)
          ? imageSymbolSelected.value
          : this.imageSymbolSelected,
      photo: (photo != null) ? photo.value : this.photo,
    );
  }
}
