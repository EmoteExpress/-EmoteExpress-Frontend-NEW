import 'dart:io';

import 'package:equatable/equatable.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:emote_express/utils/generic_utils.dart';
import 'package:emote_express/models/generic/wrapped.dart';
import 'package:emote_express/models/calendar/calendar.dart';
import 'package:emote_express/providers/survey_provider.dart';
import 'package:emote_express/providers/calendar_provider.dart';
import 'package:emote_express/models/generic/generic_enums.dart';
import 'package:emote_express/models/survey/list_emotions_response_model.dart';

part 'calendar_state.dart';

class CalendarCubit extends Cubit<CalendarState> {
  CalendarCubit() : super(const CalendarState());

  final _calendarProvider = CalendarProvider();
  final _surveyProvider = SurveyProvider();

  void setDate(DateTime value) =>
      emit(state.copyWith(dateSelected: Wrapped.value(value)));

  void setChartFilter(int value) => emit(state.copyWith(chartFilter: value));

  void previousMonth() {
    if (state.dateSelected == null) return;
    if (state.getCalendarStatus == WidgetStatus.loading) return;

    final desiredDate = DateTime(
      state.dateSelected!.year,
      state.dateSelected!.month - 1,
    );

    emit(state.copyWith(dateSelected: Wrapped.value(desiredDate)));
    getCalendar();
  }

  void nextMonth() {
    if (state.dateSelected == null) return;
    if (state.getCalendarStatus == WidgetStatus.loading) return;

    final desiredDate = DateTime(
      state.dateSelected!.year,
      state.dateSelected!.month + 1,
    );

    emit(state.copyWith(dateSelected: Wrapped.value(desiredDate)));
    getCalendar();
  }

  // ========================================================================
  // Calendar
  // ========================================================================

  Future<void> getCalendar() async {
    if (state.dateSelected == null) return;
    if (state.getCalendarStatus == WidgetStatus.loading) return;
    emit(state.copyWith(getCalendarStatus: WidgetStatus.loading));

    final response = await _calendarProvider.getCalendar(
      date: state.dateSelected!,
    );

    return response.fold(
      (l) {
        emit(
          state.copyWith(
            getCalendarStatus: WidgetStatus.error,
            errorText: l.details,
          ),
        );
      },
      (r) async {
        // Days of the month
        final List<CalendarDayModel> calendarDays = r;

        // First Day of the selected month
        final DateTime currentDate = DateTime(
          state.dateSelected!.year,
          state.dateSelected!.month,
          1,
        );

        // Calculating previous days of the month
        final int emptySpaces = (currentDate.weekday - 1);

        // Adding empty spaces to the calendar
        if (emptySpaces > 0 && emptySpaces <= 6) {
          for (var i = 0; i < emptySpaces; i++) {
            calendarDays.insert(0, CalendarDayModel());
          }
        }

        emit(
          state.copyWith(
            getCalendarStatus: WidgetStatus.success,
            calendarDayList: Wrapped.value(calendarDays),
          ),
        );
      },
    );
  }

  /// ```
  /// value: 0 -> week
  /// value: 1 -> month
  /// value: 2 -> year
  /// ```
  Future<void> getChart() async {
    if (state.chartFilter > 2 || state.chartFilter < 0) return;
    if (state.getChartStatus == WidgetStatus.loading) return;
    emit(state.copyWith(getChartStatus: WidgetStatus.loading));

    final response = await _calendarProvider.getChart(value: state.chartFilter);

    return response.fold(
      (l) {
        emit(
          state.copyWith(
            getChartStatus: WidgetStatus.error,
            errorText: l.details,
          ),
        );
      },
      (r) async {
        // Points to be rendered
        final List<FlSpot> chartPoints = [];

        for (var i = 0; i < (r.coordinates?.length ?? 0); i++) {
          // Checking null values
          if (r.coordinates?[i].valueY != null &&
              r.coordinates![i].valueX != null) {
            // Adding point
            chartPoints.add(
              FlSpot(r.coordinates![i].valueX!, r.coordinates![i].valueY!),
            );
          }
        }

        emit(
          state.copyWith(
            getChartStatus: WidgetStatus.success,
            chartModel: Wrapped.value(r),
            coordinates: chartPoints,
          ),
        );
      },
    );
  }

  // ========================================================================
  // Emotion Recommendation
  // ========================================================================

  Future<void> getEmotionRecommendation(int? id) async {
    if (id == null) return;
    if (state.descriptionStatus == WidgetStatus.loading) return;
    emit(state.copyWith(descriptionStatus: WidgetStatus.loading));

    final response = await _calendarProvider.getEmotionDescription(id: id);

    return response.fold(
      (l) {
        emit(
          state.copyWith(
            descriptionStatus: WidgetStatus.error,
            errorText: l.details,
          ),
        );
      },
      (r) async {
        emit(
          state.copyWith(
            descriptionStatus: WidgetStatus.success,
            emotionDescription: Wrapped.value(r),
          ),
        );
      },
    );
  }

  // ========================================================================
  // Image Symbols
  // ========================================================================

  void setQuery(String? value) => emit(
    state.copyWith(query: value, listEmotions: const Wrapped.value(null)),
  );

  void setNewSearch() {
    emit(state.copyWith(imageSymbolList: const Wrapped.value(null), query: ""));
  }

  void selectedImageSymbol(ImageSymbolModel? value) {
    emit(state.copyWith(imageSymbolSelected: Wrapped.value(value)));
  }

  void setPhoto(File? value) =>
      emit(state.copyWith(photo: Wrapped.value(value)));

  Future<void> getEmotionList() async {
    if (state.listEmotionsStatus == WidgetStatus.loading ||
        state.moreListStatus == WidgetStatus.loading) {
      return;
    }

    late int? page;

    // Set page value
    if (state.listEmotions == null) {
      page = 1;
    } else {
      if ((state.listEmotions?.links?.next ?? "").isEmpty) return;
      page = GenericUtils.getPage(state.listEmotions!.links!.next!);
      if (page == null) return;
    }

    // Set Pagination loading
    (page == 1)
        ? emit(state.copyWith(listEmotionsStatus: WidgetStatus.loading))
        : emit(state.copyWith(moreListStatus: WidgetStatus.loading));

    final response = await _surveyProvider.getEmotionList(
      page: page,
      query: state.query,
      extend: true,
    );

    return response.fold(
      (l) {
        // Handling error
        (page == 1)
            ? emit(
                state.copyWith(
                  listEmotionsStatus: WidgetStatus.error,
                  errorText: l.details,
                ),
              )
            : emit(
                state.copyWith(
                  moreListStatus: WidgetStatus.error,
                  errorText: l.details,
                ),
              );
      },
      (r) async {
        // Handling success
        emit(
          state.copyWith(
            listEmotionsStatus: WidgetStatus.success,
            moreListStatus: WidgetStatus.success,
            listEmotions: Wrapped.value(
              (state.listEmotions ?? ListEmotionsResponseModel()).copyWith(
                data: [...(state.listEmotions?.data ?? []), ...(r.data ?? [])],
                links: r.links,
                total: r.total,
              ),
            ),
          ),
        );
      },
    );
  }

  Future<void> getImageSymbolList() async {
    if (state.imageSymbolStatus == WidgetStatus.loading ||
        state.moreListStatus == WidgetStatus.loading) {
      return;
    }

    late int? page;

    // Set page value
    if (state.imageSymbolList == null) {
      page = 1;
    } else {
      if (state.imageSymbolList?.nextPage == null) return;
      page = state.imageSymbolList?.nextPage;
    }

    // Set Pagination loading
    (page == 1)
        ? emit(state.copyWith(imageSymbolStatus: WidgetStatus.loading))
        : emit(state.copyWith(moreListStatus: WidgetStatus.loading));

    final response = await _calendarProvider.getImageSymbols(
      query: state.query,
      page: page!,
    );

    return response.fold(
      (l) {
        // Handling error
        (page == 1)
            ? emit(
                state.copyWith(
                  imageSymbolStatus: WidgetStatus.error,
                  errorText: l.details,
                ),
              )
            : emit(
                state.copyWith(
                  moreListStatus: WidgetStatus.error,
                  errorText: l.details,
                ),
              );
      },
      (r) async {
        // Handling success
        emit(
          state.copyWith(
            imageSymbolStatus: WidgetStatus.success,
            moreListStatus: WidgetStatus.success,
            query: ((r.data ?? []).isNotEmpty) ? r.data?.first.emotion : null,
            imageSymbolList: Wrapped.value(
              (state.imageSymbolList ?? ImageSymbolListResponseModel())
                  .copyWith(
                    data: [
                      ...(state.imageSymbolList?.data ?? []),
                      ...(r.data ?? []),
                    ],
                    nextPage: r.nextPage,
                    tags: r.tags,
                  ),
            ),
          ),
        );
      },
    );
  }

  Future<void> createImageSymbol() async {
    if (state.imageSymbolSelected == null) return;
    if (state.imageSymbolStatus == WidgetStatus.loading) return;
    emit(state.copyWith(imageSymbolStatus: WidgetStatus.loading));

    final response = await _calendarProvider.createImageSymbol(
      data: ImageSymbolRequestModel(
        emotion: state.imageSymbolSelected?.emotion,
        description: state.query,
        image: state.photo,
      ),
    );

    return response.fold(
      (l) {
        emit(
          state.copyWith(
            imageSymbolStatus: WidgetStatus.error,
            errorText: l.details,
          ),
        );
      },
      (r) async {
        emit(state.copyWith(imageSymbolStatus: WidgetStatus.success));
      },
    );
  }

  // ========================================================================
  // Face Gallery
  // ========================================================================

  Future<void> getFaceGallery() async {
    if (state.faceGalleryStatus == WidgetStatus.loading) return;
    emit(state.copyWith(faceGalleryStatus: WidgetStatus.loading));

    final response = await _calendarProvider.getFaceGallery();

    return response.fold(
      (l) {
        emit(
          state.copyWith(
            faceGalleryStatus: WidgetStatus.error,
            errorText: l.details,
          ),
        );
      },
      (r) async {
        emit(
          state.copyWith(
            faceGalleryStatus: WidgetStatus.success,
            faceGallery: Wrapped.value(r),
          ),
        );
      },
    );
  }
}
