import 'package:flutter/material.dart';
import 'package:emote_express/core/constants/constants_colors.dart';
import 'package:emote_express/widgets/generic/generic_network_image.dart';
import 'package:emote_express/models/calendar/calendar_day_response_model.dart';

class CalendarDayComponent extends StatelessWidget {
  const CalendarDayComponent(
      {super.key, required this.calendarDay, required this.onPressed});

  final CalendarDayModel calendarDay;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onPressed,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 5),
        decoration: BoxDecoration(
          color: (calendarDay.emotion == null)
              ? ConstantColors.cff1F2128
              : _getColor(),
          border: (calendarDay.isEmptyDay || calendarDay.emotion == null)
              ? const Border.fromBorderSide(
                  BorderSide(color: Color(0xFF4F4F4F)),
                )
              : null,
          borderRadius: const BorderRadius.all(Radius.circular(5)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              alignment: Alignment.center,
              constraints: const BoxConstraints(minHeight: 32),
              decoration: (calendarDay.emotion == null)
                  ? const BoxDecoration(
                      color: ConstantColors.checkboxColor,
                      borderRadius: BorderRadius.all((Radius.circular(5))))
                  : null,
              child: Text(
                "${calendarDay.date?.day ?? ""}",
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontWeight: FontWeight.w700,
                  fontSize: 16,
                ),
              ),
            ),
            if (!calendarDay.isEmptyDay && calendarDay.emotion != null)
              Expanded(
                child: GenericNetworkImage(
                  path: calendarDay.url,
                  sizeDefaultIcon: 24,
                  border: 0,
                  fit: BoxFit.contain,
                ),
              )
            /*const Flexible(
              child: Text(
                "Happy",
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 12,
                ),
              ),
            ),*/
          ],
        ),
      ),
    );
  }

  Color _getColor() {
    switch (calendarDay.emotion) {
      case "Depression":
        return const Color(0xFFF7A8A8);
      case "Hate":
        return const Color(0xFFFF6666);
      case "Surprise":
        return const Color(0xFFFFC3A0);
      case "Loneliness":
        return const Color(0xFFF5A9BC);
      case "Anger":
        return const Color(0xFFFF6F61);
      case "Shame":
        return const Color(0xFFF4B393);
      case "Fear":
        return const Color(0xFFF3B0C3);
      case "Confusion":
        return const Color(0xFFF4C2C2);
      case "Disgust":
        return const Color(0xFFB2E2AF);
      case "Sadness":
        return const Color(0xFFA1C4FD);
      case "Disappointment":
        return const Color(0xFFF7CAC9);
      case "Pride":
        return const Color(0xFFD6A2E8);
      case "Relief":
        return const Color(0xFFAEEEEE);
      case "Hope":
        return const Color(0xFFA3E4D7);
      case "Guilt":
        return const Color(0xFFE29F71);
      case "Anxiety":
        return const Color(0xFFCBAACB);
      case "Boredom":
        return const Color(0xFFFAD6A5);
      case "Joy":
        return const Color(0xFFFFE066);
      case "Love":
        return const Color(0xFFFFB6B9);
      case "Happiness":
        return const Color(0xFFFFF5BA);
      case "Excitement":
        return const Color(0xFFFFB347);
      case "Gratitude":
        return const Color(0xFFB2F2BB);
      case "Contentment":
        return const Color(0xFFFFD580);
      case "Satisfaction":
        return const Color(0xFFB5EAD7);
      case "Interest":
        return const Color(0xFF89CFF0);
      case "Calmness":
        return const Color(0xFFACE7EF);
      case "Acceptance":
        return const Color(0xFFA9DEF9);
      case "Frustration":
        return const Color(0xFFFFA07A);
      case "Jealousy":
        return const Color(0xFFC5E384);
      case "Despair":
        return const Color(0xFFB39EB5);
      default:
        return Colors.green;
    }
  }
}
