import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:emote_express/ui/calendar/cubit/cubit.dart';
import 'package:emote_express/ui/posts/views/post_view.dart';
import 'package:emote_express/core/constants/constants_colors.dart';
import 'package:emote_express/models/generic/emotion_response_model.dart';
import 'package:emote_express/widgets/generic/generic_network_image.dart';

class FaceGalleryTrendingCarousel extends StatelessWidget {
  const FaceGalleryTrendingCarousel({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<CalendarCubit, CalendarState>(
      buildWhen: (p, c) =>
          (p.faceGallery?.dataTrending != c.faceGallery?.dataTrending),
      builder: (context, state) {
        return CarouselSlider.builder(
          itemCount: state.faceGallery?.dataTrending?.length ?? 0,
          options: CarouselOptions(
            viewportFraction: 1,
            aspectRatio: (16 / 9),
            autoPlay: true,
            enableInfiniteScroll: true,
          ),
          itemBuilder: (context, index, realIndex) {
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8.0),
              child: Stack(
                children: [
                  GestureDetector(
                    onTap: () {
                      final emotion = EmotionResponseModel(
                        emotion:
                            state.faceGallery?.dataTrending?[index].emotion,
                        postId: state.faceGallery?.dataTrending?[index].idPost,
                        profileUrl:
                            state.faceGallery?.dataTrending?[index].user?.url,
                        url: state.faceGallery?.dataTrending?[index].url,
                      );

                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => PostView(emotion: emotion),
                        ),
                      );
                    },
                    child: GenericNetworkImage(
                      border: 8,
                      path: state.faceGallery?.dataTrending?[index].url,
                    ),
                  ),
                  Align(
                    alignment: Alignment.bottomCenter,
                    child: Container(
                      margin: const EdgeInsets.symmetric(
                        vertical: 10,
                        horizontal: 16,
                      ),
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      decoration: const BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.all(Radius.circular(40)),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Flexible(
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                GenericNetworkImage(
                                  path: state
                                      .faceGallery
                                      ?.dataTrending?[index]
                                      .user
                                      ?.url,
                                  size: 40,
                                  sizeDefaultIcon: 40,
                                  iconDefaultColor: ConstantColors.cffF6912E,
                                ),
                                const SizedBox(width: 5),
                                Flexible(
                                  child: Text(
                                    state
                                            .faceGallery
                                            ?.dataTrending?[index]
                                            .user
                                            ?.name ??
                                        "N/A",
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                      fontWeight: FontWeight.w700,
                                      color: ConstantColors.cff111114,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                onPressed: () async {},
                                color: ConstantColors.cff111114,
                                icon: const Icon(Icons.favorite_border_rounded),
                              ),
                              const SizedBox(width: 2),
                              Text(
                                state
                                        .faceGallery
                                        ?.dataTrending?[index]
                                        .totalLikes
                                        .toString() ??
                                    "N/A",
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  fontWeight: FontWeight.w700,
                                  color: ConstantColors.cff111114,
                                ),
                              ),
                            ],
                          ),
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                onPressed: () async {},
                                color: ConstantColors.cff111114,
                                icon: const Icon(
                                  Icons.chat_bubble_outline_rounded,
                                ),
                              ),
                              const SizedBox(width: 2),
                              Text(
                                state
                                        .faceGallery
                                        ?.dataTrending?[index]
                                        .totalComments
                                        .toString() ??
                                    "N/A",
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  fontWeight: FontWeight.w700,
                                  color: ConstantColors.cff111114,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }
}
