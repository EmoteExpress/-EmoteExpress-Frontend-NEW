import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:emote_express/models/generic/generic_enums.dart';
import 'package:emote_express/widgets/buttons/generic_button.dart';
import 'package:emote_express/core/constants/constants_icons.dart';
import 'package:emote_express/core/constants/constants_colors.dart';

class FaceGalleryFilterComponent extends StatelessWidget {
  const FaceGalleryFilterComponent({super.key, required this.onFilterSelected});

  final void Function(Gender) onFilterSelected;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(
          children: [
            Expanded(
                child: _Component(
              title: "Male",
              onPressed: () => onFilterSelected(Gender.male),
            )),
            const SizedBox(width: 18),
            Expanded(
                child: _Component(
              title: "Female",
              onPressed: () => onFilterSelected(Gender.female),
            )),
          ],
        ),
        const SizedBox(height: 18),
        GenericButton(
          text: "All",
          onTap: () => onFilterSelected(Gender.other),
        ),
      ],
    );
  }
}

class _Component extends StatelessWidget {
  const _Component({required this.title, required this.onPressed});

  final String title;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Material(
          color: Colors.transparent,
          borderRadius: const BorderRadius.all(Radius.circular(8)),
          child: InkWell(
            onTap: onPressed,
            borderRadius: const BorderRadius.all(Radius.circular(8)),
            child: Ink(
              height: 110,
              decoration: const BoxDecoration(
                color: ConstantColors.cff1F2128,
                borderRadius: BorderRadius.all(Radius.circular(8)),
                border: Border.fromBorderSide(BorderSide(color: Colors.white)),
              ),
              child: Stack(
                children: [
                  Positioned(
                    bottom: -60,
                    left: (title == "Male") ? 8 : null,
                    right: (title == "Female") ? 8 : null,
                    child: Container(
                      height: 100,
                      width: 100,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            blurRadius: 33,
                            spreadRadius: 1,
                            color: ConstantColors.cffF6912E,
                          )
                        ],
                      ),
                    ),
                  ),
                  SvgPicture.asset(
                    (title == "Male")
                        ? ConstantIcons.maleButton
                        : ConstantIcons.womanButton,
                  ),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(height: 10),
        GestureDetector(
          onTap: onPressed,
          child: Text(
            title,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w900,
            ),
          ),
        ),
      ],
    );
  }
}
