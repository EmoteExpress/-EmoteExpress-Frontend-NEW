import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:emote_express/core/core.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:emote_express/ui/calendar/cubit/cubit.dart';

class CalendarChartComponent extends StatefulWidget {
  const CalendarChartComponent({super.key});

  @override
  State<CalendarChartComponent> createState() => _CalendarChartComponentState();
}

class _CalendarChartComponentState extends State<CalendarChartComponent> {
  final List<Color> gradientColors = const [
    ConstantColors.cffF6912E,
    ConstantColors.cffFFBE26,
  ];

  static const Color gridColor = Color(0xFF1C1C21);

  //bool showAvg = false;

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<CalendarCubit, CalendarState>(
      buildWhen: (p, c) =>
          (p.coordinates != c.coordinates || p.chartModel != c.chartModel),
      builder: (context, state) {
        return AspectRatio(
          aspectRatio: 1.6,
          child: LineChart(
            LineChartData(
              backgroundColor: const Color(0xff151515),
              gridData: FlGridData(
                show: true,
                drawVerticalLine: true,
                horizontalInterval: 2,
                verticalInterval: (state.chartFilter == 0)
                    ? 1
                    : (state.chartFilter == 1)
                    ? 3
                    : 50,
                getDrawingHorizontalLine: (value) {
                  return const FlLine(color: gridColor, strokeWidth: 1);
                },
                getDrawingVerticalLine: (value) {
                  return const FlLine(color: gridColor, strokeWidth: 1);
                },
              ),
              titlesData: FlTitlesData(
                show: true,
                rightTitles: const AxisTitles(
                  sideTitles: SideTitles(showTitles: false),
                ),
                topTitles: const AxisTitles(
                  sideTitles: SideTitles(showTitles: false),
                ),
                leftTitles: const AxisTitles(
                  sideTitles: SideTitles(showTitles: false),
                ),
                bottomTitles: AxisTitles(
                  sideTitles: SideTitles(
                    showTitles: true,
                    reservedSize: 30,
                    interval: (state.chartFilter == 0)
                        ? null
                        : (state.chartFilter == 1)
                        ? 3
                        : 80,
                    //getTitlesWidget: bottomTitleWidgets,
                  ),
                ),
                /*leftTitles: AxisTitles(
                  sideTitles: SideTitles(
                    showTitles: true,
                    interval: 1,
                    getTitlesWidget: leftTitleWidgets,
                    reservedSize: 28,
                  ),
                  ),*/
              ),
              borderData: FlBorderData(
                show: false,
                border: Border.all(color: const Color(0xff151515)),
              ),
              minX: (state.chartModel?.minX != null)
                  ? (state.chartModel!.minX! - 1)
                  : 0,
              maxX: state.chartModel?.maxX ?? 7.0,
              minY: -10,
              maxY: 10,
              lineBarsData: [
                LineChartBarData(
                  spots: state.coordinates,
                  isCurved: false,
                  gradient: LinearGradient(colors: gradientColors),
                  barWidth: 3,
                  isStrokeCapRound: true,
                  dotData: const FlDotData(show: false),
                  belowBarData: BarAreaData(
                    show: true,
                    gradient: LinearGradient(
                      colors: gradientColors
                          .map((color) => color.withValues(alpha: 0.3))
                          .toList(),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  /*SizedBox(
          width: 60,
          height: 34,
          child: TextButton(
            onPressed: () {
              setState(() {
                showAvg = !showAvg;
              });
            },
            child: Text(
              'avg',
              style: TextStyle(
                fontSize: 12,
                color: showAvg ? Colors.white.withOpacity(0.5) : Colors.white,
              ),
            ),
          ),
        ),*/

  /*Widget bottomTitleWidgets(double value, TitleMeta meta) {
    const style = TextStyle(
      fontWeight: FontWeight.bold,
      fontSize: 16,
    );
    Widget text;
    switch (value.toInt()) {
      case 2:
        text = const Text('MAR', style: style);
        break;
      case 5:
        text = const Text('JUN', style: style);
        break;
      case 8:
        text = const Text('SEP', style: style);
        break;
      default:
        text = const Text('', style: style);
        break;
    }

    return SideTitleWidget(
      axisSide: meta.axisSide,
      child: text,
    );
  }*/

  /*Widget leftTitleWidgets(double value, TitleMeta meta) {
    String text;
    switch (value.toInt()) {
      case 10:
        text = '10';
        break;
      case 0:
        text = '0';
        break;
      case -8:
        text = '-10';
        break;
      default:
        return const SizedBox.shrink();
    }

    return Text(text,
        textAlign: TextAlign.left,
        style: const TextStyle(
          fontWeight: FontWeight.bold,
          fontSize: 15,
        ));
  }*/

  /*LineChartData avgData() {
    return LineChartData(
      lineTouchData: const LineTouchData(enabled: false),
      gridData: FlGridData(
        show: true,
        drawHorizontalLine: true,
        verticalInterval: 1,
        horizontalInterval: 1,
        getDrawingVerticalLine: (value) {
          return const FlLine(
            color: Color(0xff37434d),
            strokeWidth: 1,
          );
        },
        getDrawingHorizontalLine: (value) {
          return const FlLine(
            color: Color(0xff37434d),
            strokeWidth: 1,
          );
        },
      ),
      titlesData: FlTitlesData(
        show: true,
        bottomTitles: AxisTitles(
          sideTitles: SideTitles(
            showTitles: true,
            reservedSize: 30,
            getTitlesWidget: bottomTitleWidgets,
            interval: 1,
          ),
        ),
        leftTitles: AxisTitles(
          sideTitles: SideTitles(
            showTitles: true,
            getTitlesWidget: leftTitleWidgets,
            reservedSize: 42,
            interval: 1,
          ),
        ),
        topTitles: const AxisTitles(
          sideTitles: SideTitles(showTitles: false),
        ),
        rightTitles: const AxisTitles(
          sideTitles: SideTitles(showTitles: false),
        ),
      ),
      borderData: FlBorderData(
        show: true,
        border: Border.all(color: const Color(0xff37434d)),
      ),
      minX: 0,
      maxX: 11,
      minY: 0,
      maxY: 6,
      lineBarsData: [
        LineChartBarData(
          spots: const [
            FlSpot(0, 3.44),
            FlSpot(2.6, 3.44),
            FlSpot(4.9, 3.44),
            FlSpot(6.8, 3.44),
            FlSpot(8, 3.44),
            FlSpot(9.5, 3.44),
            FlSpot(11, 3.44),
          ],
          isCurved: true,
          gradient: LinearGradient(
            colors: [
              ColorTween(begin: gradientColors[0], end: gradientColors[1])
                  .lerp(0.2)!,
              ColorTween(begin: gradientColors[0], end: gradientColors[1])
                  .lerp(0.2)!,
            ],
          ),
          barWidth: 5,
          isStrokeCapRound: true,
          dotData: const FlDotData(
            show: false,
          ),
          belowBarData: BarAreaData(
            show: true,
            gradient: LinearGradient(
              colors: [
                ColorTween(begin: gradientColors[0], end: gradientColors[1])
                    .lerp(0.2)!
                    .withOpacity(0.1),
                ColorTween(begin: gradientColors[0], end: gradientColors[1])
                    .lerp(0.2)!
                    .withOpacity(0.1),
              ],
            ),
          ),
        ),
      ],
    );
  }*/
}
