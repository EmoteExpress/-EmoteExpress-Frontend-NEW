import 'package:flutter/material.dart';
import 'package:emote_express/core/core.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:emote_express/utils/generic_utils.dart';
import 'package:emote_express/ui/calendar/calendar.dart';
import 'package:emote_express/widgets/generic/generic.dart';
import 'package:emote_express/models/generic/generic_enums.dart';
import 'package:emote_express/widgets/buttons/generic_button.dart';
import 'package:emote_express/widgets/dialogs/generic_dialog.dart';
import 'package:emote_express/ui/home/views/search_word_view.dart';
import 'package:emote_express/widgets/buttons/generic_text_icon_button.dart';

class CalendarView extends StatelessWidget {
  const CalendarView({super.key});

  static const String routeName = 'calendart_view';

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (BuildContext context) => CalendarCubit()
        ..setDate(DateTime.now())
        ..getCalendar()
        ..getChart(),
      child: Scaffold(
        appBar: AppBar(title: const Text("Calendar")),
        body: const SafeArea(child: _View()),
      ),
    );
  }
}

class _View extends StatelessWidget {
  const _View();

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.max,
      children: [
        Expanded(
            child: ListView(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 0),
          children: [
            BlocListener<CalendarCubit, CalendarState>(
              listenWhen: (p, c) => (p.getChartStatus != c.getChartStatus),
              listener: (context, state) {
                switch (state.getChartStatus) {
                  case WidgetStatus.error:
                    showDialog<void>(
                      context: context,
                      barrierDismissible: false,
                      builder: (context) => GenericDialog(
                        description: state.errorText,
                        isErrorDialog: true,
                      ),
                    );
                    break;
                  default:
                    break;
                }
              },
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
                decoration: const BoxDecoration(
                  color: ConstantColors.cff1F2128,
                  borderRadius: BorderRadius.all(Radius.circular(8)),
                ),
                child: const _ChartSection(),
              ),
            ),
            const SizedBox(height: 8),
            BlocListener<CalendarCubit, CalendarState>(
              listenWhen: (p, c) =>
                  (p.getCalendarStatus != c.getCalendarStatus),
              listener: (context, state) {
                switch (state.getCalendarStatus) {
                  case WidgetStatus.error:
                    showDialog<void>(
                      context: context,
                      barrierDismissible: false,
                      builder: (context) => GenericDialog(
                        description: state.errorText,
                        isErrorDialog: true,
                      ),
                    );
                    break;
                  default:
                    break;
                }
              },
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.all(8),
                decoration: const BoxDecoration(
                  color: ConstantColors.cff1F2128,
                  borderRadius: BorderRadius.all(Radius.circular(8)),
                ),
                child: const _CalendarSection(),
              ),
            ),
          ],
        )),
        const SizedBox(height: 12),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Expanded(
                    child: GenericTextIconButton(
                      text: "Emotion Express",
                      icon: Icons.emoji_emotions_rounded,
                      onPressed: () {
                        Navigator.pushNamed(context, SearchWordView.routeName);
                      },
                    ),
                  ),
                  const SizedBox(width: 6),
                  Expanded(
                    child: GenericTextIconButton(
                      text: "Image Symbols",
                      icon: Icons.emoji_emotions_rounded,
                      onPressed: () => Navigator.pushNamed(
                          context, ImageSymbolsView.routeName),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              GenericButton(
                text: "Face & Gallery",
                onTap: () =>
                    Navigator.pushNamed(context, FaceAndGalleryView.routeName),
              ),
            ],
          ),
        )
      ],
    );
  }
}

class _CalendarSection extends StatelessWidget {
  const _CalendarSection();

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            IconButton(
              color: Colors.white,
              visualDensity: VisualDensity.compact,
              icon: const Icon(Icons.arrow_left_rounded),
              onPressed: () {
                context.read<CalendarCubit>().previousMonth();
              },
            ),
            const SizedBox(width: 4),
            BlocBuilder<CalendarCubit, CalendarState>(
                buildWhen: (p, c) => (p.dateSelected != c.dateSelected),
                builder: (context, state) {
                  return Flexible(
                    child: Text(
                      GenericUtils.calendarDate(state.dateSelected),
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                          fontSize: 16, fontWeight: FontWeight.w500),
                    ),
                  );
                }),
            const SizedBox(width: 4),
            IconButton(
              color: Colors.white,
              visualDensity: VisualDensity.compact,
              icon: const Icon(Icons.arrow_right_rounded),
              onPressed: () {
                context.read<CalendarCubit>().nextMonth();
              },
            ),
          ],
        ),
        const SizedBox(height: 10),
        const Row(
          mainAxisSize: MainAxisSize.max,
          children: [
            _DayComponent("Mon", 1),
            SizedBox(width: 4),
            _DayComponent("Tue", 2),
            SizedBox(width: 4),
            _DayComponent("Wed", 3),
            SizedBox(width: 4),
            _DayComponent("Thu", 4),
            SizedBox(width: 4),
            _DayComponent("Fri", 5),
            SizedBox(width: 4),
            _DayComponent("Sat", 6),
            SizedBox(width: 4),
            _DayComponent("Sun", 7),
          ],
        ),
        const SizedBox(height: 4),
        BlocBuilder<CalendarCubit, CalendarState>(
            buildWhen: (p, c) => (p.calendarDayList != c.calendarDayList),
            builder: (context, state) {
              return GridView.builder(
                itemCount: state.calendarDayList?.length ?? 0,
                shrinkWrap: true,
                padding: const EdgeInsets.all(0),
                physics: const NeverScrollableScrollPhysics(),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 7,
                  mainAxisSpacing: 4,
                  crossAxisSpacing: 4,
                  childAspectRatio: 0.6,
                ),
                itemBuilder: (context, index) {
                  return CalendarDayComponent(
                    calendarDay: state.calendarDayList![index],
                    onPressed: () {
                      if (state.calendarDayList![index].idEmotion != null) {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => EmotionDescriptionView(
                                emotionId:
                                    state.calendarDayList![index].idEmotion,
                              ),
                            ));
                      }
                    },
                  );
                },
              );
            }),
      ],
    );
  }
}

class _ChartSection extends StatelessWidget {
  const _ChartSection();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 0),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Flexible(
                child: Text(
                  "Emotion / Day",
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              BlocConsumer<CalendarCubit, CalendarState>(
                  listenWhen: (p, c) => (p.chartFilter != c.chartFilter),
                  listener: (context, state) {
                    context.read<CalendarCubit>().getChart();
                  },
                  buildWhen: (p, c) => (p.chartFilter != c.chartFilter),
                  builder: (context, state) {
                    return Row(
                      children: [
                        _ChartFilter(
                          title: "1W",
                          isSelected: (state.chartFilter == 0),
                          onPressed: () =>
                              context.read<CalendarCubit>().setChartFilter(0),
                        ),
                        const SizedBox(width: 8),
                        _ChartFilter(
                          title: "1M",
                          isSelected: (state.chartFilter == 1),
                          onPressed: () =>
                              context.read<CalendarCubit>().setChartFilter(1),
                        ),
                        const SizedBox(width: 8),
                        _ChartFilter(
                          title: "1Y",
                          isSelected: (state.chartFilter == 2),
                          onPressed: () =>
                              context.read<CalendarCubit>().setChartFilter(2),
                        ),
                      ],
                    );
                  })
            ],
          ),
          const SizedBox(height: 6),
          Stack(
            children: [
              const CalendarChartComponent(),
              BlocBuilder<CalendarCubit, CalendarState>(
                buildWhen: (p, c) => (p.getChartStatus != c.getChartStatus),
                builder: (context, state) {
                  switch (state.getChartStatus) {
                    case WidgetStatus.loading:
                      return const Center(child: LoadingIndicator());
                    case WidgetStatus.error:
                      return Center(child: GenericError(text: state.errorText));
                    default:
                      return const SizedBox.shrink();
                  }
                },
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _ChartFilter extends StatelessWidget {
  const _ChartFilter(
      {required this.title, required this.isSelected, required this.onPressed});

  final String title;
  final bool isSelected;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onPressed,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
        decoration: BoxDecoration(
          color: (isSelected) ? Colors.white : const Color(0xFF1F1F20),
          borderRadius: const BorderRadius.all(Radius.circular(12)),
        ),
        child: Text(
          title,
          style: TextStyle(
            fontWeight: FontWeight.w700,
            color: (isSelected) ? const Color(0xFF1F1F20) : Colors.white,
          ),
        ),
      ),
    );
  }
}

class _DayComponent extends StatelessWidget {
  const _DayComponent(this.value, this.dayOfWeek);

  final String value;
  final int dayOfWeek;

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<CalendarCubit, CalendarState>(
        buildWhen: (p, c) => (p.dateSelected != c.dateSelected),
        builder: (context, state) {
          final today = DateTime.now();
          return Expanded(
              child: Text(
            value,
            maxLines: 1,
            textAlign: TextAlign.center,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: ((state.dateSelected?.month == today.month) &&
                      (state.dateSelected?.year == today.year) &&
                      today.weekday == dayOfWeek)
                  ? ConstantColors.cffFFBE26
                  : Colors.white,
            ),
          ));
        });
  }
}
