import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:emote_express/ui/calendar/cubit/cubit.dart';
import 'package:emote_express/models/generic/generic_enums.dart';
import 'package:emote_express/widgets/dialogs/generic_dialog.dart';
import 'package:emote_express/widgets/buttons/generic_button.dart';
import 'package:emote_express/widgets/input/generic_form_input.dart';
import 'package:emote_express/widgets/generic/loading_indicator.dart';
import 'package:emote_express/widgets/input/select_profile_image.dart';
import 'package:emote_express/widgets/generic/generic_network_image.dart';
import 'package:emote_express/models/calendar/image_symbol_list_response_model.dart';

class CreateImageSymbolView extends StatelessWidget {
  const CreateImageSymbolView({super.key, this.imageSymbol});

  static const String routeName = 'create_image_symbol_view';

  final ImageSymbolModel? imageSymbol;

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (BuildContext context) => CalendarCubit()
        ..selectedImageSymbol(imageSymbol)
        ..setQuery(imageSymbol?.quote),
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: AppBar(title: const Text("Create Image Symbols")),
        body: SafeArea(
          child: BlocListener<CalendarCubit, CalendarState>(
            listenWhen: (p, c) => (p.imageSymbolStatus != c.imageSymbolStatus),
            listener: (context, state) {
              switch (state.imageSymbolStatus) {
                case WidgetStatus.error:
                  showDialog<void>(
                    context: context,
                    barrierDismissible: false,
                    builder: (context) => GenericDialog(
                      description: state.errorText,
                      isErrorDialog: true,
                    ),
                  );
                  break;

                case WidgetStatus.success:
                  showDialog<void>(
                    context: context,
                    barrierDismissible: false,
                    builder: (context) => GenericDialog(
                      title: "Post created successfully!",
                      description: '''We're excited to see your latest post! '''
                          '''It's now available for everyone to read. Thanks '''
                          '''for sharing your thoughts with us.''',
                      onAccept: () {
                        Navigator.pop(context);
                        Navigator.pop(context);
                      },
                    ),
                  );

                  break;
                default:
                  break;
              }
            },
            child: Stack(
              children: [
                const _View(),
                BlocBuilder<CalendarCubit, CalendarState>(
                  buildWhen: (p, c) =>
                      (p.imageSymbolStatus != c.imageSymbolStatus),
                  builder: (context, state) {
                    if (state.imageSymbolStatus == WidgetStatus.loading) {
                      return const Center(child: LoadingIndicator());
                    } else {
                      return const SizedBox.shrink();
                    }
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _View extends StatefulWidget {
  const _View();

  @override
  State<_View> createState() => _ViewState();
}

class _ViewState extends State<_View> {
  late CalendarCubit _cubit;
  late TextEditingController _controller;

  @override
  void initState() {
    _cubit = context.read<CalendarCubit>();
    _controller = TextEditingController(
      text: _cubit.state.imageSymbolSelected?.quote,
    );
    super.initState();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.max,
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        BlocBuilder<CalendarCubit, CalendarState>(
            buildWhen: (p, c) =>
                (p.imageSymbolSelected != c.imageSymbolSelected),
            builder: (context, state) {
              return Expanded(
                child: ListView(
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  children: [
                    Text(
                      state.imageSymbolSelected?.emotion ?? "N/A",
                      style: const TextStyle(
                        fontSize: 27,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 16),
                    const _ImageComponent(),
                    const SizedBox(height: 16),
                    const Text(
                      "Knowing our emotions",
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const SizedBox(height: 16),
                    GenericFormInput(
                      maxLines: 5,
                      minLines: 5,
                      textController: _controller,
                      hintText: "Express what you feel",
                      textInputType: TextInputType.multiline,
                      textInputAction: TextInputAction.newline,
                      textCapitalization: TextCapitalization.sentences,
                      onChanged: (value) => _cubit.setQuery(value),
                    ),
                  ],
                ),
              );
            }),
        BlocBuilder<CalendarCubit, CalendarState>(
            buildWhen: (p, c) => (p.query != c.query || p.photo != c.photo),
            builder: (context, state) {
              return Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
                child: GenericButton(
                  text: "Create Post",
                  onTap:
                      ((state.query.trim()).isNotEmpty && state.photo != null)
                          ? () {
                              FocusScope.of(context).unfocus();
                              FocusManager.instance.primaryFocus?.unfocus();
                              _cubit.createImageSymbol();
                            }
                          : null,
                ),
              );
            })
      ],
    );
  }
}

class _ImageComponent extends StatelessWidget {
  const _ImageComponent();

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<CalendarCubit, CalendarState>(
        buildWhen: (p, c) => (p.photo != c.photo),
        builder: (context, state) {
          return GestureDetector(
            onTap: () {
              FocusScope.of(context).unfocus();
              FocusManager.instance.primaryFocus?.unfocus();

              showModalBottomSheet<void>(
                context: context,
                isScrollControlled: true,
                builder: (BuildContext context2) {
                  return UploadImageModal(
                    onSelected: (image) {
                      context.read<CalendarCubit>().setPhoto(image.file);
                      Navigator.pop(context2);
                    },
                  );
                },
              );
            },
            child: (state.photo == null)
                ? Container(
                    width: MediaQuery.of(context).size.width,
                    height: MediaQuery.of(context).size.height * 0.3,
                    decoration: const BoxDecoration(
                      color: Color(0xFF292929),
                      border: Border.fromBorderSide(
                        BorderSide(color: Color(0xFFA9A9A9)),
                      ),
                      borderRadius: BorderRadius.all(Radius.circular(8)),
                    ),
                    child: const Icon(
                      Icons.camera_alt_outlined,
                      size: 70,
                      color: Color(0xFFF9912A),
                    ),
                  )
                : GenericNetworkImage(
                    path: state.photo?.path,
                    border: 8,
                    width: MediaQuery.of(context).size.width,
                    height: MediaQuery.of(context).size.height * 0.3,
                  ),
          );
        });
  }
}
