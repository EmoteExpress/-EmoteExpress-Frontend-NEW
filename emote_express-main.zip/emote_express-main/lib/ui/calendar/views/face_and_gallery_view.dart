import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:emote_express/ui/calendar/calendar.dart';
import 'package:emote_express/widgets/generic/generic.dart';
import 'package:emote_express/ui/posts/views/feed_view.dart';
import 'package:emote_express/ui/posts/views/post_view.dart';
import 'package:emote_express/models/generic/generic_enums.dart';
import 'package:emote_express/ui/home/widgets/emotion_image.dart';

class FaceAndGalleryView extends StatelessWidget {
  const FaceAndGalleryView({super.key});

  static const String routeName = 'face_and_gallery_view';

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (BuildContext context) => CalendarCubit()..getFaceGallery(),
      child: Scaffold(
        appBar: AppBar(title: const Text("Face & Gallery")),
        body: const GenericLayout(child: SafeArea(child: _View())),
      ),
    );
  }
}

class _View extends StatelessWidget {
  const _View();

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
      children: [
        FaceGalleryFilterComponent(
          onFilterSelected: (gender) {
            Navigator.push<void>(
              context,
              MaterialPageRoute(builder: (context) => FeedView(gender: gender)),
            );
          },
        ),
        const SizedBox(height: 16),
        const Text(
          "Trending Today",
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 16),
        BlocBuilder<CalendarCubit, CalendarState>(
          buildWhen: (p, c) => (p.faceGalleryStatus != c.faceGalleryStatus),
          builder: (context, state) {
            switch (state.faceGalleryStatus) {
              case WidgetStatus.loading:
                return const Center(child: LoadingIndicator());
              case WidgetStatus.error:
                return Center(child: GenericError(text: state.errorText));
              default:
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const FaceGalleryTrendingCarousel(),
                    const SizedBox(height: 16),
                    const Text(
                      "Other Users",
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 16),
                    GridView.builder(
                      itemCount:
                          state.faceGallery?.recommendedPosts?.length ?? 0,
                      shrinkWrap: true,
                      padding: const EdgeInsets.all(0),
                      physics: const NeverScrollableScrollPhysics(),
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 2,
                            mainAxisSpacing: 16,
                            crossAxisSpacing: 16,
                            childAspectRatio: 0.8,
                          ),
                      itemBuilder: (context, index) {
                        return EmotionImage(
                          path: state.faceGallery?.recommendedPosts?[index].url,
                          text: state
                              .faceGallery
                              ?.recommendedPosts?[index]
                              .emotion,
                          profileUrl: state
                              .faceGallery
                              ?.recommendedPosts?[index]
                              .profileUrl,
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => PostView(
                                  emotion: state
                                      .faceGallery
                                      ?.recommendedPosts?[index],
                                ),
                              ),
                            );
                          },
                        );
                      },
                    ),
                  ],
                );
            }
          },
        ),
      ],
    );
  }
}
