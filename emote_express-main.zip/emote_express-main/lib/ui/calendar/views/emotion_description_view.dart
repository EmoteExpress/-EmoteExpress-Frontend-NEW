import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:emote_express/ui/calendar/calendar.dart';
import 'package:emote_express/widgets/generic/generic.dart';
import 'package:emote_express/models/generic/generic_enums.dart';
import 'package:emote_express/core/constants/constants_colors.dart';

// This page is used for Calendar day view and survey view
class EmotionDescriptionView extends StatelessWidget {
  const EmotionDescriptionView({super.key, this.emotionId});

  static const String routeName = 'calendart_day_summary_view';

  final int? emotionId;

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (BuildContext context) =>
          CalendarCubit()..getEmotionRecommendation(emotionId),
      child: Scaffold(
        appBar: AppBar(
          title: const Text("Summary"),
        ),
        body: SafeArea(
            child: BlocBuilder<CalendarCubit, CalendarState>(
          buildWhen: (p, c) => (p.descriptionStatus != c.descriptionStatus),
          builder: (context, state) {
            switch (state.descriptionStatus) {
              case WidgetStatus.loading:
                return const Center(child: LoadingIndicator());
              case WidgetStatus.error:
                return Center(child: GenericError(text: state.errorText));
              default:
                return const _View();
            }
          },
        )),
      ),
    );
  }
}

class _View extends StatelessWidget {
  const _View();

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<CalendarCubit, CalendarState>(
        buildWhen: (p, c) => (p.emotionDescription != c.emotionDescription),
        builder: (context, state) {
          return Column(
            children: [
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                  children: [
                    const SizedBox(height: 20),
                    Container(
                      height: 200,
                      width: 200,
                      padding: const EdgeInsets.all(30),
                      decoration: const BoxDecoration(
                        color: Color(0xFFF4CE9B),
                        shape: BoxShape.circle,
                      ),
                      child: GenericNetworkImage(
                        path: state.emotionDescription?.url,
                        border: 0,
                        fit: BoxFit.contain,
                      ),
                    ),
                    const SizedBox(height: 20),
                    Text(
                      state.emotionDescription?.emotion ?? "N/A",
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      child: Text(
                        state.emotionDescription?.description ?? "N/A",
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontSize: 16,
                          color: Color(0xFF848484),
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                    const SizedBox(height: 30),
                    const Text(
                      "Recommendations",
                      textAlign: TextAlign.left,
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const SizedBox(height: 16),
                    ListView.separated(
                      shrinkWrap: true,
                      padding: const EdgeInsets.all(0),
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: state.emotionDescription?.tags?.length ?? 0,
                      itemBuilder: (BuildContext context, int index) {
                        return _Component(
                          title:
                              state.emotionDescription?.tags?[index].subtitle,
                          description:
                              state.emotionDescription?.tags?[index].concept,
                        );
                      },
                      separatorBuilder: (BuildContext context, int index) =>
                          const SizedBox(height: 16),
                    ),
                    const SizedBox(height: 16),
                  ],
                ),
              ),
              /*const SizedBox(height: 12),
            const SafeArea(
              top: false,
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 16),
                child: GenericButton(text: "Next"),
              ),
            )*/
            ],
          );
        });
  }
}

class _Component extends StatelessWidget {
  const _Component({this.title, this.description});

  final String? title;
  final String? description;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
      decoration: const BoxDecoration(
        color: ConstantColors.cff1F2128,
        borderRadius: BorderRadius.all(Radius.circular(8)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title ?? "N/A",
            textAlign: TextAlign.left,
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 16),
          Text(
            description ?? "N/A",
            textAlign: TextAlign.justify,
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w300,
            ),
          ),
        ],
      ),
    );
  }
}
