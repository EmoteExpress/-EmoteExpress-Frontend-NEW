import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:emote_express/ui/calendar/cubit/cubit.dart';
import 'package:emote_express/widgets/generic/generic.dart';
import 'package:emote_express/widgets/input/search_input.dart';
import 'package:emote_express/models/generic/generic_enums.dart';
import 'package:emote_express/ui/calendar/views/search_image_symbol_view.dart';

class ImageSymbolsView extends StatelessWidget {
  const ImageSymbolsView({super.key});

  static const String routeName = 'image_symbols_view';

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => CalendarCubit(),
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: AppBar(title: const Text("Image Symbols")),
        body: const SafeArea(child: _View()),
      ),
    );
  }
}

class _View extends StatefulWidget {
  const _View();

  @override
  State<_View> createState() => _ViewState();
}

class _ViewState extends State<_View> {
  late CalendarCubit _cubit;
  late TextEditingController _controller;
  late ScrollController _scrollController;

  @override
  void initState() {
    _cubit = context.read<CalendarCubit>();
    _scrollController = ScrollController();
    _controller = TextEditingController(text: "");

    _cubit.getEmotionList();

    _scrollController.addListener(() {
      double position = _scrollController.position.pixels;
      double maxExtend = _scrollController.position.maxScrollExtent;
      if ((position > maxExtend - 400)) {
        _cubit.getEmotionList();
      }
    });

    super.initState();
  }

  @override
  void dispose() {
    _controller.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        BlocBuilder<CalendarCubit, CalendarState>(
            buildWhen: (p, c) => (p.query != c.query),
            builder: (context, state) {
              return Padding(
                padding:
                    const EdgeInsets.symmetric(vertical: 0, horizontal: 16),
                child: SearchInput(
                  hintText: "Search emotion",
                  textController: _controller,
                  onChanged: (value) {
                    _cubit.setQuery(value);
                    _cubit.getEmotionList();
                  },
                ),
              );
            }),
        const SizedBox(height: 16),
        BlocBuilder<CalendarCubit, CalendarState>(
          buildWhen: (p, c) => (p.listEmotionsStatus != c.listEmotionsStatus ||
              p.moreListStatus != c.moreListStatus),
          builder: (context, state) {
            switch (state.listEmotionsStatus) {
              case WidgetStatus.loading:
                return const Center(child: LoadingAnimation());
              case WidgetStatus.error:
                return Expanded(
                  child: Center(child: GenericError(text: state.errorText)),
                );
              default:
                List<Widget> children = [];

                for (String? emotion in state.listEmotions?.data ?? []) {
                  children.add(_Component(
                    text: emotion,
                    onPressed: () {
                      Navigator.push<void>(
                          context,
                          MaterialPageRoute(
                            builder: (context) => SearchImageSymbolView(
                              query: emotion,
                            ),
                          ));
                    },
                  ));
                }

                if (state.moreListStatus == WidgetStatus.loading) {
                  children.add(const Center(child: LoadingIndicator()));
                }

                if (state.moreListStatus == WidgetStatus.error) {
                  children.add(const GenericError());
                }

                return Expanded(
                  child: GridView.builder(
                    itemCount: children.length,
                    shrinkWrap: true,
                    controller: _scrollController,
                    keyboardDismissBehavior:
                        ScrollViewKeyboardDismissBehavior.onDrag,
                    padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 3,
                      mainAxisSpacing: 5,
                      crossAxisSpacing: 4,
                      childAspectRatio: 2.2,
                    ),
                    itemBuilder: (context, index) => children[index],
                  ),
                );
            }
          },
        )
      ],
    );
  }
}

class _Component extends StatelessWidget {
  const _Component({this.text, this.onPressed});

  final String? text;
  final VoidCallback? onPressed;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onPressed,
      child: Container(
        alignment: Alignment.center,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        decoration: const BoxDecoration(
          color: Color(0xFF292929),
          borderRadius: BorderRadius.all(Radius.circular(8)),
        ),
        child: Text(
          text ?? "N/A",
          textAlign: TextAlign.center,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
    );
  }
}
