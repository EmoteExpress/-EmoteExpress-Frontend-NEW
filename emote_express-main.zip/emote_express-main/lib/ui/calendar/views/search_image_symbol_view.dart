import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:emote_express/widgets/generic/generic.dart';
import 'package:emote_express/ui/calendar/cubit/cubit.dart';
import 'package:emote_express/widgets/input/search_input.dart';
import 'package:emote_express/models/generic/generic_enums.dart';
import 'package:emote_express/ui/home/views/search_word_view.dart';
import 'package:emote_express/ui/home/views/custom_floating_button.dart';
import 'package:emote_express/ui/calendar/views/create_image_symbol_view.dart';

class SearchImageSymbolView extends StatelessWidget {
  const SearchImageSymbolView({super.key, this.query});

  static const String routeName = 'search_image_symbol_view';

  final String? query;

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (BuildContext context) => CalendarCubit()..setQuery(query),
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: AppBar(title: const Text("Image Symbols")),
        floatingActionButton: BlocBuilder<CalendarCubit, CalendarState>(
            buildWhen: (p, c) => (p.imageSymbolStatus != c.imageSymbolStatus),
            builder: (context, state) {
              return (state.imageSymbolStatus == WidgetStatus.success)
                  ? CustomFloatingButton(
                      onPressed: () {
                        final cubit = context.read<CalendarCubit>();
                        cubit.setNewSearch();
                        cubit.getImageSymbolList();
                      },
                    )
                  : const SizedBox.shrink();
            }),
        floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
        body: const SafeArea(child: _View()),
      ),
    );
  }
}

class _View extends StatefulWidget {
  const _View();

  @override
  State<_View> createState() => _ViewState();
}

class _ViewState extends State<_View> {
  late CalendarCubit _cubit;
  late TextEditingController _controller;
  late ScrollController _scrollController;

  @override
  void initState() {
    _cubit = context.read<CalendarCubit>();
    _controller = TextEditingController(text: _cubit.state.query);
    _scrollController = ScrollController();

    _cubit.getImageSymbolList();

    super.initState();
  }

  @override
  void dispose() {
    _controller.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        BlocListener<CalendarCubit, CalendarState>(
          listenWhen: (p, c) => (p.query != c.query),
          listener: (context, state) {
            _controller.text = state.query;
          },
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 0, horizontal: 16),
            child: SearchInput(
              hintText: "Search emotions",
              textController: _controller,
              onChanged: (value) {
                _cubit.setNewSearch();
                _cubit.setQuery(value);

                if ((value ?? "").isNotEmpty) {
                  _cubit.getImageSymbolList();
                }
              },
            ),
          ),
        ),
        const SizedBox(height: 16),
        BlocBuilder<CalendarCubit, CalendarState>(
          buildWhen: (p, c) => (p.imageSymbolStatus != c.imageSymbolStatus),
          builder: (context, state) {
            switch (state.imageSymbolStatus) {
              case WidgetStatus.loading:
                return const Expanded(child: Center(child: LoadingAnimation()));
              case WidgetStatus.error:
                return Expanded(
                  child: Center(child: GenericError(text: state.errorText)),
                );
              default:
                return const Expanded(child: SafeArea(child: _RenderContent()));
            }
          },
        )
      ],
    );
  }
}

class _RenderContent extends StatelessWidget {
  const _RenderContent();

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<CalendarCubit, CalendarState>(
        buildWhen: (p, c) => (p.imageSymbolList != c.imageSymbolList),
        builder: (context, state) {
          if ((state.imageSymbolList?.data ?? []).isEmpty) {
            return const Center(
              child: Padding(
                padding: EdgeInsets.all(24.0),
                child: Text(
                  '''Sorry! No result found :( We're sorry what you were '''
                  '''looking for. Please try another word.''',
                  textAlign: TextAlign.center,
                ),
              ),
            );
          }

          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: 40,
                child: ListView.separated(
                  itemCount: state.imageSymbolList?.tags?.length ?? 0,
                  shrinkWrap: true,
                  scrollDirection: Axis.horizontal,
                  padding:
                      const EdgeInsets.symmetric(vertical: 0, horizontal: 16),
                  itemBuilder: (context, index) {
                    return GestureDetector(
                      onTap: () {
                        final cubit = context.read<CalendarCubit>();

                        cubit.setNewSearch();
                        cubit.setQuery(
                            state.imageSymbolList?.tags?[index] ?? "");

                        cubit.getImageSymbolList();
                      },
                      child: TagComponent(
                        text: state.imageSymbolList?.tags?[index] ?? "N/A",
                        padding: const EdgeInsets.symmetric(horizontal: 10),
                      ),
                    );
                  },
                  separatorBuilder: (context, index) =>
                      const SizedBox(width: 10),
                ),
              ),
              const SizedBox(height: 16),
              Expanded(
                child: GridView.builder(
                  itemCount: state.imageSymbolList?.data?.length ?? 0,
                  shrinkWrap: true,
                  keyboardDismissBehavior:
                      ScrollViewKeyboardDismissBehavior.onDrag,
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    mainAxisSpacing: 16,
                    crossAxisSpacing: 16,
                    childAspectRatio: 0.8,
                  ),
                  itemBuilder: (context, index) {
                    return _Component(
                      text: state.imageSymbolList?.data?[index].quote,
                      onPressed: () {
                        Navigator.push<void>(
                            context,
                            MaterialPageRoute(
                              builder: (context) => CreateImageSymbolView(
                                  imageSymbol:
                                      state.imageSymbolList?.data?[index]),
                            ));
                      },
                    );
                  },
                ),
              ),
            ],
          );
        });
  }
}

class _Component extends StatelessWidget {
  const _Component({this.text, this.onPressed});

  final String? text;
  final VoidCallback? onPressed;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onPressed,
      child: Container(
        alignment: Alignment.center,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        decoration: const BoxDecoration(
          color: Color(0xFF292929),
          borderRadius: BorderRadius.all(Radius.circular(8)),
        ),
        child: Text(
          text ?? "N/A",
          textAlign: TextAlign.center,
          overflow: TextOverflow.ellipsis,
          maxLines: 8,
          style: const TextStyle(
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
    );
  }
}
