import 'package:flutter/material.dart';
import 'package:emote_express/ui/home/views/views.dart';
import 'package:emote_express/utils/local_storage.dart';
import 'package:emote_express/models/generic/generic_enums.dart';
import 'package:emote_express/ui/authentication/login/views/views.dart';
import 'package:emote_express/ui/onboarding/views/onboarding_view.dart';

class App extends StatefulWidget {
  const App({super.key});

  @override
  State<App> createState() => _AppState();
}

class _AppState extends State<App> {
  late AppState status;

  @override
  void initState() {
    final isLogged = (LocalStorage.getToken() ?? "").isNotEmpty;
    final hasSeenOnboarding = LocalStorage.hasSeenOnboarding() ?? false;

    // Caso cuando es necesario mostrar el onboarding
    if (!hasSeenOnboarding) {
      status = AppState.onboarding;
      return;
    }

    // Caso cuando el usuario esta logueado
    if (isLogged) {
      if (LocalStorage.getUserType() == "user") {
        status = AppState.loggedUser;
      } else {
        status = AppState.error;
      }
      return;
    }

    // Caso cuando el usuario ya vio el onboarding y no esta logueado
    if (hasSeenOnboarding && !isLogged) {
      status = AppState.logOut;
      return;
    }

    // Caso cuando el usuario no ha visto el onboarding y esta logueado
    if (!hasSeenOnboarding && isLogged) {
      status = AppState.error;
      return;
    }

    status = AppState.error;

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    switch (status) {
      case AppState.onboarding:
        return const OnBoardingView();
      case AppState.loggedUser:
        return const HomeView();
      case AppState.logOut:
        return const LoginView();
      case AppState.error:
        return const HomeDefaultView();
    }
  }
}
