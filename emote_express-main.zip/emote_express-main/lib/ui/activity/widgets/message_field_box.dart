import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:emote_express/ui/activity/cubit/cubit.dart';
import 'package:emote_express/models/generic/generic_enums.dart';
import 'package:emote_express/widgets/dialogs/generic_dialog.dart';
import 'package:emote_express/core/constants/constants_colors.dart';
import 'package:emote_express/widgets/generic/loading_indicator.dart';

class MessageFieldBox extends StatefulWidget {
  const MessageFieldBox({super.key});

  @override
  State<MessageFieldBox> createState() => _MessageFieldBoxState();
}

class _MessageFieldBoxState extends State<MessageFieldBox> {
  late ActivityCubit _cubit;
  late TextEditingController _controller;

  @override
  void initState() {
    _cubit = context.read<ActivityCubit>();
    _controller = TextEditingController();
    super.initState();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(color: ConstantColors.cff1F2128),
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Flexible(
            child: TextFormField(
              controller: _controller,
              textCapitalization: TextCapitalization.sentences,
              decoration: InputDecoration(
                filled: true,
                fillColor: ConstantColors.cff08080D,
                hintText: 'Type your question...',
                hintStyle: TextStyle(color: Color(0xFFC2C2C2)),
                contentPadding: const EdgeInsets.symmetric(
                  vertical: 12,
                  horizontal: 12,
                ),
                enabledBorder: OutlineInputBorder(
                  borderSide: const BorderSide(color: Color(0xFF757575)),
                  borderRadius: BorderRadius.circular(8),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: const BorderSide(color: Color(0xFF757575)),
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ),
          ),
          const SizedBox(width: 6),
          BlocConsumer<ActivityCubit, ActivityState>(
            listenWhen: (p, c) => (p.sendThreadStatus != c.sendThreadStatus),
            listener: (context, state) {
              if (state.sendThreadStatus == WidgetStatus.error) {
                FocusScope.of(context).unfocus();
                FocusManager.instance.primaryFocus?.unfocus();

                showDialog<void>(
                  context: context,
                  barrierDismissible: false,
                  builder: (context) => GenericDialog(
                    description: state.errorText,
                    isErrorDialog: true,
                  ),
                );
              }
            },
            buildWhen: (p, c) => (p.sendThreadStatus != c.sendThreadStatus),
            builder: (context, state) {
              if (state.sendThreadStatus == WidgetStatus.loading) {
                return const LoadingIndicator();
              }

              return Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(100),
                  color: ConstantColors.cffF6912E,
                ),
                child: IconButton(
                  icon: const Icon(Icons.send_rounded, color: Colors.white),
                  onPressed: () {
                    if (_controller.text.trim().isEmpty) return;

                    _cubit.sendMessage(message: _controller.text.trim());
                    _controller.clear();
                  },
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
