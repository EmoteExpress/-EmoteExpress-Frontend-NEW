import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:emote_express/utils/generic_utils.dart';
import 'package:emote_express/models/generic/wrapped.dart';
import 'package:emote_express/providers/activity_provider.dart';
import 'package:emote_express/models/generic/generic_enums.dart';
import 'package:emote_express/models/activity/list_messages_model.dart';
import 'package:emote_express/models/activity/list_threads_response_model.dart';

part 'activity_state.dart';

class ActivityCubit extends Cubit<ActivityState> {
  ActivityCubit() : super(const ActivityState());

  final _activityProvider = ActivityProvider();

  void setThread(String? id) => emit(state.copyWith(threadId: id));

  // =========================================================================
  // Threads
  // =========================================================================

  Future<void> getThreads() async {
    if (state.getThreadStatus == WidgetStatus.loading) return;
    emit(
      state.copyWith(
        getThreadStatus: WidgetStatus.loading,
        listThreads: Wrapped.value(null),
      ),
    );

    final resp = await _activityProvider.getThreads();

    resp.fold(
      (l) {
        emit(
          state.copyWith(
            errorText: l.details,
            getThreadStatus: WidgetStatus.error,
          ),
        );
      },
      (r) {
        emit(
          state.copyWith(
            listThreads: Wrapped.value(r),
            getThreadStatus: WidgetStatus.success,
          ),
        );
      },
    );
  }

  Future<void> getMoreThreads() async {
    final nextPage = GenericUtils.getPage(state.listThreads?.links?.next ?? "");
    if (state.getMoreStatus == WidgetStatus.loading || nextPage == null) return;

    emit(state.copyWith(getMoreStatus: WidgetStatus.loading));

    final response = await _activityProvider.getThreads(page: nextPage);

    response.fold(
      (l) => emit(
        state.copyWith(getMoreStatus: WidgetStatus.error, errorText: l.details),
      ),
      (r) {
        final currentList = state.listThreads?.data ?? [];
        final newList = [...currentList, ...(r.data!)];

        emit(
          state.copyWith(
            getMoreStatus: WidgetStatus.success,
            listThreads: Wrapped.value(r.copyWith(data: newList)),
          ),
        );
      },
    );
  }

  Future<void> deleteThread(String? id) async {
    if (id == null) return;
    if (state.activityGenericStatus == WidgetStatus.loading) return;
    emit(state.copyWith(activityGenericStatus: WidgetStatus.loading));

    final response = await _activityProvider.deleteThread(id);

    response.fold(
      (l) {
        emit(
          state.copyWith(
            errorText: l.details,
            activityGenericStatus: WidgetStatus.error,
          ),
        );
      },
      (r) {
        emit(state.copyWith(activityGenericStatus: WidgetStatus.success));
        getThreads();
      },
    );
  }

  // =========================================================================
  // Messages
  // =========================================================================

  Future<void> getThreadMessages() async {
    if (state.threadId.isEmpty) return;
    late int? page;

    // Set page value
    if (state.listMessages == null) {
      page = 1;
    } else {
      if ((state.listMessages?.links?.next ?? "").isEmpty) return;
      page = GenericUtils.getPage(state.listMessages!.links!.next!);
      if (page == null) return;
    }

    if (state.getThreadStatus == WidgetStatus.loading) return;
    if (state.getMoreStatus == WidgetStatus.loading) return;

    // Set Pagination loading
    (page == 1)
        ? emit(state.copyWith(getThreadStatus: WidgetStatus.loading))
        : emit(state.copyWith(getMoreStatus: WidgetStatus.loading));

    final response = await _activityProvider.getThreadMessages(
      idThread: state.threadId,
      page: page,
    );

    return response.fold(
      (l) {
        // Handling error
        (page == 1)
            ? emit(
                state.copyWith(
                  getThreadStatus: WidgetStatus.error,
                  errorText: l.details,
                ),
              )
            : emit(
                state.copyWith(
                  getMoreStatus: WidgetStatus.error,
                  errorText: l.details,
                ),
              );
      },
      (r) {
        // Handling success
        emit(
          state.copyWith(
            getThreadStatus: WidgetStatus.success,
            getMoreStatus: WidgetStatus.success,
            listMessages: Wrapped.value(
              (state.listMessages ?? ListMessagesResponseModel()).copyWith(
                data: [...(state.listMessages?.data ?? []), ...(r.data ?? [])],
                links: r.links,
                total: r.total,
              ),
            ),
          ),
        );
      },
    );
  }

  // Si el id del hilo es nulo, se crea un hilo nuevo.
  // Si el id del hilo no es nulo, se agrega un mensaje al hilo.
  Future<void> sendMessage({required String message}) async {
    if (message.isEmpty) return;
    if (state.sendThreadStatus == WidgetStatus.loading) return;

    // Se agrega manualmente el mensaje enviado por el usuario.
    final newList = state.listMessages?.data ?? [];
    newList.insert(0, MessageModel(message: message, question: false));
    emit(
      state.copyWith(
        sendThreadStatus: WidgetStatus.loading,
        listMessages: Wrapped.value(
          (state.listMessages == null)
              ? ListMessagesResponseModel(data: newList)
              : state.listMessages?.copyWith(data: newList),
        ),
      ),
    );

    final response = await _activityProvider.sendMessage(
      message: message,
      idThread: state.threadId,
    );

    return response.fold(
      (l) {
        // Se elimina manualmente el mensaje enviado por el usuario.
        newList.removeAt(0);
        emit(
          state.copyWith(
            sendThreadStatus: WidgetStatus.error,
            errorText: l.details,
            listMessages: Wrapped.value(
              (state.listMessages == null)
                  ? ListMessagesResponseModel(data: newList)
                  : state.listMessages?.copyWith(data: newList),
            ),
          ),
        );
      },
      (r) async {
        final newList = state.listMessages?.data ?? [];
        newList.insert(0, MessageModel(message: r.text, question: true));

        // Si se esta creando una conversacion se guarda el id en el estado
        if (state.threadId.isEmpty) emit(state.copyWith(threadId: r.idThread));

        emit(
          state.copyWith(
            listMessages: Wrapped.value(
              state.listMessages?.copyWith(data: [...newList]),
            ),
            sendThreadStatus: WidgetStatus.success,
          ),
        );
      },
    );
  }
}
