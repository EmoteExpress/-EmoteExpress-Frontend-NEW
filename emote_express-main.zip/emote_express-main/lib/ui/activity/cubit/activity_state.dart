part of 'activity_cubit.dart';

class ActivityState extends Equatable {
  const ActivityState({
    this.errorText = '',
    this.activityGenericStatus = WidgetStatus.initial,
    this.sendThreadStatus = WidgetStatus.initial,
    this.threadId = '',
    this.getThreadStatus = WidgetStatus.initial,
    this.listMessages,
    this.getMoreStatus = WidgetStatus.initial,
    this.listThreads,
  });

  // General
  final String? errorText;
  final WidgetStatus getMoreStatus;
  final WidgetStatus activityGenericStatus;

  final ListThreadsResponseModel? listThreads;

  // Chat
  final String threadId;
  final WidgetStatus sendThreadStatus;
  final WidgetStatus getThreadStatus;
  final ListMessagesResponseModel? listMessages;

  @override
  List<Object?> get props => [
    errorText,
    activityGenericStatus,
    sendThreadStatus,
    threadId,
    getThreadStatus,
    listMessages,
    getMoreStatus,
    listThreads,
  ];

  ActivityState copyWith({
    String? errorText,
    WidgetStatus? activityGenericStatus,
    WidgetStatus? sendThreadStatus,
    String? threadId,
    WidgetStatus? getThreadStatus,
    Wrapped<ListMessagesResponseModel?>? listMessages,
    WidgetStatus? getMoreStatus,
    Wrapped<ListThreadsResponseModel?>? listThreads,
  }) {
    return ActivityState(
      errorText: errorText ?? this.errorText,
      activityGenericStatus:
          activityGenericStatus ?? this.activityGenericStatus,
      sendThreadStatus: sendThreadStatus ?? this.sendThreadStatus,
      threadId: threadId ?? this.threadId,
      getThreadStatus: getThreadStatus ?? this.getThreadStatus,
      listMessages: (listMessages != null)
          ? listMessages.value
          : this.listMessages,
      getMoreStatus: getMoreStatus ?? this.getMoreStatus,
      listThreads: (listThreads != null) ? listThreads.value : this.listThreads,
    );
  }
}
