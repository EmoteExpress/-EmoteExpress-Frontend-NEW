import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:emote_express/ui/activity/cubit/cubit.dart';
import 'package:emote_express/widgets/input/search_input.dart';
import 'package:emote_express/widgets/buttons/generic_button.dart';
import 'package:emote_express/ui/survey/widgets/survey_step_1.dart';

class AssistantSearchView extends StatelessWidget {
  const AssistantSearchView({super.key});

  static const String routeName = 'assitant_search_view';

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => ActivityCubit(),
      child: Scaffold(
        appBar: AppBar(title: const Text("Select Assistant")),
        body: const SafeArea(child: _View()),
      ),
    );
  }
}

class _View extends StatelessWidget {
  const _View();

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 0, horizontal: 16),
          child: SearchInput(
            hintText: "Search",
            // textController: _controller,
            onChanged: (value) {},
          ),
        ),
        const SizedBox(height: 24),
        Expanded(
          child: GridView.builder(
            itemCount: 22,
            shrinkWrap: true,
            padding: const EdgeInsets.symmetric(vertical: 0, horizontal: 16),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 16,
              mainAxisSpacing: 16,
            ),
            itemBuilder: (context, index) {
              return BlocBuilder<ActivityCubit, ActivityState>(
                // buildWhen: (p, c) => (p.feelingSelected != c.feelingSelected),
                builder: (context, state) {
                  return SelectableOption(
                    title: "N/A",
                    // path: state.listfeelings[index].url,
                    isSelected: false,
                    //     (state.listfeelings[index].emotion ==
                    //     state.feelingSelected),
                    onPressed: () {},
                  );
                },
              );
            },
          ),
        ),
        const SizedBox(height: 24),
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 0, horizontal: 16),
          child: GenericButton(text: "Select Assistant"),
        ),
        const SizedBox(height: 24),
      ],
    );
  }
}
