import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:emote_express/utils/generic_utils.dart';
import 'package:emote_express/ui/activity/cubit/cubit.dart';
import 'package:emote_express/widgets/generic/generic.dart';
import 'package:emote_express/models/generic/generic_enums.dart';
import 'package:emote_express/core/constants/constants_colors.dart';
import 'package:emote_express/models/activity/list_messages_model.dart';
import 'package:emote_express/ui/activity/widgets/message_field_box.dart';

class AssitantChatView extends StatelessWidget {
  const AssitantChatView({super.key});

  static const String routeName = 'assitant_chat_view';

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.sizeOf(context);
    final id = ModalRoute.of(context)?.settings.arguments as String?;

    return BlocProvider(
      create: (context) => ActivityCubit()..setThread(id),
      child: Scaffold(
        appBar: AppBar(title: const Text("Chat")),
        body: SafeArea(
          child: Column(
            children: [
              Expanded(
                child: Container(
                  width: size.width,
                  color: ConstantColors.cff08080D,
                  child: _RenderMessages(),
                ),
              ),
              const MessageFieldBox(),
            ],
          ),
        ),
      ),
    );
  }
}

class _RenderMessages extends StatefulWidget {
  const _RenderMessages();

  @override
  State<_RenderMessages> createState() => _RenderMessagesState();
}

class _RenderMessagesState extends State<_RenderMessages> {
  late ActivityCubit _cubit;
  late ScrollController _scrollController;

  @override
  void initState() {
    super.initState();
    _cubit = context.read<ActivityCubit>();
    _scrollController = ScrollController();
    _cubit.getThreadMessages();

    _scrollController.addListener(() {
      double position = _scrollController.position.pixels;
      double maxExtend = _scrollController.position.maxScrollExtent;
      if ((position > maxExtend - 200)) {
        _cubit.getThreadMessages();
      }
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ActivityCubit, ActivityState>(
      buildWhen: (p, c) =>
          (p.getThreadStatus != c.getThreadStatus ||
          p.getMoreStatus != c.getMoreStatus ||
          p.listMessages != c.listMessages),
      builder: (context, state) {
        switch (state.getThreadStatus) {
          case WidgetStatus.loading:
            return const Center(child: LoadingIndicator());
          case WidgetStatus.error:
            return Center(child: GenericError(text: state.errorText));
          default:
            if (state.threadId.isEmpty) {
              return const Center(
                child: Padding(
                  padding: EdgeInsets.all(24.0),
                  child: Text(
                    "Where should we start?",
                    textAlign: TextAlign.center,
                  ),
                ),
              );
            }

            if (state.listMessages?.data?.isEmpty ?? true) {
              return const Center(
                child: Padding(
                  padding: EdgeInsets.all(24.0),
                  child: Text(
                    '''Sorry! No result found.''',
                    textAlign: TextAlign.center,
                  ),
                ),
              );
            }
            List<Widget> children = [];

            for (MessageModel? data in state.listMessages?.data ?? []) {
              children.add(_MessageComponent(data));
            }

            if (state.getMoreStatus == WidgetStatus.loading) {
              children.add(const Center(child: LoadingIndicator()));
            }

            if (state.getMoreStatus == WidgetStatus.error) {
              children.add(GenericError(text: state.errorText));
            }

            return Scrollbar(
              controller: _scrollController,
              child: ListView.separated(
                reverse: true,
                shrinkWrap: true,
                controller: _scrollController,
                itemCount: children.length,
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 12,
                ),
                itemBuilder: (_, i) => children[i],
                separatorBuilder: (_, i) => const SizedBox(height: 16),
              ),
            );
        }
      },
    );
  }
}

class _MessageComponent extends StatelessWidget {
  const _MessageComponent(this.message);

  final MessageModel? message;

  @override
  Widget build(BuildContext context) {
    // Definimos si es del usuario para reutilizar la lógica
    final isUser = message?.question ?? false;

    return Align(
      // Alinea a la derecha si es usuario, a la izquierda si no
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
        padding: const EdgeInsets.all(16),
        constraints: BoxConstraints(
          // Evita que la burbuja ocupe todo el ancho si el texto es corto
          maxWidth: MediaQuery.of(context).size.width * 0.75,
        ),
        decoration: BoxDecoration(
          color: isUser ? const Color(0xFF2D3235) : const Color(0xFF141718),
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(20),
            topRight: const Radius.circular(20),
            bottomLeft: Radius.circular(isUser ? 20 : 0),
            bottomRight: Radius.circular(isUser ? 0 : 20),
          ),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              message?.message ?? "...",
              style: const TextStyle(color: Colors.white, fontSize: 15),
            ),
            const SizedBox(height: 8),
            Align(
              alignment: Alignment.bottomRight,
              child: Text(
                message?.createdAt != null
                    ? GenericUtils.parseDate(message!.createdAt!)
                    : "",
                style: const TextStyle(fontSize: 10, color: Colors.grey),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
