import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:emote_express/utils/generic_utils.dart';
import 'package:emote_express/widgets/generic/generic.dart';
import 'package:emote_express/ui/activity/cubit/cubit.dart';
import 'package:emote_express/models/generic/generic_enums.dart';
import 'package:emote_express/widgets/dialogs/generic_dialog.dart';
import 'package:emote_express/widgets/buttons/generic_button.dart';
import 'package:emote_express/core/constants/constants_images.dart';
import 'package:emote_express/core/constants/constants_colors.dart';
import 'package:emote_express/ui/activity/views/assitant_chat_view.dart';
import 'package:emote_express/models/activity/list_threads_response_model.dart';

class BrainActivityView extends StatelessWidget {
  const BrainActivityView({super.key});

  static const String routeName = 'brain_activity_view';

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => ActivityCubit()..getThreads(),
      child: Scaffold(
        appBar: AppBar(title: const Text("Brain Activity")),
        body: SafeArea(
          child: BlocListener<ActivityCubit, ActivityState>(
            listenWhen: (p, c) =>
                (p.activityGenericStatus != c.activityGenericStatus),
            listener: (context, state) {
              switch (state.activityGenericStatus) {
                case WidgetStatus.loading:
                  showDialog<void>(
                    context: context,
                    barrierDismissible: false,
                    builder: (_) => PopScope(
                      canPop: false,
                      child: Center(child: LoadingIndicator()),
                    ),
                  );
                  break;

                case WidgetStatus.error:
                  Navigator.pop(context);
                  showDialog<void>(
                    context: context,
                    barrierDismissible: false,
                    builder: (context) => GenericDialog(
                      description: state.errorText,
                      isErrorDialog: true,
                    ),
                  );
                  break;

                case WidgetStatus.success:
                  Navigator.pop(context);
                  break;
                default:
                  break;
              }
            },
            child: const _View(),
          ),
        ),
      ),
    );
  }
}

class _View extends StatefulWidget {
  const _View();

  @override
  State<_View> createState() => _ViewState();
}

class _ViewState extends State<_View> {
  final _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(_onScroll);
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  void _onScroll() {
    final maxScroll = _scrollController.position.maxScrollExtent;
    final currentScroll = _scrollController.position.pixels;
    if (currentScroll >= (maxScroll - 300)) {
      context.read<ActivityCubit>().getMoreThreads();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.max,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: _Component(),
        ),
        const SizedBox(height: 12),
        Expanded(
          child: BlocBuilder<ActivityCubit, ActivityState>(
            buildWhen: (p, c) =>
                p.getThreadStatus != c.getThreadStatus ||
                p.getMoreStatus != c.getMoreStatus,
            builder: (context, state) {
              switch (state.getThreadStatus) {
                case WidgetStatus.loading:
                  return const Center(child: LoadingIndicator());
                case WidgetStatus.error:
                  return Center(child: GenericError(text: state.errorText));
                default:
                  if ((state.listThreads?.data ?? []).isEmpty) {
                    return const Center(
                      child: GenericError(
                        text:
                            "There are no conversations to display at this time.",
                      ),
                    );
                  }

                  return ListView.separated(
                    controller: _scrollController,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    keyboardDismissBehavior:
                        ScrollViewKeyboardDismissBehavior.onDrag,
                    itemCount:
                        (state.listThreads?.data?.length ?? 0) +
                        (state.getMoreStatus == WidgetStatus.loading ? 1 : 0),
                    itemBuilder: (context, index) {
                      if (index < state.listThreads!.data!.length) {
                        return _ThreadComponent(
                          state.listThreads!.data?[index],
                        );
                      }

                      return const Center(child: LoadingIndicator());
                    },
                    separatorBuilder: (context, index) => SizedBox(height: 8),
                  );
              }
            },
          ),
        ),
        // Padding(
        //   padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        //   child: GenericButton(
        //     text: "Search assistant",
        //     onTap: null,
        //     //() => Navigator.pushNamed(context, AssistantSearchView.routeName),
        //   ),
        // ),
      ],
    );
  }
}

class _ThreadComponent extends StatelessWidget {
  const _ThreadComponent(this.thread);

  final ThreadModel? thread;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: ListTile(
        title: Text(
          thread?.message ?? "N/A",
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontWeight: FontWeight.w400),
        ),
        subtitle: Text(
          GenericUtils.parseDate(thread?.dateMessage),
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(
            fontWeight: FontWeight.w400,
            fontSize: 14,
            color: Color(0xFFBBBCBE),
          ),
        ),
        selected: true,
        selectedTileColor: ConstantColors.cff1F2128,
        selectedColor: Colors.white,
        trailing: IconButton(
          color: Colors.red,
          icon: Icon(Icons.delete_rounded),
          visualDensity: VisualDensity.compact,
          onPressed: () =>
              context.read<ActivityCubit>().deleteThread(thread?.idThread),
        ),
        tileColor: Colors.transparent,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(8)),
        ),
        onTap: () {
          Navigator.pushNamed(
            context,
            AssitantChatView.routeName,
            arguments: thread?.idThread,
          );
        },
      ),
    );
  }
}

class _Component extends StatelessWidget {
  const _Component();

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Color(0xFF1F2128),
        borderRadius: BorderRadius.all(Radius.circular(18)),
      ),
      child: Stack(
        children: [
          SizedBox(
            height: 150,
            width: MediaQuery.of(context).size.width,
            child: Image.asset(ConstantImages.shape, fit: BoxFit.cover),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Color(0xFF2A2C33),
                    border: Border.fromBorderSide(
                      BorderSide(color: Color(0xFF32333B)),
                    ),
                  ),
                  child: Icon(
                    Icons.assistant_rounded,
                    size: 30,
                    color: ConstantColors.cffF6912E,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  "Let's see what can I do for you?",
                  style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 16),
                GenericButton(
                  text: "Start Conversation",
                  onTap: () {
                    Navigator.pushNamed(
                      context,
                      AssitantChatView.routeName,
                    ).then((value) {
                      if (!context.mounted) return;
                      context.read<ActivityCubit>().getThreads();
                    });
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
