import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:emote_express/utils/generic_utils.dart';
import 'package:emote_express/models/survey/survey.dart';
import 'package:emote_express/models/generic/wrapped.dart';
import 'package:emote_express/providers/survey_provider.dart';
import 'package:emote_express/models/generic/generic_enums.dart';

part 'survey_state.dart';

class SurveyCubit extends Cubit<SurveyState> {
  SurveyCubit() : super(const SurveyState());

  final _surveyProvider = SurveyProvider();

  void clean() => emit(const SurveyState());

  void setSurveyIndex(int value) => emit(state.copyWith(surveyIndex: value));

  // =========================================================================
  // Step 1
  // =========================================================================

  void setFeeling(String value) {
    emit(state.copyWith(feelingSelected: Wrapped.value(value)));
  }

  Future<void> getFeelingList() async {
    emit(state.copyWith(listFeelingsStatus: WidgetStatus.loading));

    final response = await _surveyProvider.getFeelingsList();

    return response.fold(
      (l) {
        emit(
          state.copyWith(
            listFeelingsStatus: WidgetStatus.error,
            errorText: l.details,
          ),
        );
      },
      (r) async {
        emit(
          state.copyWith(
            listFeelingsStatus: WidgetStatus.success,
            listfeelings: r,
          ),
        );
      },
    );
  }
  // =========================================================================
  // Step 2
  // =========================================================================

  void setEmotion(String value) {
    emit(state.copyWith(emotionSelected: Wrapped.value(value)));
  }

  void setQuery(String? value) => emit(
    state.copyWith(query: value, listEmotions: const Wrapped.value(null)),
  );

  Future<void> getEmotionList() async {
    if (state.listEmotionsStatus == WidgetStatus.loading ||
        state.moreListStatus == WidgetStatus.loading) {
      return;
    }

    late int? page;

    // Set page value
    if (state.listEmotions == null) {
      page = 1;
    } else {
      if ((state.listEmotions?.links?.next ?? "").isEmpty) return;
      page = GenericUtils.getPage(state.listEmotions!.links!.next!);
      if (page == null) return;
    }

    // Set Pagination loading
    (page == 1)
        ? emit(state.copyWith(listEmotionsStatus: WidgetStatus.loading))
        : emit(state.copyWith(moreListStatus: WidgetStatus.loading));

    final response = await _surveyProvider.getEmotionList(
      page: page,
      query: state.query,
    );

    return response.fold(
      (l) {
        // Handling error
        (page == 1)
            ? emit(
                state.copyWith(
                  listEmotionsStatus: WidgetStatus.error,
                  errorText: l.details,
                ),
              )
            : emit(
                state.copyWith(
                  moreListStatus: WidgetStatus.error,
                  errorText: l.details,
                ),
              );
      },
      (r) async {
        // Handling success
        emit(
          state.copyWith(
            listEmotionsStatus: WidgetStatus.success,
            moreListStatus: WidgetStatus.success,
            listEmotions: Wrapped.value(
              (state.listEmotions ?? ListEmotionsResponseModel()).copyWith(
                data: [...(state.listEmotions?.data ?? []), ...(r.data ?? [])],
                links: r.links,
                total: r.total,
              ),
            ),
          ),
        );
      },
    );
  }

  // =========================================================================
  // Step 3
  // =========================================================================

  void setComfortable(bool value) {
    emit(state.copyWith(isComfortable: Wrapped.value(value)));
  }

  // =========================================================================
  // Quiz
  // =========================================================================

  Future<void> setQuiz() async {
    emit(state.copyWith(quizStatus: WidgetStatus.loading));

    if (state.feelingSelected == null ||
        state.emotionSelected == null ||
        state.isComfortable == null) {
      emit(
        state.copyWith(
          quizStatus: WidgetStatus.error,
          errorText: "Null values",
        ),
      );
      throw Exception("Null values");
    }

    final response = await _surveyProvider.setQuiz(
      feeling: state.feelingSelected!,
      emotion: state.emotionSelected!,
      isComfortable: state.isComfortable!,
    );

    return response.fold(
      (l) {
        emit(
          state.copyWith(quizStatus: WidgetStatus.error, errorText: l.details),
        );
      },
      (r) async {
        emit(state.copyWith(quizStatus: WidgetStatus.success));
      },
    );
  }
}
