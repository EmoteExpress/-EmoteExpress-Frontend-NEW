part of 'survey_cubit.dart';

class SurveyState extends Equatable {
  const SurveyState({
    this.errorText = '',
    this.surveyIndex = 0,
    this.listEmotions,
    this.listEmotionsStatus = WidgetStatus.initial,
    this.feelingSelected,
    this.emotionSelected,
    this.isComfortable,
    this.quizStatus = WidgetStatus.initial,
    this.listFeelingsStatus = WidgetStatus.initial,
    this.listfeelings = const [],
    this.moreListStatus = WidgetStatus.initial,
    this.query = "",
  });

  // General
  final String? errorText;
  final int surveyIndex;

  // Step 1
  final String? feelingSelected;
  final WidgetStatus listFeelingsStatus;
  final List<FeelingResponseModel> listfeelings;

  // Step 2
  final String query;
  final String? emotionSelected;
  final WidgetStatus listEmotionsStatus;
  final WidgetStatus moreListStatus;
  final ListEmotionsResponseModel? listEmotions;

  // Step 3
  final bool? isComfortable;

  // Quiz
  final WidgetStatus quizStatus;

  @override
  List<Object?> get props => [
        errorText,
        surveyIndex,
        listEmotions,
        listEmotionsStatus,
        feelingSelected,
        emotionSelected,
        isComfortable,
        quizStatus,
        listFeelingsStatus,
        listfeelings,
        moreListStatus,
        query,
      ];

  SurveyState copyWith({
    String? errorText,
    int? surveyIndex,
    Wrapped<ListEmotionsResponseModel?>? listEmotions,
    WidgetStatus? listEmotionsStatus,
    Wrapped<String?>? feelingSelected,
    Wrapped<String?>? emotionSelected,
    Wrapped<bool?>? isComfortable,
    WidgetStatus? quizStatus,
    WidgetStatus? listFeelingsStatus,
    List<FeelingResponseModel>? listfeelings,
    WidgetStatus? moreListStatus,
    String? query,
  }) {
    return SurveyState(
      errorText: errorText ?? this.errorText,
      surveyIndex: surveyIndex ?? this.surveyIndex,
      listEmotions:
          listEmotions != null ? listEmotions.value : this.listEmotions,
      listEmotionsStatus: listEmotionsStatus ?? this.listEmotionsStatus,
      feelingSelected: feelingSelected != null
          ? feelingSelected.value
          : this.feelingSelected,
      emotionSelected: emotionSelected != null
          ? emotionSelected.value
          : this.emotionSelected,
      isComfortable:
          isComfortable != null ? isComfortable.value : this.isComfortable,
      quizStatus: quizStatus ?? this.quizStatus,
      listFeelingsStatus: listFeelingsStatus ?? this.listFeelingsStatus,
      listfeelings: listfeelings ?? this.listfeelings,
      moreListStatus: moreListStatus ?? this.moreListStatus,
      query: query ?? this.query,
    );
  }
}
