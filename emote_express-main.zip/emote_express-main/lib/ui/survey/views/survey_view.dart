import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:emote_express/ui/survey/survey.dart';
import 'package:emote_express/widgets/generic/generic.dart';
import 'package:emote_express/models/generic/generic_enums.dart';
import 'package:emote_express/widgets/dialogs/generic_dialog.dart';
import 'package:emote_express/widgets/buttons/generic_button.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';
import 'package:emote_express/core/constants/constants_colors.dart';

class SurveyView extends StatelessWidget {
  const SurveyView({super.key});

  static const String routeName = 'survey_view';

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (BuildContext context) => SurveyCubit(),
      child: BlocBuilder<SurveyCubit, SurveyState>(
        buildWhen: (p, c) => (p.surveyIndex != c.surveyIndex),
        builder: (context, state) {
          return PopScope(
            canPop: false,
            onPopInvokedWithResult: (didPop, _) {
              if (!didPop) {
                // Validando si es necesario volver al step anterior
                if (state.surveyIndex > 0) {
                  context.read<SurveyCubit>().setSurveyIndex(
                    state.surveyIndex - 1,
                  );
                } else {
                  showDialog<void>(
                    context: context,
                    barrierDismissible: false,
                    builder: (context) => const GenericDialog(
                      title: "This step is required",
                      description:
                          '''Take a quick moment to check in with yourself. '''
                          '''Logging your daily mood helps you track your '''
                          '''emotional journey over time.''',
                    ),
                  );
                }
              }
            },
            child: Scaffold(
              body: BlocConsumer<SurveyCubit, SurveyState>(
                listenWhen: (p, c) => (p.quizStatus != c.quizStatus),
                listener: (context, state) async {
                  switch (state.quizStatus) {
                    case WidgetStatus.error:
                      showDialog<void>(
                        context: context,
                        barrierDismissible: false,
                        builder: (context) => GenericDialog(
                          description: state.errorText,
                          isErrorDialog: true,
                        ),
                      );
                      break;

                    case WidgetStatus.success:
                      Navigator.pushNamedAndRemoveUntil(
                        // ignore: use_build_context_synchronously
                        context,
                        SurveyFinishedView.routeName,
                        (Route<dynamic> route) => false,
                      );
                      break;

                    default:
                      break;
                  }
                },
                buildWhen: (p, c) => (p.quizStatus != c.quizStatus),
                builder: (context, state) {
                  return Stack(
                    children: [
                      const _View(),
                      if (state.quizStatus == WidgetStatus.loading)
                        const Center(child: LoadingIndicator()),
                    ],
                  );
                },
              ),
            ),
          );
        },
      ),
    );
  }
}

class _View extends StatefulWidget {
  const _View();

  @override
  State<_View> createState() => _ViewState();
}

class _ViewState extends State<_View> {
  late SurveyCubit _cubit;

  @override
  void initState() {
    _cubit = context.read<SurveyCubit>();
    _cubit.getEmotionList();
    _cubit.getFeelingList();
    super.initState();
  }

  bool _validateStep(SurveyState state) {
    switch (state.surveyIndex) {
      case 0:
        return (state.feelingSelected != null) ? true : false;
      case 1:
        return (state.emotionSelected != null) ? true : false;
      case 2:
        return (state.isComfortable != null) ? true : false;
      default:
        return false;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const SizedBox(height: 28),
        SafeArea(
          bottom: false,
          child: BlocBuilder<SurveyCubit, SurveyState>(
            buildWhen: (p, c) => (p.surveyIndex != c.surveyIndex),
            builder: (context, state) {
              return AnimatedSmoothIndicator(
                activeIndex: state.surveyIndex,
                count: 3,
                effect: SlideEffect(
                  spacing: 8,
                  radius: 8,
                  dotWidth: ((MediaQuery.of(context).size.width * 0.7) / 3),
                  dotHeight: 12,
                  paintStyle: PaintingStyle.fill,
                  dotColor: const Color(0xFF553D05),
                  activeDotColor: ConstantColors.cffFFBE26,
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 22),
        BlocBuilder<SurveyCubit, SurveyState>(
          buildWhen: (p, c) => (p.surveyIndex != c.surveyIndex),
          builder: (context, state) {
            switch (state.surveyIndex) {
              case 0:
                return const Expanded(child: SurveyStep1());
              case 1:
                return const Expanded(child: SurveyStep2());
              case 2:
                return const Expanded(child: SurveyStep3());
              default:
                return const SizedBox.shrink();
            }
          },
        ),
        BlocBuilder<SurveyCubit, SurveyState>(
          buildWhen: (p, c) =>
              (p.surveyIndex != c.surveyIndex ||
              p.feelingSelected != c.feelingSelected ||
              p.emotionSelected != c.emotionSelected ||
              p.isComfortable != c.isComfortable),
          builder: (context, state) {
            return SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 12,
                ),
                child: GenericButton(
                  text: (state.surveyIndex == 2) ? "Finish" : "Next",
                  onTap: _validateStep(state)
                      ? () {
                          if (state.surveyIndex == 2) {
                            _cubit.setQuiz();
                            return;
                          }

                          if (state.surveyIndex < 2) {
                            _cubit.setSurveyIndex(state.surveyIndex + 1);
                          }
                        }
                      : null,
                ),
              ),
            );
          },
        ),
      ],
    );
  }
}
