import 'package:flutter/material.dart';
import 'package:emote_express/widgets/generic/generic.dart';
import 'package:emote_express/ui/home/views/home_view.dart';
import 'package:emote_express/ui/home/views/search_word_view.dart';
import 'package:emote_express/widgets/buttons/generic_button.dart';
import 'package:emote_express/core/constants/constants_images.dart';
import 'package:emote_express/widgets/dialogs/generic_dialog.dart';

class SurveyFinishedView extends StatelessWidget {
  const SurveyFinishedView({super.key});

  static const String routeName = 'survey_finished_view';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: PopScope(
        canPop: false,
        onPopInvokedWithResult: (didPop, _) {
          if (!didPop) {
            showDialog<void>(
              context: context,
              builder: (context) => GenericDialog(
                title: "Do you want to go Home?",
                description:
                    '''Your mood has been recorded. Ready to head '''
                    '''to the home screen and start your day?''',
                onAccept: () {
                  Navigator.pushNamedAndRemoveUntil(
                    context,
                    HomeView.routeName,
                    (Route<dynamic> route) => false,
                  );
                },
              ),
            );
          }
        },
        child: GenericLayout(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Image.asset(
                      ConstantImages.surveyFinished,
                      height: MediaQuery.of(context).size.height * 0.4,
                      filterQuality: FilterQuality.high,
                    ),
                    const SizedBox(height: 15),
                    const Text(
                      "Survey Completed",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 25,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 7),
                    const Text(
                      "We've checked your emotions",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontWeight: FontWeight.w600,
                        fontSize: 16,
                        color: Color(0xFF848484),
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    GenericButton(
                      text: "Express an emotion",
                      onTap: () {
                        Navigator.pushNamed(context, SearchWordView.routeName);
                      },
                    ),
                    const SizedBox(height: 24),
                    GenericButton(
                      text: "Maybe Later",
                      color: Colors.transparent,
                      onTap: () {
                        Navigator.pushNamedAndRemoveUntil(
                          context,
                          HomeView.routeName,
                          (Route<dynamic> route) => false,
                        );
                      },
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
