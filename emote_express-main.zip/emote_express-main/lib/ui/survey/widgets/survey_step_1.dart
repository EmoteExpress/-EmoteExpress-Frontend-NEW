import 'package:flutter/material.dart';
import 'package:emote_express/core/core.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:emote_express/ui/survey/survey.dart';
import 'package:emote_express/widgets/generic/generic.dart';
import 'package:emote_express/models/generic/generic_enums.dart';

class SurveyStep1 extends StatelessWidget {
  const SurveyStep1({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const SurveyTitle(title: "How are you feeling today?"),
        const SizedBox(height: 22),
        BlocBuilder<SurveyCubit, SurveyState>(
          buildWhen: (p, c) => (p.listFeelingsStatus != c.listFeelingsStatus),
          builder: (context, state) {
            switch (state.listFeelingsStatus) {
              case WidgetStatus.loading:
                return const Center(child: LoadingAnimation());
              case WidgetStatus.error:
                return Expanded(
                  child: Center(child: GenericError(text: state.errorText)),
                );
              default:
                return Expanded(
                  child: GridView.builder(
                    itemCount: state.listfeelings.length,
                    shrinkWrap: true,
                    padding: const EdgeInsets.symmetric(
                      vertical: 0,
                      horizontal: 16,
                    ),
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          crossAxisSpacing: 16,
                          mainAxisSpacing: 16,
                        ),
                    itemBuilder: (context, index) {
                      return BlocBuilder<SurveyCubit, SurveyState>(
                        buildWhen: (p, c) =>
                            (p.feelingSelected != c.feelingSelected),
                        builder: (context, state) {
                          return SelectableOption(
                            title: state.listfeelings[index].emotion ?? "N/A",
                            path: state.listfeelings[index].url,
                            isSelected:
                                (state.listfeelings[index].emotion ==
                                state.feelingSelected),
                            onPressed: () {
                              final cubit = context.read<SurveyCubit>();

                              if (state.listfeelings[index].emotion != null) {
                                cubit.setFeeling(
                                  state.listfeelings[index].emotion!,
                                );
                              }
                            },
                          );
                        },
                      );
                    },
                  ),
                );
            }
          },
        ),
      ],
    );
  }
}

class SelectableOption extends StatelessWidget {
  const SelectableOption({
    super.key,
    required this.title,
    this.path,
    required this.isSelected,
    required this.onPressed,
  });

  final String title;
  final String? path;
  final bool isSelected;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        onTap: onPressed,
        borderRadius: BorderRadius.circular(14),
        child: Ink(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: (isSelected)
                ? ConstantColors.checkboxColor
                : ConstantColors.cff1F2128,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: (isSelected)
                  ? ConstantColors.cffFFBE26
                  : const Color(0xFF4C4D56),
              width: 1,
            ),
          ),
          child: Stack(
            alignment: Alignment.center,
            children: [
              Positioned(
                top: 0,
                right: 0,
                child: Container(
                  decoration: BoxDecoration(
                    color: (isSelected)
                        ? ConstantColors.cffFFBE26
                        : const Color(0xFF12161E),
                    shape: BoxShape.circle,
                    border: Border.all(
                      width: 1,
                      color: ConstantColors.cff2D3441,
                    ),
                  ),
                  child: Icon(
                    Icons.check_rounded,
                    size: 20,
                    color: (isSelected) ? Colors.white : Colors.transparent,
                  ),
                ),
              ),
              Column(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Container(
                    width: 70,
                    height: 70,
                    padding: const EdgeInsets.all(7),
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      color: Color(0xFFB8DFF2),
                    ),
                    child: GenericNetworkImage(
                      path: path,
                      border: 0,
                      fit: BoxFit.contain,
                    ),
                  ),
                  Text(
                    title,
                    textAlign: TextAlign.center,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.w600),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
