import 'package:flutter/material.dart';
import 'package:emote_express/core/constants/constants_colors.dart';

class SurveyOption extends StatelessWidget {
  const SurveyOption(
      {super.key,
      required this.title,
      required this.isSelected,
      required this.onPressed});

  final String title;
  final bool isSelected;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(8),
      child: InkWell(
        onTap: onPressed,
        borderRadius: BorderRadius.circular(8),
        child: Ink(
          padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 10),
          decoration: BoxDecoration(
            color: ConstantColors.cff1F2128,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: (isSelected)
                  ? ConstantColors.cffFFBE26
                  : const Color(0xFF4C4D56),
              width: 1,
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Flexible(
                child: Text(
                  title,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.w600),
                ),
              ),
              Container(
                decoration: BoxDecoration(
                  color: (isSelected)
                      ? ConstantColors.cffFFBE26
                      : const Color(0xFF12161E),
                  shape: BoxShape.circle,
                  border: Border.all(width: 1, color: ConstantColors.cff2D3441),
                ),
                child: Icon(
                  Icons.circle,
                  size: 20,
                  color: (isSelected)
                      ? ConstantColors.cffFFBE26
                      : Colors.transparent,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
