import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:emote_express/ui/survey/survey.dart';
import 'package:emote_express/widgets/generic/generic.dart';
import 'package:emote_express/widgets/input/search_input.dart';
import 'package:emote_express/models/generic/generic_enums.dart';

class SurveyStep2 extends StatefulWidget {
  const SurveyStep2({super.key});

  @override
  State<SurveyStep2> createState() => _SurveyStep2State();
}

class _SurveyStep2State extends State<SurveyStep2> {
  late SurveyCubit cubit;
  late ScrollController scrollController;
  late TextEditingController queryController;

  @override
  void initState() {
    cubit = context.read<SurveyCubit>();
    scrollController = ScrollController();
    queryController = TextEditingController(text: cubit.state.query);

    scrollController.addListener(() {
      double position = scrollController.position.pixels;
      double maxExtend = scrollController.position.maxScrollExtent;
      if ((position > maxExtend - 400)) {
        cubit.getEmotionList();
      }
    });

    super.initState();
  }

  @override
  void dispose() {
    queryController.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const SurveyTitle(
          title: "Any emotion that you can identify as the constant?",
        ),
        const SizedBox(height: 22),
        BlocBuilder<SurveyCubit, SurveyState>(
            buildWhen: (p, c) => (p.query != c.query),
            builder: (context, state) {
              return Padding(
                padding:
                    const EdgeInsets.symmetric(vertical: 0, horizontal: 16),
                child: SearchInput(
                  hintText: "Search emotion",
                  textController: queryController,
                  onChanged: (value) {
                    cubit.setQuery(value);
                    cubit.getEmotionList();
                  },
                ),
              );
            }),
        const SizedBox(height: 18),
        BlocBuilder<SurveyCubit, SurveyState>(
          buildWhen: (p, c) => (p.listEmotionsStatus != c.listEmotionsStatus ||
              p.emotionSelected != c.emotionSelected ||
              p.moreListStatus != c.moreListStatus),
          builder: (context, state) {
            switch (state.listEmotionsStatus) {
              case WidgetStatus.loading:
                return const Center(child: LoadingAnimation());
              case WidgetStatus.error:
                return Expanded(
                  child: Center(child: GenericError(text: state.errorText)),
                );
              default:
                List<Widget> children = [];

                for (String? emotion in state.listEmotions?.data ?? []) {
                  children.add(SurveyOption(
                    title: emotion ?? "N/A",
                    isSelected: (emotion == state.emotionSelected),
                    onPressed: () {
                      if (emotion != null) {
                        cubit.setEmotion(emotion);
                      }
                    },
                  ));
                }

                if (state.moreListStatus == WidgetStatus.loading) {
                  children.add(const Center(child: LoadingIndicator()));
                }

                if (state.moreListStatus == WidgetStatus.error) {
                  children.add(const GenericError());
                }

                return Expanded(
                    child: ListView.separated(
                  shrinkWrap: true,
                  controller: scrollController,
                  itemCount: children.length,
                  padding:
                      const EdgeInsets.symmetric(vertical: 0, horizontal: 16),
                  itemBuilder: (context, index) => children[index],
                  separatorBuilder: (context, index) =>
                      const SizedBox(height: 18),
                ));
            }
          },
        )
      ],
    );
  }
}
