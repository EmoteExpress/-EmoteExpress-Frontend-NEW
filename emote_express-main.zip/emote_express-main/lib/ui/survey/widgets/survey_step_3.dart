import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:emote_express/ui/survey/survey.dart';

class SurveyStep3 extends StatelessWidget {
  const SurveyStep3({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const SurveyTitle(
          title: "Do you feel comfortable in your own skin today?",
        ),
        const SizedBox(height: 22),
        Expanded(
          child: BlocBuilder<SurveyCubit, SurveyState>(
              buildWhen: (p, c) => (p.isComfortable != c.isComfortable),
              builder: (context, state) {
                return ListView(
                  shrinkWrap: true,
                  padding:
                      const EdgeInsets.symmetric(vertical: 0, horizontal: 16),
                  children: [
                    SurveyOption(
                      title: "Yes",
                      isSelected: (state.isComfortable == true),
                      onPressed: () {
                        final cubit = context.read<SurveyCubit>();
                        cubit.setComfortable(true);
                      },
                    ),
                    const SizedBox(height: 18),
                    SurveyOption(
                      title: "No",
                      isSelected: (state.isComfortable == false),
                      onPressed: () {
                        final cubit = context.read<SurveyCubit>();
                        cubit.setComfortable(false);
                      },
                    ),
                  ],
                );
              }),
        ),
      ],
    );
  }
}
