part of 'posts_cubit.dart';

class PostsState extends Equatable {
  const PostsState({
    this.errorText = '',
    this.getMyPostsStatus = WidgetStatus.initial,
    this.createPostStatus = WidgetStatus.initial,
    this.description = "",
    this.postListModel,
    this.post,
    this.likes,
    this.isLiked = false,
    this.likeStatus = WidgetStatus.initial,
    this.comments,
    this.isFavorite = false,
    this.favoriteStatus = WidgetStatus.initial,
    this.feedStatus = WidgetStatus.initial,
    this.feeds,
    this.deleteStatus = WidgetStatus.initial,
    this.postToEdit,
    this.users,
    this.moreListStatus = WidgetStatus.initial,
    this.externalUserId,
    this.gender,
    this.query = "",
    this.filter,
    this.getAudiosStatus = WidgetStatus.initial,
    this.listAudios,
    this.selectedAudio,
  });

  // General
  final String query;
  final String errorText;
  final int? externalUserId;
  final WidgetStatus moreListStatus;
  final WidgetStatus deleteStatus;
  final PostResponseModel? post;

  // Favorites
  final bool isFavorite;
  final WidgetStatus favoriteStatus;

  // Likes
  final int? likes;
  final bool isLiked;
  final WidgetStatus likeStatus;
  final ListUsersResponseModel? users;

  // Comments
  final int? comments;

  // Profile Posts
  final WidgetStatus getMyPostsStatus;
  final ListPostsResponseModel? postListModel;

  // Create or Edit a Post
  final String description;
  final PostResponseModel? postToEdit;
  final WidgetStatus createPostStatus;

  // Feed
  final WidgetStatus feedStatus;
  final ListRecommendedEmotionsResponseModel? feeds;

  // Face & Gallery
  final Gender? gender;

  // Follower and following users list
  final String? filter;

  // Audios
  final WidgetStatus getAudiosStatus;
  final ListAudiosResponseModel? listAudios;
  final AudioModel? selectedAudio;

  @override
  List<Object?> get props => [
    errorText,
    getMyPostsStatus,
    createPostStatus,
    description,
    postListModel,
    post,
    likes,
    isLiked,
    likeStatus,
    comments,
    isFavorite,
    favoriteStatus,
    feedStatus,
    feeds,
    deleteStatus,
    postToEdit,
    users,
    moreListStatus,
    externalUserId,
    gender,
    query,
    filter,
    getAudiosStatus,
    listAudios,
    selectedAudio,
  ];

  PostsState copyWith({
    String? errorText,
    WidgetStatus? getMyPostsStatus,
    WidgetStatus? createPostStatus,
    String? description,
    Wrapped<ListPostsResponseModel?>? postListModel,
    Wrapped<PostResponseModel?>? post,
    Wrapped<int?>? likes,
    bool? isLiked,
    WidgetStatus? likeStatus,
    Wrapped<int?>? comments,
    bool? isFavorite,
    WidgetStatus? favoriteStatus,
    WidgetStatus? feedStatus,
    Wrapped<ListRecommendedEmotionsResponseModel?>? feeds,
    WidgetStatus? deleteStatus,
    Wrapped<PostResponseModel?>? postToEdit,
    Wrapped<ListUsersResponseModel?>? users,
    WidgetStatus? moreListStatus,
    Wrapped<int?>? externalUserId,
    Wrapped<Gender?>? gender,
    String? query,
    Wrapped<String?>? filter,
    WidgetStatus? getAudiosStatus,
    Wrapped<ListAudiosResponseModel?>? listAudios,
    Wrapped<AudioModel?>? selectedAudio,
  }) {
    return PostsState(
      errorText: errorText ?? this.errorText,
      getMyPostsStatus: getMyPostsStatus ?? this.getMyPostsStatus,
      createPostStatus: createPostStatus ?? this.createPostStatus,
      description: description ?? this.description,
      postListModel: postListModel != null
          ? postListModel.value
          : this.postListModel,
      post: post != null ? post.value : this.post,
      likes: likes != null ? likes.value : this.likes,
      isLiked: isLiked ?? this.isLiked,
      likeStatus: likeStatus ?? this.likeStatus,
      comments: comments != null ? comments.value : this.comments,
      isFavorite: isFavorite ?? this.isFavorite,
      favoriteStatus: favoriteStatus ?? this.favoriteStatus,
      feedStatus: feedStatus ?? this.feedStatus,
      feeds: feeds != null ? feeds.value : this.feeds,
      deleteStatus: deleteStatus ?? this.deleteStatus,
      postToEdit: postToEdit != null ? postToEdit.value : this.postToEdit,
      users: users != null ? users.value : this.users,
      moreListStatus: moreListStatus ?? this.moreListStatus,
      externalUserId: externalUserId != null
          ? externalUserId.value
          : this.externalUserId,
      gender: gender != null ? gender.value : this.gender,
      query: query ?? this.query,
      filter: filter != null ? filter.value : this.filter,
      getAudiosStatus: getAudiosStatus ?? this.getAudiosStatus,
      listAudios: listAudios != null ? listAudios.value : this.listAudios,
      selectedAudio: selectedAudio != null
          ? selectedAudio.value
          : this.selectedAudio,
    );
  }
}
