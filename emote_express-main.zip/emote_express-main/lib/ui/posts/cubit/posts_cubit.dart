import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:emote_express/models/posts/posts.dart';
import 'package:emote_express/utils/generic_utils.dart';
import 'package:emote_express/models/generic/generic.dart';
import 'package:emote_express/providers/post_provider.dart';

part 'posts_state.dart';

class PostsCubit extends Cubit<PostsState> {
  PostsCubit() : super(const PostsState());

  final _postProvider = PostProvider();

  // External Profile Posts
  void setExternalProfileUserId(int? value) =>
      emit(state.copyWith(externalUserId: Wrapped.value(value)));

  void setPostDescription(String? value) =>
      emit(state.copyWith(description: value));

  void setPostToEdit(PostResponseModel? post) {
    if (post == null) return;
    emit(
      state.copyWith(
        postToEdit: Wrapped.value(post),
        description: post.dataPost?.description,
      ),
    );
  }

  void updateComments(int value) =>
      emit(state.copyWith(comments: Wrapped.value(value)));

  // Query de busquedas
  void setQuery(String value) => emit(state.copyWith(query: value));

  // Filtro para listado de usuarios de seguidores y seguidos
  void setFilter(String value) =>
      emit(state.copyWith(filter: Wrapped.value(value)));

  // =========================================================================
  // Posts
  // =========================================================================

  Future<void> createPost({
    required String emotion,
    required String url,
  }) async {
    if (state.createPostStatus == WidgetStatus.loading) return;
    emit(state.copyWith(createPostStatus: WidgetStatus.loading));

    final response = await _postProvider.createPost(
      emotion: emotion,
      url: url,
      description: state.description,
      audio: state.selectedAudio,
    );

    return response.fold(
      (l) {
        emit(
          state.copyWith(
            createPostStatus: WidgetStatus.error,
            errorText: l.details,
          ),
        );
      },
      (r) async {
        emit(state.copyWith(createPostStatus: WidgetStatus.success));
      },
    );
  }

  // Get posts from my profile or external profile
  Future<void> getPosts() async {
    if (state.getMyPostsStatus == WidgetStatus.loading ||
        state.moreListStatus == WidgetStatus.loading) {
      return;
    }

    late int? page;

    // Set page value
    if (state.postListModel == null) {
      page = 1;
    } else {
      if ((state.postListModel?.links?.next ?? "").isEmpty) return;
      page = GenericUtils.getPage(state.postListModel!.links!.next!);
      if (page == null) return;
    }

    // Set Pagination loading
    (page == 1)
        ? emit(state.copyWith(getMyPostsStatus: WidgetStatus.loading))
        : emit(state.copyWith(moreListStatus: WidgetStatus.loading));

    final response = await _postProvider.getPosts(
      page: page,
      userId: state.externalUserId,
    );

    return response.fold(
      (l) {
        // Handling error
        (page == 1)
            ? emit(
                state.copyWith(
                  getMyPostsStatus: WidgetStatus.error,
                  errorText: l.details,
                ),
              )
            : emit(
                state.copyWith(
                  moreListStatus: WidgetStatus.error,
                  errorText: l.details,
                ),
              );
      },
      (r) {
        // Handling success
        emit(
          state.copyWith(
            getMyPostsStatus: WidgetStatus.success,
            moreListStatus: WidgetStatus.success,
            postListModel: Wrapped.value(
              (state.postListModel ?? ListPostsResponseModel()).copyWith(
                data: [...(state.postListModel?.data ?? []), ...(r.data ?? [])],
                dataUser: r.dataUser,
                links: r.links,
                total: r.total,
              ),
            ),
          ),
        );
      },
    );
  }

  Future<void> getPost(int? id) async {
    if (id == null) return;
    if (state.getMyPostsStatus == WidgetStatus.loading) return;
    emit(state.copyWith(getMyPostsStatus: WidgetStatus.loading));

    final response = await _postProvider.getPost(id);

    return response.fold(
      (l) {
        emit(
          state.copyWith(
            getMyPostsStatus: WidgetStatus.error,
            errorText: l.details,
          ),
        );
      },
      (r) {
        emit(
          state.copyWith(
            getMyPostsStatus: WidgetStatus.success,
            post: Wrapped.value(r),
            likes: Wrapped.value(r.dataPost?.totalLikes),
            comments: Wrapped.value(r.dataPost?.totalComments),
            isLiked: r.dataPost?.isLiked,
            isFavorite: r.dataPost?.isFavorite,
          ),
        );
      },
    );
  }

  // Actualizacion local de las variables del post para seguidores y seguidos
  Future<void> updateLocalProfile() async {
    if (state.moreListStatus == WidgetStatus.loading) return;
    emit(state.copyWith(moreListStatus: WidgetStatus.loading));

    final response = await _postProvider.getPosts(userId: state.externalUserId);

    return response.fold(
      (l) {
        emit(
          state.copyWith(
            moreListStatus: WidgetStatus.error,
            errorText: l.details,
          ),
        );
      },
      (r) {
        emit(
          state.copyWith(
            moreListStatus: WidgetStatus.success,
            postListModel: Wrapped.value(
              (state.postListModel ?? ListPostsResponseModel()).copyWith(
                dataUser: r.dataUser,
              ),
            ),
          ),
        );
      },
    );
  }

  Future<void> likePost() async {
    if (state.post?.dataPost?.id == null) return;
    if (state.deleteStatus == WidgetStatus.loading) return;
    if (state.likeStatus == WidgetStatus.loading) return;
    emit(state.copyWith(likeStatus: WidgetStatus.loading));

    final response = await _postProvider.toggleLikePost(
      state.post!.dataPost!.id!,
    );

    return response.fold(
      (l) {
        emit(
          state.copyWith(likeStatus: WidgetStatus.error, errorText: l.details),
        );
      },
      (r) {
        emit(
          state.copyWith(
            likeStatus: WidgetStatus.success,
            isLiked: !state.isLiked,
            likes: (state.isLiked)
                ? Wrapped.value((state.likes ?? 0) - 1)
                : Wrapped.value((state.likes ?? 0) + 1),
          ),
        );
      },
    );
  }

  Future<void> addPostToFavorites() async {
    if (state.post?.dataPost?.id == null) return;
    if (state.deleteStatus == WidgetStatus.loading) return;
    if (state.favoriteStatus == WidgetStatus.loading) return;
    emit(state.copyWith(favoriteStatus: WidgetStatus.loading));

    final response = await _postProvider.toggleFavoritePost(
      state.post!.dataPost!.id!,
    );

    return response.fold(
      (l) {
        emit(
          state.copyWith(
            favoriteStatus: WidgetStatus.error,
            errorText: l.details,
          ),
        );
      },
      (r) {
        emit(
          state.copyWith(
            favoriteStatus: WidgetStatus.success,
            isFavorite: !state.isFavorite,
          ),
        );
      },
    );
  }

  Future<void> deletePost(int? id) async {
    if (state.deleteStatus == WidgetStatus.loading || id == null) return;
    emit(state.copyWith(deleteStatus: WidgetStatus.loading));

    final response = await _postProvider.deletePost(id);

    return response.fold(
      (l) {
        emit(
          state.copyWith(
            deleteStatus: WidgetStatus.error,
            errorText: l.details,
          ),
        );
      },
      (r) {
        emit(state.copyWith(deleteStatus: WidgetStatus.success));
      },
    );
  }

  Future<void> editPost() async {
    if (state.postToEdit?.dataPost?.id == null) return;
    if (state.createPostStatus == WidgetStatus.loading) return;
    emit(state.copyWith(createPostStatus: WidgetStatus.loading));

    final response = await _postProvider.updatePost(
      id: state.postToEdit!.dataPost!.id!,
      url: state.postToEdit!.dataPost!.url!,
      description: state.description,
    );

    return response.fold(
      (l) {
        emit(
          state.copyWith(
            createPostStatus: WidgetStatus.error,
            errorText: l.details,
          ),
        );
      },
      (r) {
        emit(state.copyWith(createPostStatus: WidgetStatus.success));
      },
    );
  }

  // Follow or unfollow a user
  Future<void> followUser({
    required int? userId,
    required bool? currentFollowValue,
  }) async {
    if (userId == null || currentFollowValue == null) return;
    if (state.favoriteStatus == WidgetStatus.loading) return;
    emit(state.copyWith(favoriteStatus: WidgetStatus.loading));

    final response = await _postProvider.followUser(userId: userId);

    return response.fold(
      (l) => emit(
        state.copyWith(
          favoriteStatus: WidgetStatus.error,
          errorText: l.details,
        ),
      ),
      (r) {
        // Actualizando estado desde una publicacion
        if (state.post != null) {
          emit(
            state.copyWith(
              favoriteStatus: WidgetStatus.success,
              post: Wrapped.value(
                state.post?.copyWith(
                  dataUser: state.post?.dataUser?.copyWith(
                    alreadyFollow: !currentFollowValue,
                  ),
                ),
              ),
            ),
          );
        }

        // Actualizando estado desde listado de perfiles (Seguidores y Seguidos)
        if ((state.users?.data ?? []).isNotEmpty) {
          final newList = [...state.users!.data!];

          final index = newList.indexWhere((e) => (e.id == userId));

          newList[index] = newList[index].copyWith(
            alreadyFollow: !currentFollowValue,
            followers: (currentFollowValue)
                ? ((newList[index].followers ?? 0) - 1)
                : ((newList[index].followers ?? 0) + 1),
          );

          emit(
            state.copyWith(
              favoriteStatus: WidgetStatus.success,
              users: Wrapped.value(state.users!.copyWith(data: newList)),
            ),
          );
        }
      },
    );
  }

  // TODO integrar paginado
  Future<void> getProfileFollowers() async {
    if (state.externalUserId == null) return;
    if (state.likeStatus == WidgetStatus.loading) return;
    emit(state.copyWith(likeStatus: WidgetStatus.loading));

    final response = await _postProvider.getProfileFollowers(
      query: state.query,
      userId: state.externalUserId!,
      isFollowers: (state.filter?.toLowerCase() == "followers") ? true : false,
    );

    return response.fold(
      (l) {
        emit(
          state.copyWith(likeStatus: WidgetStatus.error, errorText: l.details),
        );
      },
      (r) {
        emit(
          state.copyWith(
            likeStatus: WidgetStatus.success,
            users: Wrapped.value(r),
          ),
        );
      },
    );
  }

  // TODO integrar paginado
  Future<void> getLikes(int? id) async {
    if (id == null) return;
    if (state.likeStatus == WidgetStatus.loading) return;
    emit(state.copyWith(likeStatus: WidgetStatus.loading));

    final response = await _postProvider.getLikes(id: id);

    return response.fold(
      (l) {
        emit(
          state.copyWith(likeStatus: WidgetStatus.error, errorText: l.details),
        );
      },
      (r) {
        emit(
          state.copyWith(
            likeStatus: WidgetStatus.success,
            users: Wrapped.value(r),
          ),
        );
      },
    );
  }

  // TODO integrar paginado
  Future<void> getFavoritePosts() async {
    if (state.getMyPostsStatus == WidgetStatus.loading) return;
    emit(state.copyWith(getMyPostsStatus: WidgetStatus.loading));

    final response = await _postProvider.getFavorites();

    return response.fold(
      (l) {
        emit(
          state.copyWith(
            getMyPostsStatus: WidgetStatus.error,
            errorText: l.details,
          ),
        );
      },
      (r) {
        emit(
          state.copyWith(
            getMyPostsStatus: WidgetStatus.success,
            postListModel: Wrapped.value(r),
          ),
        );
      },
    );
  }

  // =========================================================================
  // Feed
  // =========================================================================

  Future<void> getFeeds() async {
    if (state.feedStatus == WidgetStatus.loading ||
        state.moreListStatus == WidgetStatus.loading) {
      return;
    }

    late int? page;

    // Set page value
    if (state.feeds == null) {
      page = 1;
    } else {
      if ((state.feeds?.links?.next ?? "").isEmpty) return;
      page = GenericUtils.getPage(state.feeds!.links!.next!);
      if (page == null) return;
    }

    // Set Pagination loading
    (page == 1)
        ? emit(state.copyWith(feedStatus: WidgetStatus.loading))
        : emit(state.copyWith(moreListStatus: WidgetStatus.loading));

    final response = await _postProvider.getFeed(
      page: page,
      gender: state.gender,
    );

    return response.fold(
      (l) {
        // Handling error
        (page == 1)
            ? emit(
                state.copyWith(
                  feedStatus: WidgetStatus.error,
                  errorText: l.details,
                ),
              )
            : emit(
                state.copyWith(
                  moreListStatus: WidgetStatus.error,
                  errorText: l.details,
                ),
              );
      },
      (r) async {
        // Handling success
        emit(
          state.copyWith(
            feedStatus: WidgetStatus.success,
            moreListStatus: WidgetStatus.success,
            feeds: Wrapped.value(
              (state.feeds ?? ListRecommendedEmotionsResponseModel()).copyWith(
                data: [...(state.feeds?.data ?? []), ...(r.data ?? [])],
                links: r.links,
                total: r.total,
              ),
            ),
          ),
        );
      },
    );
  }

  // =========================================================================
  // Face & Gallery
  // =========================================================================

  void setGender(Gender? value) {
    if (value == null) return;
    emit(state.copyWith(gender: Wrapped.value(value)));
  }

  // =========================================================================
  // Audios
  // =========================================================================

  void setAudio(AudioModel? value) =>
      emit(state.copyWith(selectedAudio: Wrapped.value(value)));

  Future<void> getAudios() async {
    if (state.getAudiosStatus == WidgetStatus.loading) return;
    emit(
      state.copyWith(
        getAudiosStatus: WidgetStatus.loading,
        listAudios: Wrapped.value(null),
      ),
    );

    final resp = await _postProvider.getAudios(query: state.query);

    resp.fold(
      (l) {
        emit(
          state.copyWith(
            errorText: l.details,
            getAudiosStatus: WidgetStatus.error,
          ),
        );
      },
      (r) {
        emit(
          state.copyWith(
            listAudios: Wrapped.value(r),
            getAudiosStatus: WidgetStatus.success,
          ),
        );
      },
    );
  }

  Future<void> getMoreAudios() async {
    final nextPage = GenericUtils.getPage(state.listAudios?.links?.next ?? "");
    if (state.moreListStatus == WidgetStatus.loading || nextPage == null) {
      return;
    }

    emit(state.copyWith(moreListStatus: WidgetStatus.loading));

    final response = await _postProvider.getAudios(
      query: state.query,
      page: nextPage,
    );

    response.fold(
      (l) => emit(state.copyWith(moreListStatus: WidgetStatus.error)),
      (r) {
        final currentList = state.listAudios?.data ?? [];
        final newList = [...currentList, ...r.data];

        emit(
          state.copyWith(
            moreListStatus: WidgetStatus.success,
            listAudios: Wrapped.value(r.copyWith(data: newList)),
          ),
        );
      },
    );
  }
}
