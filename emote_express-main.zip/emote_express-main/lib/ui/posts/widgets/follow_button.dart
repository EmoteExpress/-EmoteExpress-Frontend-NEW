import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:emote_express/ui/cubit/cubit.dart';
import 'package:emote_express/core/constants/constants_colors.dart';

class FollowButton extends StatelessWidget {
  const FollowButton({
    super.key,
    required this.userId,
    required this.isFollowing,
    this.onPressed,
  });

  final int? userId; // id del usuario al que se va a seguir o dejar de seguir.
  final bool? isFollowing; // variable que indica si ya seguimos al usuario.
  final VoidCallback? onPressed;

  @override
  Widget build(BuildContext context) {
    // Obteniendo el id del usuario autenticado.
    final loggeUserId = context.select(
      (GeneralCubit generalCubit) =>
          generalCubit.state.homeResponseModel?.dataUser?.id,
    );

    // Verificado que el usuario no sea el autenticado
    final isNotMe = (userId != null && loggeUserId != userId);

    // Validando si es posible mostrar el boton
    final canShowButton = (isNotMe && isFollowing != null);

    if (!canShowButton) return SizedBox.shrink();

    return TextButton.icon(
      icon: Icon(
        (isFollowing!) ? Icons.done_all_rounded : Icons.person_add_rounded,
      ),
      iconAlignment: IconAlignment.end,
      onPressed: onPressed,
      style: ButtonStyle(
        backgroundColor: WidgetStatePropertyAll(
          (onPressed == null)
              ? Colors.grey
              : (isFollowing!)
              ? Colors.white
              : ConstantColors.cffF6912E,
        ),
        foregroundColor: (onPressed == null)
            ? null
            : WidgetStatePropertyAll(
                (isFollowing!) ? ConstantColors.cff111114 : Colors.white,
              ),
        shape: WidgetStatePropertyAll(
          RoundedRectangleBorder(
            borderRadius: BorderRadiusGeometry.all(Radius.circular(4)),
          ),
        ),
      ),
      label: Text((isFollowing!) ? "Following" : "Follow"),
    );
  }
}
