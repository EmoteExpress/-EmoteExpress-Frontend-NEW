import 'package:flutter/material.dart';
import 'package:emote_express/core/constants/constants_colors.dart';
import 'package:emote_express/models/posts/post_response_model.dart';

class SelectedAudioComponent extends StatelessWidget {
  const SelectedAudioComponent({
    super.key,
    this.audio,
    required this.trailing,
    required this.onPressed,
  });

  final AudioModel? audio;
  final Widget trailing;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: ListTile(
        title: Text(
          audio?.name ?? "N/A",
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontWeight: FontWeight.w600),
        ),
        subtitle: Text(
          audio?.id.toString() ?? "N/A",
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontSize: 14, color: Color(0xFFBBBCBE)),
        ),
        selected: true,
        selectedTileColor: ConstantColors.cffF6912E,
        selectedColor: Colors.white,
        trailing: trailing,
        tileColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(8)),
          side: BorderSide(color: Colors.white),
        ),
        onTap: onPressed,
      ),
    );
  }
}
