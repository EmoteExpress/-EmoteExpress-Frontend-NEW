import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:emote_express/ui/posts/posts.dart';
import 'package:emote_express/widgets/generic/generic.dart';
import 'package:emote_express/models/generic/generic_enums.dart';
import 'package:emote_express/core/constants/constants_colors.dart';

class PostUserInformationComponent extends StatelessWidget {
  const PostUserInformationComponent({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 24),
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
      decoration: const BoxDecoration(
        color: ConstantColors.checkboxColor,
        borderRadius: BorderRadius.all(Radius.circular(8)),
      ),
      child: BlocBuilder<PostsCubit, PostsState>(
        buildWhen: (p, c) => (p.getMyPostsStatus != c.getMyPostsStatus),
        builder: (context, state) {
          if (state.getMyPostsStatus == WidgetStatus.success) {
            return GestureDetector(
              onTap: () {
                // Navigation to External Profile
                if (state.post?.dataPost?.ownPost == false) {
                  Navigator.push<void>(
                    context,
                    MaterialPageRoute(
                      builder: (context) =>
                          PostsView(userId: state.post?.dataUser?.id),
                    ),
                  );
                }
              },
              child: const _RenderComponent(),
            );
          } else {
            return const _LoadingPlaceholder();
          }
        },
      ),
    );
  }
}

class _LoadingPlaceholder extends StatelessWidget {
  const _LoadingPlaceholder();

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.max,
      children: [
        const GenericNetworkImage(
          size: 50,
          border: 100,
          defaultIcon: Icons.person_rounded,
        ),
        const SizedBox(width: 12),
        Flexible(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: double.infinity,
                decoration: const BoxDecoration(
                  color: Colors.grey,
                  borderRadius: BorderRadius.all(Radius.circular(8)),
                ),
                child: const Text(
                  "",
                  style: TextStyle(fontWeight: FontWeight.w600),
                ),
              ),
              const SizedBox(height: 6),
              Container(
                width: double.infinity,
                decoration: const BoxDecoration(
                  color: Colors.blueGrey,
                  borderRadius: BorderRadius.all(Radius.circular(8)),
                ),
                child: const Text(
                  "",
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: Color(0xFFA9A9A9),
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _RenderComponent extends StatelessWidget {
  const _RenderComponent();

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<PostsCubit, PostsState>(
      buildWhen: (p, c) => (p.post != c.post),
      builder: (context, state) {
        return Row(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Flexible(
              child: Row(
                children: [
                  GenericNetworkImage(
                    path: state.post?.dataUser?.url,
                    size: 50,
                    border: 100,
                  ),
                  const SizedBox(width: 12),
                  Flexible(
                    child: Column(
                      spacing: 6,
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          state.post?.dataUser?.name ?? "N/A",
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontWeight: FontWeight.w600),
                        ),
                        LastWordComponent(
                          word: state.post?.dataUser?.lastEmotion,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            if (state.post?.dataPost?.ownPost == true) ...[
              const SizedBox(width: 12),
              const _OptionsButton(),
            ],

            if (state.post?.dataPost?.ownPost == false) ...[
              const SizedBox(width: 12),
              BlocBuilder<PostsCubit, PostsState>(
                buildWhen: (p, c) =>
                    (p.post?.dataUser?.alreadyFollow !=
                    c.post?.dataUser?.alreadyFollow),
                builder: (context, state) {
                  return FollowButton(
                    userId: state.post?.dataUser?.id,
                    isFollowing: state.post!.dataUser!.alreadyFollow!,
                    onPressed: () {
                      context.read<PostsCubit>().followUser(
                        userId: state.post?.dataUser?.id,
                        currentFollowValue: state.post?.dataUser?.alreadyFollow,
                      );
                    },
                  );
                },
              ),
            ],
          ],
        );
      },
    );
  }
}

class _OptionsButton extends StatelessWidget {
  const _OptionsButton();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(8),
      decoration: const BoxDecoration(
        color: ConstantColors.cff1F2128,
        borderRadius: BorderRadius.all(Radius.circular(8)),
      ),
      child: PopupMenuButton<int>(
        offset: const Offset(10, 40),
        padding: const EdgeInsets.symmetric(vertical: 12),
        color: ConstantColors.checkboxColor,
        shape: const RoundedRectangleBorder(
          side: BorderSide(color: Color(0xFF222428)),
          borderRadius: BorderRadius.all(Radius.circular(8)),
        ),
        onSelected: (value) {
          final cubit = context.read<PostsCubit>();
          switch (value) {
            case 1:
              Navigator.push<void>(
                context,
                MaterialPageRoute(
                  builder: (context) => CreatePostView(post: cubit.state.post),
                ),
              );
              break;
            case 2:
              cubit.deletePost(cubit.state.post?.dataPost?.id);
              break;
            default:
              break;
          }
        },
        itemBuilder: (BuildContext context) {
          return [
            const PopupMenuItem(
              value: 1,
              padding: EdgeInsets.symmetric(horizontal: 12),
              labelTextStyle: WidgetStatePropertyAll(
                TextStyle(color: Colors.white, fontWeight: FontWeight.w500),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.edit_rounded, color: Colors.white),
                  SizedBox(width: 10),
                  Text('Edit'),
                ],
              ),
            ),
            const PopupMenuItem(
              value: 2,
              padding: EdgeInsets.symmetric(horizontal: 12),
              labelTextStyle: WidgetStatePropertyAll(
                TextStyle(
                  color: Color(0xFFCC2229),
                  fontWeight: FontWeight.w500,
                ),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.delete_rounded, color: Color(0xFFCC2229)),
                  SizedBox(width: 10),
                  Text('Delete'),
                ],
              ),
            ),
          ];
        },
        child: const Icon(Icons.pending_outlined, color: Colors.white),
      ),
    );
  }
}
