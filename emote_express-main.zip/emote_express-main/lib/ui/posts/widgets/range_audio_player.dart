import 'dart:async';

import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:emote_express/widgets/generic/loading_indicator.dart';

class RangeAudioPlayer extends StatefulWidget {
  const RangeAudioPlayer({
    super.key,
    required this.url,
    required this.startSecond,
    this.endSecond,
  });

  final String url;
  final int startSecond;
  final int? endSecond;

  @override
  State<RangeAudioPlayer> createState() => _RangeAudioPlayerState();
}

class _RangeAudioPlayerState extends State<RangeAudioPlayer> {
  late AudioPlayer _player;
  StreamSubscription? _positionSubscription;

  @override
  void initState() {
    super.initState();
    _player = AudioPlayer();
    _initPlayer();
  }

  @override
  void didUpdateWidget(RangeAudioPlayer oldWidget) {
    super.didUpdateWidget(oldWidget);
    // Si la URL cambia, recargamos el audio
    if (oldWidget.url != widget.url) {
      _initPlayer();
    }
  }

  Future<void> _initPlayer() async {
    try {
      await _player.stop();
      await _player.setUrl(widget.url);

      // Cancelamos suscripción previa si existe para evitar duplicados
      await _positionSubscription?.cancel();

      // Escuchamos la posición para detenerlo si pasa el endSecond
      _positionSubscription = _player.positionStream.listen((position) {
        // Calculamos el final: prioridad al widget, si no, la duración total
        final end = Duration(
          seconds: widget.endSecond ?? _player.duration?.inSeconds ?? 0,
        );

        if (position.inSeconds >= end.inSeconds) {
          _player.pause();
          _player.seek(Duration(seconds: widget.startSecond));
        }
      });
    } catch (e) {
      debugPrint("Error cargando audio: $e");
    }
  }

  @override
  void dispose() {
    _positionSubscription?.cancel();
    _player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<PlayerState>(
      stream: _player.playerStateStream,
      builder: (context, snapshot) {
        final playerState = snapshot.data;
        final isPlaying = playerState?.playing ?? false;
        final processingState = playerState?.processingState;

        if (processingState == ProcessingState.loading ||
            processingState == ProcessingState.buffering) {
          return const SizedBox(
            width: 24,
            height: 24,
            child: LoadingIndicator(),
          );
        }

        return IconButton(
          color: Colors.white,
          icon: Icon(isPlaying ? Icons.pause : Icons.play_arrow),
          onPressed: () {
            if (isPlaying) {
              _player.pause();
            } else {
              // Si está fuera del rango (al final o muy atrás), resetear al inicio del clip
              if (_player.position.inSeconds >=
                      (widget.endSecond ?? _player.duration!.inSeconds) ||
                  _player.position.inSeconds < widget.startSecond) {
                _player.seek(Duration(seconds: widget.startSecond));
              }
              _player.play();
            }
          },
        );
      },
    );
  }
}
