import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:emote_express/core/constants/constants.dart';
import 'package:emote_express/ui/posts/cubit/posts_cubit.dart';
import 'package:emote_express/ui/posts/views/post_likes_view.dart';
import 'package:emote_express/ui/posts/widgets/range_audio_player.dart';
import 'package:emote_express/ui/comments/views/post_comments_view.dart';

class PostActionsComponent extends StatelessWidget {
  const PostActionsComponent({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 2, horizontal: 10),
      decoration: const BoxDecoration(
        color: ConstantColors.checkboxColor,
        borderRadius: BorderRadius.all(Radius.circular(40)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.max,
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          BlocBuilder<PostsCubit, PostsState>(
            buildWhen: (p, c) => (p.isLiked != c.isLiked),
            builder: (context, state) {
              return Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    onPressed: () => context.read<PostsCubit>().likePost(),
                    color: Colors.white,
                    icon: Icon(
                      (state.isLiked)
                          ? Icons.favorite_rounded
                          : Icons.favorite_border_rounded,
                      color: (state.isLiked)
                          ? ConstantColors.cffF6912E
                          : Colors.white,
                    ),
                  ),
                  const SizedBox(width: 2),
                  Flexible(
                    child: GestureDetector(
                      onTap: () {
                        Navigator.push<void>(
                          context,
                          MaterialPageRoute(
                            builder: (context) =>
                                PostLikesView(id: state.post?.dataPost?.id),
                          ),
                        );
                      },
                      child: Text(
                        (state.likes != null) ? "${state.likes}" : "N/A",
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontWeight: FontWeight.w700,
                          color: ConstantColors.white,
                        ),
                      ),
                    ),
                  ),
                ],
              );
            },
          ),

          BlocBuilder<PostsCubit, PostsState>(
            buildWhen: (p, c) => (p.comments != c.comments),
            builder: (context, state) {
              return Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    onPressed: () async {
                      await Navigator.push<int?>(
                        context,
                        MaterialPageRoute(
                          builder: (context) =>
                              PostCommentsView(id: state.post?.dataPost?.id),
                        ),
                      ).then((value) {
                        if (value is int) {
                          if (!context.mounted) return;
                          context.read<PostsCubit>().updateComments(value);
                        }
                      });
                    },
                    color: Colors.white,
                    icon: const Icon(Icons.chat_bubble_outline_rounded),
                  ),
                  const SizedBox(width: 2),
                  Flexible(
                    child: Text(
                      state.comments.toString(),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontWeight: FontWeight.w700,
                        color: ConstantColors.white,
                      ),
                    ),
                  ),
                ],
              );
            },
          ),

          BlocBuilder<PostsCubit, PostsState>(
            buildWhen: (p, c) => (p.isFavorite != c.isFavorite),
            builder: (context, state) {
              return IconButton(
                onPressed: () =>
                    context.read<PostsCubit>().addPostToFavorites(),
                color: Colors.white,
                icon: Icon(
                  (state.isFavorite)
                      ? Icons.bookmark_rounded
                      : Icons.bookmark_border_rounded,
                ),
              );
            },
          ),

          if (context.read<PostsCubit>().state.post?.dataPost?.audio != null)
            BlocBuilder<PostsCubit, PostsState>(
              buildWhen: (p, c) =>
                  (p.post?.dataPost?.audio != c.post?.dataPost?.audio),
              builder: (context, state) {
                if ((state.post?.dataPost?.audio?.url ?? "").isEmpty) {
                  return SizedBox.shrink();
                }

                return RangeAudioPlayer(
                  url: state.post!.dataPost!.audio!.url!,
                  startSecond: state.post?.dataPost?.audio?.initSecond ?? 0,
                  endSecond: state.post?.dataPost?.audio?.endSecond,
                );
              },
            ),
        ],
      ),
    );
  }
}
