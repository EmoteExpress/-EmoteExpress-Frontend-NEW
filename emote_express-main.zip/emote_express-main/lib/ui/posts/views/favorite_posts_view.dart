import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:emote_express/ui/posts/posts.dart';
import 'package:emote_express/widgets/generic/generic.dart';
import 'package:emote_express/models/generic/generic_enums.dart';
import 'package:emote_express/ui/home/widgets/emotion_image.dart';

class FavoritePostsView extends StatelessWidget {
  const FavoritePostsView({super.key});

  static const String routeName = 'favorite_posts_view';

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (BuildContext context) => PostsCubit()..getFavoritePosts(),
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: AppBar(
          title: const Text("Favorite Posts"),
        ),
        body: const _View(),
      ),
    );
  }
}

class _View extends StatelessWidget {
  const _View();

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<PostsCubit, PostsState>(
      buildWhen: (p, c) => (p.getMyPostsStatus != c.getMyPostsStatus),
      builder: (context, state) {
        switch (state.getMyPostsStatus) {
          case WidgetStatus.loading:
            return const Center(child: LoadingAnimation());
          case WidgetStatus.error:
            return Center(child: GenericError(text: state.errorText));
          default:
            if ((state.postListModel?.data ?? []).isEmpty) {
              return const Center(
                child: GenericError(
                  text: '''Your saved posts are waiting to be filled '''
                      '''with your favorite content. What will you save first?''',
                ),
              );
            }

            return GridView.builder(
              shrinkWrap: true,
              itemCount: state.postListModel?.data?.length,
              padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 20),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 16,
                crossAxisSpacing: 16,
                childAspectRatio: 0.8,
              ),
              itemBuilder: (context, index) {
                return EmotionImage(
                  path: state.postListModel?.data?[index].url,
                  profileUrl: state.postListModel?.data?[index].profileUrl,
                  text: state.postListModel?.data?[index].emotion,
                  onPressed: () async {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => PostView(
                          emotion: state.postListModel?.data?[index],
                        ),
                      ),
                    );
                  },
                );
              },
            );
        }
      },
    );
  }
}
