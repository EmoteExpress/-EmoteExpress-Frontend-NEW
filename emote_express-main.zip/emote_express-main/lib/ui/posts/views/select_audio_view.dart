import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:emote_express/ui/posts/cubit/cubit.dart';
import 'package:emote_express/models/generic/generic.dart';
import 'package:emote_express/widgets/generic/generic.dart';
import 'package:emote_express/widgets/input/search_input.dart';
import 'package:emote_express/core/constants/constants_colors.dart';
import 'package:emote_express/models/posts/post_response_model.dart';
import 'package:emote_express/widgets/modals/configure_audio_modal.dart';
import 'package:emote_express/models/posts/list_audios_response_model.dart';
import 'package:emote_express/ui/posts/widgets/selected_audio_component.dart';

class SelectAudioView extends StatelessWidget {
  const SelectAudioView({super.key});

  static const String routeName = 'select_audio_view';

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => PostsCubit()..getAudios(),
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: AppBar(title: const Text("Add Sound")),
        body: SafeArea(
          child: Stack(
            alignment: Alignment.bottomCenter,
            children: [
              _RenderView(),
              BlocBuilder<PostsCubit, PostsState>(
                buildWhen: (p, c) => (p.selectedAudio != c.selectedAudio),
                builder: (context, state) {
                  if (state.selectedAudio == null) return SizedBox.shrink();

                  return Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 20,
                      vertical: 20,
                    ),
                    child: SelectedAudioComponent(
                      audio: state.selectedAudio,
                      trailing: IconButton(
                        iconSize: 32,
                        icon: Icon(Icons.arrow_circle_right_outlined),
                        onPressed: () {
                          // Devuelve a la vista del formulario el audio seleccionado.
                          Navigator.pop(context, state.selectedAudio);
                        },
                      ),
                      onPressed: () async {
                        FocusScope.of(context).unfocus();
                        FocusManager.instance.primaryFocus?.unfocus();

                        // Abre el modal para visualizar el audio seleccionado
                        // final result =
                        //     await showModalBottomSheet<Map<String, dynamic>>(
                        //       context: context,
                        //       useSafeArea: true,
                        //       isScrollControlled: true,
                        //       showDragHandle: true,
                        //       backgroundColor: ConstantColors.cff111114,
                        //       shape: const RoundedRectangleBorder(
                        //         borderRadius: BorderRadius.only(
                        //           topLeft: Radius.circular(20),
                        //           topRight: Radius.circular(20),
                        //         ),
                        //       ),

                        //       builder: (BuildContext ctx) {
                        //         return DraggableScrollableSheet(
                        //           expand: false,
                        //           initialChildSize: 0.7,
                        //           maxChildSize: 0.8,
                        //           minChildSize: 0.4,
                        //           builder: (_, scrollController) {
                        //             return ConfigureAudioModal(
                        //               audio: state.selectedAudio,
                        //               scrollController: scrollController,
                        //             );
                        //           },
                        //         );
                        //       },
                        //     );
                      },
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _RenderView extends StatefulWidget {
  const _RenderView();

  @override
  State<_RenderView> createState() => _RenderViewState();
}

class _RenderViewState extends State<_RenderView> {
  final _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(_onScroll);
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  void _onScroll() {
    final maxScroll = _scrollController.position.maxScrollExtent;
    final currentScroll = _scrollController.position.pixels;
    if (currentScroll >= (maxScroll - 300)) {
      context.read<PostsCubit>().getMoreAudios();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.max,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 0, horizontal: 16),
          child: SearchInput(
            hintText: "Search sound",
            onChanged: (value) {
              context.read<PostsCubit>().setQuery(value ?? "");
              context.read<PostsCubit>().getAudios();
            },
          ),
        ),
        const SizedBox(height: 24),
        Expanded(
          child: BlocBuilder<PostsCubit, PostsState>(
            buildWhen: (p, c) =>
                p.getAudiosStatus != c.getAudiosStatus ||
                p.moreListStatus != c.moreListStatus ||
                p.listAudios != c.listAudios,
            builder: (context, state) {
              switch (state.getAudiosStatus) {
                case WidgetStatus.loading:
                  return const Center(child: LoadingIndicator());
                case WidgetStatus.error:
                  return Center(child: GenericError(text: state.errorText));
                default:
                  if ((state.listAudios?.data ?? []).isEmpty) {
                    return const Center(
                      child: GenericError(text: "No audios found."),
                    );
                  }

                  return ListView.separated(
                    controller: _scrollController,
                    itemCount:
                        (state.listAudios?.data.length ?? 0) +
                        (state.moreListStatus == WidgetStatus.loading ? 1 : 0),
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    keyboardDismissBehavior:
                        ScrollViewKeyboardDismissBehavior.onDrag,
                    itemBuilder: (context, index) {
                      if (index < state.listAudios!.data.length) {
                        return _AudioCard(state.listAudios!.data[index]);
                      }

                      return const Center(child: LoadingIndicator());
                    },
                    separatorBuilder: (context, index) => SizedBox(height: 8),
                  );
              }
            },
          ),
        ),
      ],
    );
  }
}

class _AudioCard extends StatelessWidget {
  const _AudioCard(this.audio);

  final GalleryAudioModel? audio;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: ListTile(
        title: Text(
          audio?.cleanName ?? "N/A",
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontWeight: FontWeight.w400),
        ),
        subtitle: Text(
          audio?.id.toString() ?? "N/A",
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(
            fontWeight: FontWeight.w400,
            fontSize: 14,
            color: Color(0xFFBBBCBE),
          ),
        ),
        selected: true,
        selectedTileColor: ConstantColors.cff1F2128,
        selectedColor: Colors.white,
        trailing: Icon(Icons.arrow_forward_ios_rounded, size: 16),
        leading: Icon(Icons.music_note),
        tileColor: Colors.transparent,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(8)),
        ),
        onTap: () async {
          FocusScope.of(context).unfocus();
          FocusManager.instance.primaryFocus?.unfocus();

          final result = await showModalBottomSheet<AudioModel>(
            context: context,
            useSafeArea: true,
            isScrollControlled: true,
            showDragHandle: true,
            backgroundColor: ConstantColors.cff111114,
            shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            ),

            builder: (BuildContext ctx) {
              return DraggableScrollableSheet(
                expand: false,
                initialChildSize: 0.7,
                maxChildSize: 0.8,
                minChildSize: 0.4,
                builder: (_, scrollController) {
                  return ConfigureAudioModal(
                    audio: audio,
                    scrollController: scrollController,
                  );
                },
              );
            },
          );

          if (result != null && context.mounted) {
            context.read<PostsCubit>().setAudio(result);
          }
        },
      ),
    );
  }
}
