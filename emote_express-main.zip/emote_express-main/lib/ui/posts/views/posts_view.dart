import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:emote_express/ui/posts/posts.dart';
import 'package:emote_express/widgets/generic/generic.dart';
import 'package:emote_express/models/generic/generic_enums.dart';
import 'package:emote_express/ui/home/widgets/emotion_image.dart';
import 'package:emote_express/ui/calendar/views/calendar_view.dart';
import 'package:emote_express/models/generic/emotion_response_model.dart';

class PostsView extends StatelessWidget {
  const PostsView({super.key, this.userId});

  static const String routeName = 'posts_view';

  // External Profile id
  final int? userId;

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => PostsCubit()
        ..setExternalProfileUserId(userId)
        ..getPosts(),
      child: Scaffold(
        appBar: AppBar(
          title: const Text("Posts"),
          actions: [
            (userId == null)
                ? IconButton(
                    onPressed: () {
                      Navigator.pushNamed(context, CalendarView.routeName);
                    },
                    icon: const Icon(Icons.calendar_month_rounded),
                  )
                : const SizedBox.shrink(),
            (userId == null)
                ? IconButton(
                    onPressed: () {
                      Navigator.pushNamed(context, FavoritePostsView.routeName);
                    },
                    icon: const Icon(Icons.bookmark_rounded),
                  )
                : const SizedBox.shrink(),
          ],
        ),
        body: const SafeArea(child: _View()),
      ),
    );
  }
}

class _View extends StatefulWidget {
  const _View();

  @override
  State<_View> createState() => _ViewState();
}

class _ViewState extends State<_View> {
  late PostsCubit cubit;
  late ScrollController scrollController;

  @override
  void initState() {
    cubit = context.read<PostsCubit>();
    scrollController = ScrollController();

    cubit.getPosts();

    scrollController.addListener(() {
      double position = scrollController.position.pixels;
      double maxExtend = scrollController.position.maxScrollExtent;
      if ((position > maxExtend - 400)) {
        cubit.getPosts();
      }
    });

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        BlocBuilder<PostsCubit, PostsState>(
          buildWhen: (p, c) =>
              (p.postListModel?.dataUser != c.postListModel?.dataUser),
          builder: (context, state) {
            return Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    spacing: 12,
                    mainAxisSize: MainAxisSize.max,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: _AccountStatComponent(
                          title: "Followers",
                          value: state.postListModel?.dataUser?.followers,
                        ),
                      ),
                      ProfileImageComponent(
                        path: state.postListModel?.dataUser?.url,
                      ),
                      Expanded(
                        child: _AccountStatComponent(
                          title: "Following",
                          value: state.postListModel?.dataUser?.followed,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  state.postListModel?.dataUser?.name ?? "...",
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 8),
                BlocBuilder<PostsCubit, PostsState>(
                  buildWhen: (p, c) =>
                      (p.getMyPostsStatus != c.getMyPostsStatus),
                  builder: (context, state) {
                    return LastWordComponent(
                      word: (state.getMyPostsStatus == WidgetStatus.loading)
                          ? ''
                          : state.postListModel?.dataUser?.lastEmotion,
                    );
                  },
                ),
              ],
            );
          },
        ),
        const SizedBox(height: 5),
        BlocBuilder<PostsCubit, PostsState>(
          buildWhen: (p, c) =>
              (p.getMyPostsStatus != c.getMyPostsStatus ||
              p.moreListStatus != c.moreListStatus),
          builder: (context, state) {
            switch (state.getMyPostsStatus) {
              case WidgetStatus.loading:
                return const Expanded(child: Center(child: LoadingAnimation()));
              case WidgetStatus.error:
                return Expanded(
                  child: Center(child: GenericError(text: state.errorText)),
                );
              default:
                if ((state.postListModel?.data ?? []).isEmpty) {
                  return const Expanded(
                    child: Center(
                      child: GenericError(
                        text:
                            '''Looks like your profile is a bit empty! '''
                            '''Start filling it up by creating your '''
                            '''first post.''',
                      ),
                    ),
                  );
                }

                List<Widget> children = [];

                for (EmotionResponseModel? post
                    in state.postListModel?.data ?? []) {
                  children.add(
                    EmotionImage(
                      path: post?.url,
                      text: post?.emotion,
                      onPressed: () async {
                        await Navigator.push<bool?>(
                          context,
                          MaterialPageRoute(
                            builder: (context) => PostView(emotion: post),
                          ),
                        ).then((isPostRemoved) {
                          if (isPostRemoved == true) {
                            if (!context.mounted) return;
                            context.read<PostsCubit>().getPosts();
                          }
                        });
                      },
                    ),
                  );
                }

                if (state.moreListStatus == WidgetStatus.loading) {
                  children.add(const Center(child: LoadingIndicator()));
                }

                if (state.moreListStatus == WidgetStatus.error) {
                  children.add(const GenericError());
                }

                return Expanded(
                  // TODO el reload no funciona (si el widget no es scrolleable)
                  child: RefreshIndicator(
                    onRefresh: () => context.read<PostsCubit>().getPosts(),
                    child: GridView.builder(
                      shrinkWrap: true,
                      controller: scrollController,
                      itemCount: children.length,
                      padding: const EdgeInsets.symmetric(
                        vertical: 16,
                        horizontal: 16,
                      ),
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 3,
                            crossAxisSpacing: 8,
                            mainAxisSpacing: 8,
                            childAspectRatio: 0.8,
                          ),
                      itemBuilder: (context, index) => children[index],
                    ),
                  ),
                );
            }
          },
        ),
      ],
    );
  }
}

class _AccountStatComponent extends StatelessWidget {
  const _AccountStatComponent({required this.title, required this.value});

  final String title;
  final int? value;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () async {
        final userId = context
            .read<PostsCubit>()
            .state
            .postListModel
            ?.dataUser
            ?.id;

        final value = await Navigator.pushNamed(
          context,
          UsersListView.routeName,
          arguments: [title, userId],
        );

        if (value == true && context.mounted) {
          context.read<PostsCubit>().updateLocalProfile();
        }
      },
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text(
            (value == null) ? "--" : value.toString(),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(fontSize: 27, fontWeight: FontWeight.w700),
          ),
          Text(
            title,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(fontSize: 12, color: Color(0xFFA9A9A9)),
          ),
        ],
      ),
    );
  }
}
