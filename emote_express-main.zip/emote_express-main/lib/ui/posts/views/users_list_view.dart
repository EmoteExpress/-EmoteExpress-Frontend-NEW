import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:emote_express/ui/cubit/cubit.dart';
import 'package:emote_express/ui/posts/cubit/cubit.dart';
import 'package:emote_express/widgets/generic/generic.dart';
import 'package:emote_express/ui/posts/views/posts_view.dart';
import 'package:emote_express/widgets/input/search_input.dart';
import 'package:emote_express/models/generic/generic_enums.dart';
import 'package:emote_express/widgets/dialogs/generic_dialog.dart';
import 'package:emote_express/ui/posts/widgets/follow_button.dart';
import 'package:emote_express/models/generic/user_detail_response_model.dart';

// Followers and following list
class UsersListView extends StatelessWidget {
  const UsersListView({super.key});

  static const String routeName = 'users_list_view';

  @override
  Widget build(BuildContext context) {
    // [0] Following or Followers filter
    // [1] user id
    final values = ModalRoute.of(context)?.settings.arguments as List?;

    return BlocProvider(
      create: (context) => PostsCubit()
        ..setFilter(values?.firstOrNull)
        ..setExternalProfileUserId(values?.lastOrNull)
        ..getProfileFollowers(),
      child: Scaffold(
        appBar: AppBar(title: Text(values?.firstOrNull.toString() ?? "N/A")),
        body: SafeArea(
          child: BlocListener<PostsCubit, PostsState>(
            listenWhen: (p, c) => (p.favoriteStatus != c.favoriteStatus),
            listener: (context, state) {
              switch (state.favoriteStatus) {
                case WidgetStatus.loading:
                  showDialog<void>(
                    context: context,
                    barrierDismissible: false,
                    builder: (_) => PopScope(
                      canPop: false,
                      child: Center(child: LoadingIndicator()),
                    ),
                  );
                  break;

                case WidgetStatus.error:
                  Navigator.pop(context);
                  showDialog<void>(
                    context: context,
                    barrierDismissible: false,
                    builder: (context) => GenericDialog(
                      description: state.errorText,
                      isErrorDialog: true,
                    ),
                  );
                  break;

                case WidgetStatus.success:
                  Navigator.pop(context);
                  break;

                default:
                  break;
              }
            },
            child: const _View(),
          ),
        ),
      ),
    );
  }
}

class _View extends StatelessWidget {
  const _View();

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        PopScope(
          canPop: false,
          onPopInvokedWithResult: (didPop, result) async {
            if (didPop) return;
            final needRefresh =
                (context.read<PostsCubit>().state.favoriteStatus ==
                WidgetStatus.success);

            Navigator.of(context).pop(needRefresh);
          },
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 0, horizontal: 16),
            child: SearchInput(
              hintText: "Search user",
              // textController: _controller,
              onChanged: (value) {
                context.read<PostsCubit>().setQuery(value ?? "");
                context.read<PostsCubit>().getProfileFollowers();
              },
            ),
          ),
        ),
        Expanded(
          child: BlocBuilder<PostsCubit, PostsState>(
            buildWhen: (p, c) => (p.likeStatus != c.likeStatus),
            builder: (context, state) {
              switch (state.likeStatus) {
                case WidgetStatus.loading:
                  return const Center(child: LoadingAnimation());
                case WidgetStatus.error:
                  return Center(child: GenericError(text: state.errorText));
                default:
                  if ((state.users?.data ?? []).isEmpty) {
                    return const Center(
                      child: GenericError(text: '''List Empty.'''),
                    );
                  }

                  return BlocBuilder<PostsCubit, PostsState>(
                    buildWhen: (p, c) => (p.users != c.users),
                    builder: (context, state) {
                      return ListView.separated(
                        shrinkWrap: true,
                        itemCount: state.users?.data?.length ?? 0,
                        padding: const EdgeInsets.symmetric(
                          horizontal: 20,
                          vertical: 24,
                        ),
                        itemBuilder: (context, index) =>
                            _UserComponent(state.users?.data?[index]),
                        separatorBuilder: (context, index) =>
                            SizedBox(height: 15),
                      );
                    },
                  );
              }
            },
          ),
        ),
      ],
    );
  }
}

class _UserComponent extends StatelessWidget {
  const _UserComponent(this.user);

  final UserDetailResponseModel? user;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        final myId = context
            .read<GeneralCubit>()
            .state
            .homeResponseModel
            ?.dataUser
            ?.id;
        // Navigation to External Profile
        if (myId != (user?.id ?? -1)) {
          Navigator.push<void>(
            context,
            MaterialPageRoute(
              builder: (context) => PostsView(userId: user?.id),
            ),
          );
        }
      },
      child: Row(
        spacing: 12,
        mainAxisSize: MainAxisSize.max,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Flexible(
            child: Row(
              spacing: 8,
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                GenericNetworkImage(
                  path: user?.url,
                  size: 60,
                  border: 8,
                  fit: BoxFit.contain,
                ),
                Flexible(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        user?.name ?? "N/A",
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      Text("${user?.followers} follower(s)"),
                    ],
                  ),
                ),
              ],
            ),
          ),
          FollowButton(
            userId: user?.id,
            isFollowing: user?.alreadyFollow,
            onPressed: () {
              context.read<PostsCubit>().followUser(
                userId: user?.id,
                currentFollowValue: user?.alreadyFollow,
              );
            },
          ),
        ],
      ),
    );
  }
}
