import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:emote_express/ui/posts/posts.dart';
import 'package:emote_express/utils/generic_utils.dart';
import 'package:emote_express/widgets/generic/generic.dart';
import 'package:emote_express/core/constants/constants.dart';
import 'package:emote_express/models/generic/generic_enums.dart';
import 'package:emote_express/ui/home/widgets/emotion_image.dart';
import 'package:emote_express/widgets/dialogs/generic_dialog.dart';
import 'package:emote_express/ui/home/views/search_word_view.dart';
import 'package:emote_express/models/generic/emotion_response_model.dart';

class PostView extends StatelessWidget {
  const PostView({super.key, this.emotion});

  static const String routeName = 'post_view';

  final EmotionResponseModel? emotion;

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => PostsCubit()..getPost(emotion?.postId),
      child: Scaffold(
        extendBodyBehindAppBar: true,
        appBar: AppBar(title: Text(emotion?.emotion ?? "N/A")),
        body: Stack(
          children: [
            GenericNetworkImage(
              border: 0,
              opacity: 0.5,
              path: emotion?.url,
              height: MediaQuery.of(context).size.height * 0.30,
              width: MediaQuery.of(context).size.width,
            ),
            const _View(),
            BlocConsumer<PostsCubit, PostsState>(
              listenWhen: (p, c) => (p.deleteStatus != c.deleteStatus),
              listener: (context, state) {
                switch (state.deleteStatus) {
                  case WidgetStatus.error:
                    showDialog<void>(
                      context: context,
                      barrierDismissible: false,
                      builder: (context) => GenericDialog(
                        description: state.errorText,
                        isErrorDialog: true,
                      ),
                    );
                    break;
                  case WidgetStatus.success:
                    showDialog<void>(
                      context: context,
                      barrierDismissible: false,
                      builder: (context) => PopScope(
                        canPop: false,
                        child: GenericDialog(
                          title: "Post Deleted",
                          description:
                              "Your post has been successfully deleted.",
                          onAccept: () {
                            Navigator.pop(context);
                            Navigator.pop<bool>(context, true);
                          },
                        ),
                      ),
                    );
                    break;
                  default:
                    break;
                }
              },
              buildWhen: (p, c) => (p.deleteStatus != c.deleteStatus),
              builder: (context, state) {
                return (state.deleteStatus == WidgetStatus.loading)
                    ? const Center(child: LoadingIndicator())
                    : const SizedBox.shrink();
              },
            ),
          ],
        ),
      ),
    );
  }
}

class _View extends StatelessWidget {
  const _View();

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(
          margin: EdgeInsets.only(
            top: MediaQuery.of(context).size.height * 0.25,
          ),
          decoration: const BoxDecoration(
            color: ConstantColors.cff08080D,
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(15),
              topRight: Radius.circular(15),
            ),
          ),
          child: BlocBuilder<PostsCubit, PostsState>(
            buildWhen: (p, c) => (p.getMyPostsStatus != c.getMyPostsStatus),
            builder: (context, state) {
              switch (state.getMyPostsStatus) {
                case WidgetStatus.loading:
                  return const Center(child: LoadingIndicator());
                case WidgetStatus.error:
                  return Center(child: GenericError(text: state.errorText));
                default:
                  return const _PostContent();
              }
            },
          ),
        ),
        BlocBuilder<PostsCubit, PostsState>(
          buildWhen: (p, c) => (p.likeStatus != c.likeStatus),
          builder: (context, state) {
            switch (state.likeStatus) {
              case WidgetStatus.loading:
                return const Positioned(
                  top: 0,
                  right: 20,
                  child: SafeArea(
                    child: SizedBox(
                      width: 20,
                      height: 20,
                      child: LoadingIndicator(),
                    ),
                  ),
                );
              default:
                return const SizedBox.shrink();
            }
          },
        ),
        BlocBuilder<PostsCubit, PostsState>(
          buildWhen: (p, c) => (p.favoriteStatus != c.favoriteStatus),
          builder: (context, state) {
            switch (state.favoriteStatus) {
              case WidgetStatus.loading:
                return const Positioned(
                  top: 0,
                  right: 20,
                  child: SafeArea(
                    child: SizedBox(
                      width: 20,
                      height: 20,
                      child: LoadingIndicator(),
                    ),
                  ),
                );
              default:
                return const SizedBox.shrink();
            }
          },
        ),
        Container(
          margin: EdgeInsets.only(
            top: MediaQuery.of(context).size.height * 0.20,
          ),
          child: const Column(
            mainAxisSize: MainAxisSize.min,
            children: [PostUserInformationComponent()],
          ),
        ),
      ],
    );
  }
}

class _PostContent extends StatelessWidget {
  const _PostContent();

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<PostsCubit, PostsState>(
      buildWhen: (p, c) => (p.post != c.post),
      builder: (context, state) {
        return ListView(
          padding: const EdgeInsets.fromLTRB(24, 50, 24, 24),
          children: [
            Text(
              state.post?.dataPost?.emotion ?? "N/A",
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 10),
            Text(
              state.post?.dataPost?.description ?? "N/A",
              style: const TextStyle(
                color: ConstantColors.white,
                fontWeight: FontWeight.w300,
              ),
            ),
            const SizedBox(height: 15),
            Row(
              spacing: 8,
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(
                  Icons.calendar_today_rounded,
                  color: Colors.white,
                  size: 20,
                ),
                Text(
                  "${GenericUtils.parseDate(state.post?.dataPost?.createdAt)} ${(state.post?.dataPost?.updated == true) ? "(Edited)" : ""}",
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Color(0xFFA9A9A9),
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 15),
            if (state.post?.dataPost?.audio != null) ...[
              Row(
                spacing: 8,
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(Icons.music_note_rounded, color: Colors.white, size: 20),
                  Flexible(
                    child: Text(
                      state.post?.dataPost?.audio?.name ?? "Unknown name",
                      style: const TextStyle(
                        color: Color(0xFFA9A9A9),
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 15),
            ],
            const PostActionsComponent(),
            const SizedBox(height: 15),
            const Text(
              "Similar Words...",
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 15),
            GridView.builder(
              itemCount: state.post?.tagsEmotions?.length ?? 0,
              shrinkWrap: true,
              padding: const EdgeInsets.all(0),
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                mainAxisSpacing: 8,
                crossAxisSpacing: 8,
                childAspectRatio: 2.2,
              ),
              itemBuilder: (context, index) {
                return _SimilarWord(
                  text: state.post?.tagsEmotions?[index],
                  onPressed: () {
                    Navigator.push<void>(
                      context,
                      MaterialPageRoute(
                        builder: (context) => SearchWordView(
                          query: state.post?.tagsEmotions?[index],
                        ),
                      ),
                    );
                  },
                );
              },
            ),
            const SizedBox(height: 15),
            const Text(
              "Emotions of other users",
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 15),
            GridView.builder(
              itemCount: state.post?.recommended?.length ?? 0,
              shrinkWrap: true,
              padding: const EdgeInsets.all(0),
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 16,
                crossAxisSpacing: 16,
                childAspectRatio: 0.8,
              ),
              itemBuilder: (context, index) {
                return EmotionImage(
                  path: state.post?.recommended?[index].url,
                  text: state.post?.recommended?[index].emotion,
                  profileUrl: state.post?.recommended?[index].profileUrl,
                  onPressed: () {
                    Navigator.push<void>(
                      context,
                      MaterialPageRoute(
                        builder: (context) =>
                            PostView(emotion: state.post?.recommended?[index]),
                      ),
                    );
                  },
                );
              },
            ),
          ],
        );
      },
    );
  }
}

class _SimilarWord extends StatelessWidget {
  const _SimilarWord({this.text, this.onPressed});

  final String? text;
  final VoidCallback? onPressed;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onPressed,
      child: Container(
        alignment: Alignment.center,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        decoration: const BoxDecoration(
          color: ConstantColors.checkboxColor,
          borderRadius: BorderRadius.all(Radius.circular(8)),
        ),
        child: Text(
          text ?? "N/A",
          textAlign: TextAlign.center,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontWeight: FontWeight.w700),
        ),
      ),
    );
  }
}
