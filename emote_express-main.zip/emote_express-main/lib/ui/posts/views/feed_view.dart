import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:emote_express/ui/posts/posts.dart';
import 'package:emote_express/widgets/generic/generic.dart';
import 'package:emote_express/models/generic/generic_enums.dart';
import 'package:emote_express/ui/home/widgets/emotion_image.dart';
import 'package:emote_express/models/generic/emotion_response_model.dart';

class FeedView extends StatelessWidget {
  const FeedView({super.key, this.gender});

  static const String routeName = 'feed_view';

  // Face & Gallery
  final Gender? gender;

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => PostsCubit()..setGender(gender),
      child: Scaffold(
        appBar: AppBar(
          title: (gender != null)
              ? const Text("Face & Gallery")
              : const Text("Feed"),
        ),
        body: const _View(),
      ),
    );
  }
}

class _View extends StatefulWidget {
  const _View();

  @override
  State<_View> createState() => _ViewState();
}

class _ViewState extends State<_View> {
  late PostsCubit cubit;
  late ScrollController scrollController;

  @override
  void initState() {
    cubit = context.read<PostsCubit>();
    scrollController = ScrollController();

    cubit.getFeeds();

    scrollController.addListener(() {
      double position = scrollController.position.pixels;
      double maxExtend = scrollController.position.maxScrollExtent;
      if ((position > maxExtend - 400)) {
        cubit.getFeeds();
      }
    });

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<PostsCubit, PostsState>(
      buildWhen: (p, c) => (p.feedStatus != c.feedStatus ||
          p.moreListStatus != c.moreListStatus),
      builder: (context, state) {
        switch (state.feedStatus) {
          case WidgetStatus.loading:
            return const Center(child: LoadingAnimation());
          case WidgetStatus.error:
            return Center(child: GenericError(text: state.errorText));
          default:
            if ((state.feeds?.data ?? []).isEmpty) {
              return const Center(
                child: GenericError(
                  text: "There are no posts to display at this time.",
                ),
              );
            }

            List<Widget> children = [];

            for (EmotionResponseModel feed in state.feeds?.data ?? []) {
              children.add(EmotionImage(
                path: feed.url,
                text: feed.emotion,
                profileUrl: feed.profileUrl,
                onPressed: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => PostView(emotion: feed),
                      ));
                },
              ));
            }

            if (state.moreListStatus == WidgetStatus.loading) {
              children.add(const Center(child: LoadingIndicator()));
            }

            if (state.moreListStatus == WidgetStatus.error) {
              children.add(const GenericError());
            }

            return GridView.builder(
              shrinkWrap: true,
              controller: scrollController,
              itemCount: children.length,
              padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 20),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 16,
                crossAxisSpacing: 16,
                childAspectRatio: 0.8,
              ),
              itemBuilder: (context, index) => children[index],
            );
        }
      },
    );
  }
}
