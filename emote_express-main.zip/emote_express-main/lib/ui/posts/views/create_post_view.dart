import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:emote_express/ui/posts/posts.dart';
import 'package:emote_express/widgets/generic/generic.dart';
import 'package:emote_express/models/generic/generic_enums.dart';
import 'package:emote_express/widgets/buttons/generic_button.dart';
import 'package:emote_express/widgets/dialogs/generic_dialog.dart';
import 'package:emote_express/core/constants/constants_colors.dart';
import 'package:emote_express/models/posts/post_response_model.dart';
import 'package:emote_express/widgets/input/generic_form_input.dart';
import 'package:emote_express/models/generic/emotion_response_model.dart';

// Create or Edit a Post
class CreatePostView extends StatelessWidget {
  const CreatePostView({super.key, this.emotion, this.post});

  static const String routeName = 'create_post_view';

  /// Data to create a Post
  final EmotionResponseModel? emotion;

  /// Data to edit a Post
  final PostResponseModel? post;

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => PostsCubit()..setPostToEdit(post),
      child: Scaffold(
        appBar: AppBar(
          title: (post != null)
              ? const Text("Edit Post")
              : const Text("Create Post"),
        ),
        body: BlocListener<PostsCubit, PostsState>(
          listenWhen: (p, c) => (p.createPostStatus != c.createPostStatus),
          listener: (context, state) {
            switch (state.createPostStatus) {
              case WidgetStatus.loading:
                showDialog<void>(
                  context: context,
                  barrierDismissible: false,
                  builder: (_) => PopScope(
                    canPop: false,
                    child: Center(child: LoadingIndicator()),
                  ),
                );
                break;

              case WidgetStatus.error:
                Navigator.pop(context);
                showDialog<void>(
                  context: context,
                  barrierDismissible: false,
                  builder: (context) => GenericDialog(
                    description: state.errorText,
                    isErrorDialog: true,
                  ),
                );
                break;

              case WidgetStatus.success:
                Navigator.pop(context);

                // Creating Post Case
                if (emotion != null) {
                  showDialog<void>(
                    context: context,
                    barrierDismissible: false,
                    builder: (context) => GenericDialog(
                      title: "Post created successfully!",
                      description:
                          '''We're excited to see your latest post! '''
                          '''It's now available for everyone to read. Thanks '''
                          '''for sharing your thoughts with us.''',
                      onAccept: () {
                        Navigator.pop(context);
                        Navigator.pop(context);
                      },
                    ),
                  );
                }

                // Editin Post Case
                if (state.postToEdit != null) {
                  showDialog<void>(
                    context: context,
                    barrierDismissible: false,
                    builder: (context) => GenericDialog(
                      title: "Post updated successfully!",
                      description:
                          '''We've successfully updated your post with your'''
                          '''latest changes. You can now '''
                          '''view the updated post.''',
                      onAccept: () {
                        Navigator.popUntil(
                          context,
                          ModalRoute.withName(PostsView.routeName),
                        );
                      },
                    ),
                  );
                }

                break;
              default:
                break;
            }
          },
          child: GenericLayout(child: _View(emotion)),
        ),
      ),
    );
  }
}

class _View extends StatelessWidget {
  const _View(this.emotion);

  final EmotionResponseModel? emotion;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.max,
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        BlocBuilder<PostsCubit, PostsState>(
          buildWhen: (p, c) => (p.postToEdit != c.postToEdit),
          builder: (context, state) {
            return Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                children: [
                  Text(
                    state.postToEdit?.dataPost?.emotion ??
                        emotion?.emotion ??
                        "N/A",
                    style: const TextStyle(
                      fontSize: 27,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 16),
                  GenericNetworkImage(
                    path: state.postToEdit?.dataPost?.url ?? emotion?.url,
                    border: 8,
                    width: double.infinity,
                    height: MediaQuery.of(context).size.height * 0.3,
                    sizeDefaultIcon: 70,
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    "Express what you feel",
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                  ),
                  const SizedBox(height: 16),
                  GenericFormInput(
                    maxLines: 5,
                    minLines: 5,
                    textController: (emotion != null)
                        ? null
                        : TextEditingController(
                            text: state.postToEdit?.dataPost?.description,
                          ),
                    hintText: "Express what you feel",
                    textInputType: TextInputType.multiline,
                    textInputAction: TextInputAction.newline,
                    textCapitalization: TextCapitalization.sentences,
                    onChanged: (value) =>
                        context.read<PostsCubit>().setPostDescription(value),
                  ),
                  const SizedBox(height: 16),
                  BlocBuilder<PostsCubit, PostsState>(
                    buildWhen: (p, c) => (p.selectedAudio != c.selectedAudio),
                    builder: (context, state) {
                      // Por el momento no se permitirá la edición del audio
                      // de una publicacion
                      if (state.postToEdit != null) return SizedBox.shrink();

                      if (state.selectedAudio != null) {
                        return ListTile(
                          title: Text(
                            state.selectedAudio?.name ?? "N/A",
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontWeight: FontWeight.w400),
                          ),
                          selected: true,
                          selectedTileColor: ConstantColors.cff1F2128,
                          selectedColor: Colors.white,
                          trailing: Icon(Icons.delete),
                          tileColor: Colors.transparent,
                          shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.all(Radius.circular(8)),
                          ),
                          onTap: () =>
                              context.read<PostsCubit>().setAudio(null),
                        );
                      }

                      return ListTile(
                        title: Text(
                          "Add a sound to your post",
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontWeight: FontWeight.w400),
                        ),
                        selected: true,
                        selectedTileColor: ConstantColors.cff1F2128,
                        selectedColor: Colors.white,
                        trailing: Icon(
                          Icons.arrow_forward_ios_rounded,
                          size: 16,
                        ),
                        tileColor: Colors.transparent,
                        shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.all(Radius.circular(8)),
                        ),
                        onTap: () async {
                          FocusScope.of(context).unfocus();
                          FocusManager.instance.primaryFocus?.unfocus();

                          // Devuelve audio seleccionado.
                          final value = await Navigator.pushNamed(
                            context,
                            SelectAudioView.routeName,
                          );
                          if (value is AudioModel && context.mounted) {
                            // Guarda el audio seleccionado en el estado
                            context.read<PostsCubit>().setAudio(value);
                          }
                        },
                      );
                    },
                  ),
                ],
              ),
            );
          },
        ),
        BlocBuilder<PostsCubit, PostsState>(
          buildWhen: (p, c) => (p.description != c.description),
          builder: (context, state) {
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
              child: GenericButton(
                text: (state.postToEdit != null)
                    ? "Edit Post"
                    : "Create emotion",
                onTap:
                    ((state.description.trim().isNotEmpty &&
                            state.description !=
                                state.postToEdit?.dataPost?.description) &&
                        (emotion != null || state.postToEdit != null))
                    ? () {
                        FocusScope.of(context).unfocus();
                        FocusManager.instance.primaryFocus?.unfocus();

                        if (emotion != null && state.postToEdit != null) {
                          throw Exception("At least one value must be null.");
                        }

                        // Creating Post Case
                        if (emotion != null) {
                          context.read<PostsCubit>().createPost(
                            emotion: emotion!.emotion!,
                            url: emotion!.url!,
                          );
                        }

                        // Editin Post Case
                        if (state.postToEdit != null) {
                          context.read<PostsCubit>().editPost();
                        }
                      }
                    : null,
              ),
            );
          },
        ),
      ],
    );
  }
}
