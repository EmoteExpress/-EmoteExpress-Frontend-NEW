import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:emote_express/ui/posts/posts.dart';
import 'package:emote_express/widgets/generic/generic.dart';
import 'package:emote_express/models/generic/generic_enums.dart';
import 'package:emote_express/models/generic/user_detail_response_model.dart';

class PostLikesView extends StatelessWidget {
  const PostLikesView({super.key, this.id});

  static const String routeName = 'post_likes_view';

  final int? id;

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (BuildContext context) => PostsCubit()..getLikes(id),
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: AppBar(
          title: const Text("Likes"),
        ),
        body: const GenericLayout(
          child: _View(),
        ),
      ),
    );
  }
}

class _View extends StatelessWidget {
  const _View();

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<PostsCubit, PostsState>(
      buildWhen: (p, c) => (p.likeStatus != c.likeStatus),
      builder: (context, state) {
        switch (state.likeStatus) {
          case WidgetStatus.loading:
            return const Center(child: LoadingAnimation());
          case WidgetStatus.error:
            return Center(child: GenericError(text: state.errorText));
          default:
            if ((state.users?.data ?? []).isEmpty) {
              return const Center(
                child: GenericError(
                    text: '''We know your post is awesome. '''
                        '''Don't give up! Keep creating great content.'''),
              );
            }

            return ListView.separated(
              shrinkWrap: true,
              itemCount: state.users?.data?.length ?? 0,
              padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
              itemBuilder: (context, index) {
                return _UserTile(state.users?.data?[index]);
              },
              separatorBuilder: (context, index) => const SizedBox(height: 16),
            );
        }
      },
    );
  }
}

class _UserTile extends StatelessWidget {
  const _UserTile(this.user);

  final UserDetailResponseModel? user;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      tileColor: Colors.transparent,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(8)),
      ),
      leading: GenericNetworkImage(
        path: user?.url,
        size: 50,
      ),
      title: Text(
        user?.name ?? "N/A",
        maxLines: 2,
        overflow: TextOverflow.ellipsis,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 16,
          fontWeight: FontWeight.w700,
        ),
      ),
      //subtitle: Text(
      //  user?.lastEmotion ?? "N/A",
      //  maxLines: 1,
      //  overflow: TextOverflow.ellipsis,
      //  style: const TextStyle(
      //    color: Colors.white,
      //    fontSize: 12,
      //    fontWeight: FontWeight.w400,
      //  ),
      //),
    );
  }
}
