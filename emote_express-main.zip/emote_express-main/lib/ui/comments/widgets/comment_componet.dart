import 'package:flutter/material.dart';
import 'package:emote_express/utils/generic_utils.dart';
import 'package:emote_express/widgets/generic/generic.dart';
import 'package:emote_express/core/constants/constants_colors.dart';
import 'package:emote_express/models/posts/list_comments_response_model.dart';

class CommentComponet extends StatelessWidget {
  const CommentComponet(
      {super.key, this.comment, required this.onLike, required this.onDelete});

  final CommentModel? comment;
  final VoidCallback onLike;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Flexible(
          child: Row(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              GenericNetworkImage(
                path: comment?.dataUser?.url,
                size: 40,
                defaultIcon: Icons.person_rounded,
                sizeDefaultIcon: 40,
                border: 100,
              ),
              const SizedBox(width: 12),
              Flexible(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    RichText(
                      text: TextSpan(
                          style: const TextStyle(
                            fontSize: 16,
                            color: Colors.white,
                            fontWeight: FontWeight.w700,
                          ),
                          children: [
                            TextSpan(text: "${comment?.dataUser?.name} "),
                            TextSpan(
                              text: comment?.text,
                              style: const TextStyle(
                                fontSize: 15,
                                color: Color(0xFFF2F2F2),
                                fontWeight: FontWeight.w400,
                              ),
                            ),
                          ]),
                    ),
                    const SizedBox(height: 2),
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          color: (comment?.isLiked == true)
                              ? ConstantColors.cffFFBE26
                              : Colors.white,
                          visualDensity: VisualDensity.compact,
                          icon: const Icon(Icons.favorite_rounded),
                          onPressed: onLike,
                        ),
                        Text("${comment?.likeCount ?? 0}"),
                        // TODO report comment
                        // const SizedBox(width: 5),
                        // IconButton(
                        //   color: Colors.white,
                        //   visualDensity: VisualDensity.compact,
                        //   icon: const Icon(Icons.flag_rounded),
                        //   onPressed: () {},
                        // ),
                        if (comment?.ownComment == true) ...[
                          const SizedBox(width: 5),
                          IconButton(
                            color: Colors.red,
                            visualDensity: VisualDensity.compact,
                            icon: const Icon(Icons.delete_rounded),
                            onPressed: onDelete,
                          ),
                        ]
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 12),
            ],
          ),
        ),
        Text(
          GenericUtils.timeAgo(comment?.createdAt ?? DateTime.now()),
          style: const TextStyle(
            color: Color(0xFF828796),
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }
}
