import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:emote_express/ui/cubit/cubit.dart';
import 'package:emote_express/models/generic/generic.dart';
import 'package:emote_express/widgets/generic/generic.dart';
import 'package:emote_express/ui/comments/cubit/cubit.dart';
import 'package:emote_express/widgets/input/comment_input.dart';
import 'package:emote_express/core/constants/constants_colors.dart';

class InputComponent extends StatefulWidget {
  const InputComponent({super.key});

  @override
  State<InputComponent> createState() => InputComponentState();
}

class InputComponentState extends State<InputComponent> {
  late CommentsCubit _cubit;
  late TextEditingController _controller;

  @override
  void initState() {
    _cubit = context.read<CommentsCubit>();
    _controller = TextEditingController();
    super.initState();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
      decoration: const BoxDecoration(
        color: ConstantColors.checkboxColor,
        borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
      ),
      child: Row(
        children: [
          BlocBuilder<GeneralCubit, GeneralState>(
              buildWhen: (p, c) => (p.homeResponseModel != c.homeResponseModel),
              builder: (context, state) {
                return ProfileImageComponent(
                  size: 55,
                  path: state.homeResponseModel?.dataUser?.url,
                );
              }),
          const SizedBox(width: 8),
          Expanded(
            child: CommentInput(controller: _controller),
          ),
          const SizedBox(width: 4),
          BlocBuilder<CommentsCubit, CommentsState>(
            buildWhen: (p, c) => (p.likeCommentStatus != c.likeCommentStatus ||
                p.postCommentStatus != c.postCommentStatus ||
                p.deleteCommentStatus != c.deleteCommentStatus),
            builder: (context, state) {
              if (state.likeCommentStatus == WidgetStatus.loading ||
                  state.postCommentStatus == WidgetStatus.loading ||
                  state.deleteCommentStatus == WidgetStatus.loading) {
                return const LoadingIndicator();
              }

              return IconButton(
                icon: const Icon(Icons.send_rounded),
                onPressed: () {
                  _cubit.postComment(_controller.text.trim());
                  _controller.clear();
                },
              );
            },
          )
        ],
      ),
    );
  }
}
