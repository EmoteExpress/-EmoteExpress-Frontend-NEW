part of 'comments_cubit.dart';

class CommentsState extends Equatable {
  const CommentsState({
    this.errorText = '',
    this.postId,
    this.comments,
    this.getCommentsStatus = WidgetStatus.initial,
    this.likeCommentStatus = WidgetStatus.initial,
    this.postCommentStatus = WidgetStatus.initial,
    this.deleteCommentStatus = WidgetStatus.initial,
  });

  // General
  final String errorText;
  final int? postId;

  final ListCommentsResponseModel? comments;
  final WidgetStatus getCommentsStatus;

  final WidgetStatus likeCommentStatus;

  final WidgetStatus postCommentStatus;

  final WidgetStatus deleteCommentStatus;

  @override
  List<Object?> get props => [
        errorText,
        postId,
        comments,
        getCommentsStatus,
        likeCommentStatus,
        postCommentStatus,
        deleteCommentStatus,
      ];

  CommentsState copyWith({
    String? errorText,
    Wrapped<int?>? postId,
    Wrapped<ListCommentsResponseModel?>? comments,
    WidgetStatus? getCommentsStatus,
    WidgetStatus? likeCommentStatus,
    WidgetStatus? postCommentStatus,
    WidgetStatus? deleteCommentStatus,
  }) {
    return CommentsState(
      errorText: errorText ?? this.errorText,
      comments: comments != null ? comments.value : this.comments,
      getCommentsStatus: getCommentsStatus ?? this.getCommentsStatus,
      postId: (postId != null) ? postId.value : this.postId,
      likeCommentStatus: likeCommentStatus ?? this.likeCommentStatus,
      postCommentStatus: postCommentStatus ?? this.postCommentStatus,
      deleteCommentStatus: deleteCommentStatus ?? this.deleteCommentStatus,
    );
  }
}
