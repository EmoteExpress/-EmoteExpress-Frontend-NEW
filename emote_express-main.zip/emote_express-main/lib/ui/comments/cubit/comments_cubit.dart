import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:emote_express/models/generic/wrapped.dart';
import 'package:emote_express/providers/comments_provider.dart';
import 'package:emote_express/models/generic/generic_enums.dart';
import 'package:emote_express/models/posts/list_comments_response_model.dart';

part 'comments_state.dart';

class CommentsCubit extends Cubit<CommentsState> {
  CommentsCubit() : super(const CommentsState());

  final _commentsProvider = CommentsProvider();

  void init(int? id) {
    emit(state.copyWith(postId: Wrapped.value(id)));
    getComments();
  }

  // ========================================================================
  // Comments
  // ========================================================================

  // TODO integrar paginado
  Future<void> getComments() async {
    if (state.postId == null) return;
    emit(state.copyWith(getCommentsStatus: WidgetStatus.loading));

    final response = await _commentsProvider.getComments(postId: state.postId!);

    return response.fold((l) {
      emit(state.copyWith(
          getCommentsStatus: WidgetStatus.error, errorText: l.details));
    }, (r) async {
      emit(
        state.copyWith(
          getCommentsStatus: WidgetStatus.success,
          comments: Wrapped.value(r),
        ),
      );
    });
  }

  Future<void> likeComment(int? commentId) async {
    if (commentId == null) return;
    if (state.likeCommentStatus == WidgetStatus.loading) return;
    emit(state.copyWith(likeCommentStatus: WidgetStatus.loading));

    final response = await _commentsProvider.likeComment(commentId: commentId);

    return response.fold((l) {
      emit(state.copyWith(
          likeCommentStatus: WidgetStatus.error, errorText: l.details));
    }, (r) async {
      // Calculando el index del comentario que necesita ser actualizado
      final index =
          state.comments?.data?.indexWhere((e) => (e.id == commentId));

      // Validando errores || Returns -1 if [element] is not found.
      if ((index ?? -1).isNegative) {
        state.copyWith(likeCommentStatus: WidgetStatus.error);
        throw Exception("Comment with ID $commentId not found");
      }

      List<CommentModel>? newList = [];

      for (var i = 0; i < (state.comments?.data?.length ?? 0); i++) {
        if (i == index) {
          final count = state.comments!.data![i].likeCount;

          // Reemplazando el comentario con el valor actualizado
          newList.add(
            state.comments!.data![i].copyWith(
              isLiked: r,
              likeCount: (r == true) ? ((count ?? 0) + 1) : ((count ?? 0) - 1),
            ),
          );
        } else {
          newList.add(state.comments!.data![i]);
        }
      }

      emit(
        state.copyWith(
            likeCommentStatus: WidgetStatus.success,
            comments:
                Wrapped.value(state.comments?.copyWith(data: [...newList]))),
      );
    });
  }

  Future<void> postComment(String? comment) async {
    if (state.postId == null || (comment ?? "").isEmpty) return;
    emit(state.copyWith(postCommentStatus: WidgetStatus.loading));

    final response = await _commentsProvider.postComment(
        postId: state.postId!, comment: comment!);

    return response.fold((l) {
      emit(state.copyWith(
          postCommentStatus: WidgetStatus.error, errorText: l.details));
    }, (r) async {
      final newList = state.comments?.data ?? [];
      newList.insert(0, r);

      emit(
        state.copyWith(
          comments: Wrapped.value(state.comments?.copyWith(data: [...newList])),
          postCommentStatus: WidgetStatus.success,
        ),
      );
    });
  }

  Future<void> deleteComment(int? id) async {
    if (state.postId == null || id == null) return;
    emit(state.copyWith(deleteCommentStatus: WidgetStatus.loading));

    final response = await _commentsProvider.deleteComment(commentId: id);

    return response.fold((l) {
      emit(state.copyWith(
          deleteCommentStatus: WidgetStatus.error, errorText: l.details));
    }, (r) async {
      final newList = state.comments?.data ?? [];
      newList.removeWhere((comment) => (comment.id == id));

      emit(
        state.copyWith(
          comments: Wrapped.value(state.comments?.copyWith(data: [...newList])),
          deleteCommentStatus: WidgetStatus.success,
        ),
      );
    });
  }
}
