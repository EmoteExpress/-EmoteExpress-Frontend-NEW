import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:emote_express/ui/comments/comments.dart';
import 'package:emote_express/models/generic/generic.dart';
import 'package:emote_express/widgets/generic/generic.dart';

class PostCommentsView extends StatelessWidget {
  const PostCommentsView({super.key, this.id});

  static const String routeName = 'post_comments_view';

  final int? id;

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (BuildContext context) => CommentsCubit()..init(id),
      child: Scaffold(
        appBar: AppBar(
          title: const Text("Comments"),
        ),
        body: const GenericLayout(
          child: _View(),
        ),
      ),
    );
  }
}

class _View extends StatelessWidget {
  const _View();

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (didPop) return;
        Navigator.pop<int>(context,
            context.read<CommentsCubit>().state.comments?.data?.length);
      },
      child: const Column(
        children: [
          Expanded(
            child: _RenderComments(),
          ),
          InputComponent()
        ],
      ),
    );
  }
}

class _RenderComments extends StatelessWidget {
  const _RenderComments();

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<CommentsCubit, CommentsState>(
      buildWhen: (p, c) => (p.comments != c.comments),
      builder: (context, state) {
        switch (state.getCommentsStatus) {
          case WidgetStatus.loading:
            return const Center(child: LoadingIndicator());
          case WidgetStatus.error:
            return Center(child: GenericError(text: state.errorText));
          default:
            if (state.comments?.data?.isEmpty ?? true) {
              return const Center(
                child: GenericError(text: "No comments found."),
              );
            }

            return ListView.separated(
              shrinkWrap: true,
              itemCount: state.comments?.data?.length ?? 0,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              itemBuilder: (context, index) {
                return CommentComponet(
                  comment: state.comments?.data?[index],
                  onLike: () {
                    context
                        .read<CommentsCubit>()
                        .likeComment(state.comments?.data?[index].id);
                  },
                  onDelete: () {
                    context
                        .read<CommentsCubit>()
                        .deleteComment(state.comments?.data?[index].id);
                  },
                );
              },
              separatorBuilder: (context, index) => const SizedBox(height: 12),
            );
        }
      },
    );
  }
}
