import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:emote_express/widgets/generic/generic.dart';
import 'package:emote_express/widgets/buttons/generic_button.dart';
import 'package:emote_express/core/constants/constants_icons.dart';
import 'package:emote_express/core/constants/constants_colors.dart';
import 'package:emote_express/ui/authentication/login/views/login_view.dart';

class WelcomeView extends StatelessWidget {
  const WelcomeView({super.key});

  static const String routeName = 'welcome_view';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: SafeArea(
        child: GenericLayout(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              SvgPicture.asset(ConstantIcons.logo, fit: BoxFit.cover),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 32),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    RichText(
                      text: const TextSpan(
                        style: TextStyle(
                          fontSize: 32,
                          fontWeight: FontWeight.w800,
                        ),
                        children: [
                          TextSpan(text: "Start\n"),
                          TextSpan(
                            text: "expressing\n",
                            style: TextStyle(color: ConstantColors.cffFFBE26),
                          ),
                          TextSpan(text: "yourself"),
                        ],
                      ),
                    ),
                    const SizedBox(height: 15),
                    Text(
                      '''We have created a creative space with an '''
                      '''intuitive interface for you''',
                      style: TextStyle(
                        fontWeight: FontWeight.w500,
                        color: ConstantColors.white.withValues(alpha: 0.7),
                      ),
                    ),
                    const SizedBox(height: 24),
                    GenericButton(
                      text: "Let's go",
                      onTap: () async {
                        await Navigator.pushNamed(context, LoginView.routeName);
                      },
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
