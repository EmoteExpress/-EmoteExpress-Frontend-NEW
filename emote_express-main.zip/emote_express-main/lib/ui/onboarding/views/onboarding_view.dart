import 'package:emote_express/utils/local_storage.dart';
import 'package:flutter_svg/svg.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:emote_express/ui/cubit/cubit.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:emote_express/ui/onboarding/views/views.dart';
import 'package:emote_express/core/constants/constants.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';

class OnBoardingView extends StatelessWidget {
  const OnBoardingView({super.key});

  static const String routeName = 'onboarding_view';

  static const List _sliderImages = [
    ConstantIcons.onboarding1,
    ConstantIcons.onboarding2,
    ConstantIcons.onboarding3,
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 20),
            SvgPicture.asset(
              ConstantIcons.logo,
              height: 80,
              width: 54,
              fit: BoxFit.cover,
            ),
            const SizedBox(height: 27),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 32),
              child: RichText(
                text: const TextSpan(
                  style: TextStyle(fontSize: 32, fontWeight: FontWeight.w700),
                  children: [
                    TextSpan(text: "Record and track "),
                    TextSpan(
                      text: "your emotions",
                      style: TextStyle(color: ConstantColors.cffFFBE26),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 27),
            Expanded(
              child: CarouselSlider.builder(
                itemCount: _sliderImages.length,
                options: CarouselOptions(
                  viewportFraction: 1,
                  aspectRatio: (4 / 5),
                  enableInfiniteScroll: false,
                  onPageChanged: (index, reason) {
                    context.read<GeneralCubit>().setCarouselIndex(index);
                  },
                ),
                itemBuilder: (context, index, realIndex) {
                  return SvgPicture.asset(
                    _sliderImages[index],
                    fit: BoxFit.fitHeight,
                  );
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 5),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  BlocBuilder<GeneralCubit, GeneralState>(
                    buildWhen: (p, c) => (p.carouselIndex != c.carouselIndex),
                    builder: (context, state) {
                      return AnimatedSmoothIndicator(
                        activeIndex: state.carouselIndex,
                        count: 3,
                        effect: const SlideEffect(
                          spacing: 6,
                          radius: 8,
                          dotWidth: 24,
                          dotHeight: 12,
                          paintStyle: PaintingStyle.fill,
                          dotColor: Color(0xFF553D05),
                          activeDotColor: ConstantColors.cffFFBE26,
                        ),
                      );
                    },
                  ),
                  TextButton(
                    onPressed: () async {
                      await LocalStorage.setOnboarding().then((_) async {
                        if (!context.mounted) return;
                        await Navigator.pushNamed(
                          context,
                          WelcomeView.routeName,
                        );
                      });
                    },
                    child: const Text(
                      "Skip",
                      style: TextStyle(color: ConstantColors.cffFFBE26),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}
