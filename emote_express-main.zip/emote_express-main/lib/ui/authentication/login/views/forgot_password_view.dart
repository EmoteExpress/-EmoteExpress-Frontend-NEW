import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:emote_express/widgets/widgets.dart';
import 'package:emote_express/utils/validators.dart';
import 'package:emote_express/utils/navigator_utils.dart';
import 'package:emote_express/models/generic/generic_enums.dart';
import 'package:emote_express/ui/authentication/cubit/cubit.dart';

class ForgotPasswordView extends StatelessWidget {
  const ForgotPasswordView({super.key});
  static const String routeName = 'forgot_password_view';

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (BuildContext context) => AuthCubit(),
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: AppBar(
          title: const Text("Forgot Password"),
        ),
        body: GenericLayout(
          child: BlocConsumer<AuthCubit, AuthState>(
              listenWhen: (p, c) => (p.forgotStatus != c.forgotStatus),
              listener: (context, state) async {
                switch (state.forgotStatus) {
                  case WidgetStatus.error:
                    showDialog<void>(
                      context: context,
                      barrierDismissible: false,
                      builder: (context) => GenericDialog(
                        description: state.errorText,
                        isErrorDialog: true,
                      ),
                    );
                    break;

                  case WidgetStatus.success:
                    showDialog<void>(
                      context: context,
                      builder: (context) => GenericDialog(
                        title: "Follow the instructions",
                        description:
                            '''We've sent you an email with detailed '''
                            '''instructions on how to reset your password! Please '''
                            '''check your inbox to continue.''',
                        onAccept: () {
                          NavigatorUtils.popUntilInitialRoute(context);
                        },
                      ),
                    );
                    break;

                  default:
                    break;
                }
              },
              buildWhen: (p, c) => (p.forgotStatus != c.forgotStatus),
              builder: (context, state) {
                return Stack(
                  children: [
                    const Padding(
                      padding:
                          EdgeInsets.symmetric(horizontal: 24, vertical: 20),
                      child: _View(),
                    ),
                    if (state.forgotStatus == WidgetStatus.loading)
                      const Center(child: LoadingIndicator())
                  ],
                );
              }),
        ),
      ),
    );
  }
}

class _View extends StatefulWidget {
  const _View();

  @override
  State<_View> createState() => __ViewState();
}

class __ViewState extends State<_View> {
  late AuthCubit _cubit;

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  late TextEditingController _emailCont;

  @override
  void initState() {
    _cubit = context.read<AuthCubit>();
    _emailCont = TextEditingController();
    super.initState();
  }

  @override
  void dispose() {
    _emailCont.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Form(
          key: _formKey,
          child: GenericFormInput(
            hintText: "Email Address",
            textController: _emailCont,
            prefixIcon: Icons.email_rounded,
            textInputType: TextInputType.emailAddress,
            validator: (value) => Validators.emailValidation(value),
          ),
        ),
        GenericButton(
          text: "Recover Password",
          onTap: () {
            FocusScope.of(context).unfocus();
            FocusManager.instance.primaryFocus?.unfocus();

            if (_formKey.currentState!.validate()) {
              _cubit.forgotPassword(_emailCont.text);
            }
          },
        ),
      ],
    );
  }
}
