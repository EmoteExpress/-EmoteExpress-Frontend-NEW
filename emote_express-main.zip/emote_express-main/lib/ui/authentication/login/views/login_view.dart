import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:emote_express/widgets/widgets.dart';
import 'package:emote_express/utils/validators.dart';
import 'package:emote_express/ui/home/views/views.dart';
import 'package:emote_express/utils/local_storage.dart';
import 'package:emote_express/models/generic/generic_enums.dart';
import 'package:emote_express/core/constants/constants_icons.dart';
import 'package:emote_express/core/constants/constants_colors.dart';
import 'package:emote_express/ui/authentication/authentication.dart';

class LoginView extends StatelessWidget {
  const LoginView({super.key});

  static const String routeName = 'login_view';

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (BuildContext context) => AuthCubit()
        ..setRememberMe((LocalStorage.getEmail() ?? "").isEmpty ? false : true),
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: AppBar(title: const Text("Sign In")),
        body: GenericLayout(
          child: BlocConsumer<AuthCubit, AuthState>(
            listenWhen: (p, c) => (p.loginStatus != c.loginStatus),
            listener: (context, state) async {
              switch (state.loginStatus) {
                case WidgetStatus.error:
                  showDialog<void>(
                    context: context,
                    barrierDismissible: false,
                    builder: (context) => GenericDialog(
                      description: state.errorText,
                      isErrorDialog: true,
                    ),
                  );
                  break;

                case WidgetStatus.success:

                  // Checking values
                  if (state.responseLogin?.user?.id == null) {
                    throw Exception("Check null values");
                  }

                  // Guardando data en cache
                  await LocalStorage.setUserData(
                    userType: state.responseLogin?.user?.tiprol,
                    token: state.responseLogin?.token?.accessToken,
                  );

                  // Guardando credenciales de usuario si es necesario
                  if (state.rememberMe) {
                    await LocalStorage.setLogInCredentials(
                      email: state.emailInput,
                      password: state.passwordInput,
                    );
                  } else {
                    await LocalStorage.deleteLogInCredentials();
                  }

                  switch (LocalStorage.getUserType()) {
                    case "user":
                      Navigator.pushNamedAndRemoveUntil(
                        // ignore: use_build_context_synchronously
                        context,
                        HomeView.routeName,
                        (Route<dynamic> route) => false,
                      );
                      break;
                    default:
                      Navigator.pushNamedAndRemoveUntil(
                        context,
                        HomeDefaultView.routeName,
                        (Route<dynamic> route) => false,
                      );
                      break;
                  }
                  break;

                default:
                  break;
              }
            },
            buildWhen: (p, c) => (p.loginStatus != c.loginStatus),
            builder: (context, state) {
              return Stack(
                children: [
                  const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 24),
                    child: _View(),
                  ),
                  if (state.loginStatus == WidgetStatus.loading)
                    const Center(child: LoadingIndicator()),
                ],
              );
            },
          ),
        ),
      ),
    );
  }
}

class _View extends StatefulWidget {
  const _View();

  @override
  State<_View> createState() => _ViewState();
}

class _ViewState extends State<_View> {
  late AuthCubit _cubit;

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  late TextEditingController _emailCont;
  late TextEditingController _passwordCont;

  @override
  void initState() {
    _cubit = context.read<AuthCubit>();
    _emailCont = TextEditingController(text: LocalStorage.getEmail());
    _passwordCont = TextEditingController(text: LocalStorage.getPassword());
    super.initState();
  }

  @override
  void dispose() {
    _emailCont.dispose();
    _passwordCont.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SvgPicture.asset(
              ConstantIcons.logo,
              height: 130,
              width: 85,
              fit: BoxFit.cover,
            ),
            const SizedBox(height: 20),
            const Text(
              "Welcome Emote Express 👋🏻",
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 6),
            const Text(
              "Enter your Email & Password to Sign in",
              textAlign: TextAlign.center,
              style: TextStyle(fontWeight: FontWeight.w400),
            ),
          ],
        ),
        Form(
          key: _formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              GenericFormInput(
                hintText: "Email Address",
                textController: _emailCont,
                prefixIcon: Icons.email_rounded,
                textInputType: TextInputType.emailAddress,
                validator: (value) => Validators.emailValidation(value),
              ),
              const SizedBox(height: 24),
              BlocBuilder<AuthCubit, AuthState>(
                buildWhen: (p, c) => (p.showPassword != c.showPassword),
                builder: (context, state) {
                  return GenericFormInput(
                    hintText: "Password",
                    obscureText: !state.showPassword,
                    textController: _passwordCont,
                    prefixIcon: Icons.key_rounded,
                    textInputType: TextInputType.visiblePassword,
                    validator: (value) =>
                        Validators.loginPasswordValidation(value),
                    suffixPasswordIcon: GestureDetector(
                      onTap: () => _cubit.showOrHidePassword(),
                      child: Icon(
                        state.showPassword
                            ? Icons.visibility
                            : Icons.visibility_off,
                      ),
                    ),
                  );
                },
              ),
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Flexible(child: _RememberMeComponent()),
                  Flexible(
                    child: GestureDetector(
                      onTap: () {
                        Navigator.pushNamed(
                          context,
                          ForgotPasswordView.routeName,
                        );
                      },
                      child: const Padding(
                        padding: EdgeInsets.only(right: 20),
                        child: Text(
                          "Forgot Password",
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontWeight: FontWeight.w400,
                            color: ConstantColors.cffFFBE26,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            GenericButton(
              text: "Sign In",
              onTap: () async {
                FocusScope.of(context).unfocus();
                FocusManager.instance.primaryFocus?.unfocus();

                if (_formKey.currentState!.validate()) {
                  _cubit.login(_emailCont.text, _passwordCont.text);
                }
              },
            ),
            const Row(
              children: [
                Expanded(
                  child: Divider(color: ConstantColors.cff1F2128, height: 80),
                ),
                SizedBox(width: 8),
                Text("OR", style: TextStyle(fontWeight: FontWeight.w700)),
                SizedBox(width: 8),
                Expanded(
                  child: Divider(color: ConstantColors.cff1F2128, height: 80),
                ),
              ],
            ),
            RichText(
              text: TextSpan(
                style: const TextStyle(
                  fontWeight: FontWeight.w400,
                  fontSize: 15,
                ),
                children: [
                  const TextSpan(text: "Don't Have an Account? "),
                  TextSpan(
                    recognizer: TapGestureRecognizer()
                      ..onTap = () {
                        Navigator.pushNamed(context, RegisterView.routeName);
                      },
                    text: "Sign Up",
                    style: const TextStyle(
                      color: ConstantColors.cffFFBE26,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class _RememberMeComponent extends StatelessWidget {
  const _RememberMeComponent();

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<AuthCubit, AuthState>(
      buildWhen: (p, c) => (p.rememberMe != c.rememberMe),
      builder: (context, state) {
        return Row(
          children: [
            Checkbox(
              value: state.rememberMe,
              activeColor: ConstantColors.checkboxColor,
              onChanged: (value) {
                context.read<AuthCubit>().setRememberMe(value ?? false);
              },
            ),
            Flexible(
              child: GestureDetector(
                onTap: () {
                  context.read<AuthCubit>().setRememberMe(!state.rememberMe);
                },
                child: const Text(
                  "Remember me",
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontWeight: FontWeight.w400),
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}
