part of 'auth_cubit.dart';

class AuthState extends Equatable {
  const AuthState({
    this.errorText = '',
    this.rememberMe = false,
    this.showPassword = false,
    this.loginStatus = WidgetStatus.initial,
    this.emailInput = "",
    this.passwordInput = "",
    this.responseLogin,
    this.forgotStatus = WidgetStatus.initial,
    this.registerStatus = WidgetStatus.initial,
    this.photo,
    this.genderSelected,
  });

  // General
  final String? errorText;
  final bool showPassword;

  // Login
  final bool rememberMe;
  final String emailInput;
  final String passwordInput;
  final WidgetStatus loginStatus;
  final LoginResponseModel? responseLogin;

  // Forgot Password
  final WidgetStatus forgotStatus;

  // Register
  final WidgetStatus registerStatus;
  final Gender? genderSelected;
  final File? photo;

  @override
  List<Object?> get props => [
        errorText,
        rememberMe,
        showPassword,
        loginStatus,
        emailInput,
        passwordInput,
        responseLogin,
        forgotStatus,
        registerStatus,
        photo,
        genderSelected,
      ];

  AuthState copyWith({
    String? errorText,
    bool? rememberMe,
    bool? showPassword,
    WidgetStatus? loginStatus,
    String? emailInput,
    String? passwordInput,
    Wrapped<LoginResponseModel?>? responseLogin,
    WidgetStatus? forgotStatus,
    WidgetStatus? registerStatus,
    Wrapped<File?>? photo,
    Wrapped<Gender?>? genderSelected,
  }) {
    return AuthState(
      errorText: errorText ?? this.errorText,
      rememberMe: rememberMe ?? this.rememberMe,
      showPassword: showPassword ?? this.showPassword,
      loginStatus: loginStatus ?? this.loginStatus,
      emailInput: emailInput ?? this.emailInput,
      passwordInput: passwordInput ?? this.passwordInput,
      responseLogin:
          (responseLogin != null) ? responseLogin.value : this.responseLogin,
      forgotStatus: forgotStatus ?? this.forgotStatus,
      registerStatus: registerStatus ?? this.registerStatus,
      photo: (photo != null) ? photo.value : this.photo,
      genderSelected:
          (genderSelected != null) ? genderSelected.value : this.genderSelected,
    );
  }
}
