import 'dart:io';

import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:emote_express/models/generic/wrapped.dart';
import 'package:emote_express/providers/auth_provider.dart';
import 'package:emote_express/models/generic/generic_enums.dart';
import 'package:emote_express/models/authentication/authentication.dart';

part 'auth_state.dart';

class AuthCubit extends Cubit<AuthState> {
  AuthCubit() : super(const AuthState());

  final _authProvider = AuthProvider();

  // ========================================================================
  // Login
  // ========================================================================

  void setRememberMe(bool value) {
    emit(state.copyWith(rememberMe: value));
  }

  void showOrHidePassword() {
    emit(state.copyWith(showPassword: !state.showPassword));
  }

  Future<void> login(String email, String password) async {
    if (state.loginStatus == WidgetStatus.loading) return;
    emit(state.copyWith(loginStatus: WidgetStatus.loading));

    final response =
        await _authProvider.login(email: email, password: password);

    return response.fold((l) {
      emit(state.copyWith(
          loginStatus: WidgetStatus.error, errorText: l.details));
    }, (r) async {
      emit(state.copyWith(
        emailInput: email,
        passwordInput: password,
        loginStatus: WidgetStatus.success,
        responseLogin: Wrapped.value(r),
      ));
    });
  }

  // ========================================================================
  // Forgot Password
  // ========================================================================

  Future<void> forgotPassword(String email) async {
    if (state.forgotStatus == WidgetStatus.loading) return;
    emit(state.copyWith(forgotStatus: WidgetStatus.loading));

    final response = await _authProvider.forgotPassword(email: email);

    return response.fold((l) {
      emit(state.copyWith(
          forgotStatus: WidgetStatus.error, errorText: l.details));
    }, (r) async {
      emit(state.copyWith(forgotStatus: WidgetStatus.success));
    });
  }

  // ========================================================================
  // Register
  // ========================================================================

  void setPhoto(File? photo) {
    emit(state.copyWith(photo: Wrapped.value(photo)));
  }

  void setGender(Gender? value) {
    emit(state.copyWith(genderSelected: Wrapped.value(value)));
  }

  Future<void> register({
    required String userName,
    required String email,
    required String password,
    required String fullName,
    required String phone,
  }) async {
    if (state.registerStatus == WidgetStatus.loading) return;
    emit(state.copyWith(registerStatus: WidgetStatus.loading));

    final data = RegisterRequestModel(
      userName: userName,
      email: email,
      password: password,
      fullName: fullName,
      phone: phone,
      gender: state.genderSelected,
      image: state.photo,
    );

    final response = await _authProvider.register(data: data);

    return response.fold((l) {
      emit(state.copyWith(
          registerStatus: WidgetStatus.error, errorText: l.details));
    }, (r) async {
      emit(state.copyWith(
        registerStatus: WidgetStatus.success,
        responseLogin: Wrapped.value(r),
      ));
    });
  }
}
