import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:emote_express/widgets/widgets.dart';
import 'package:emote_express/utils/validators.dart';
import 'package:emote_express/ui/home/views/views.dart';
import 'package:emote_express/utils/local_storage.dart';
import 'package:emote_express/models/generic/generic_enums.dart';
import 'package:emote_express/ui/authentication/cubit/cubit.dart';
import 'package:emote_express/ui/authentication/register/register.dart';

class RegisterView extends StatelessWidget {
  const RegisterView({super.key});

  static const String routeName = 'register_view';

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (BuildContext context) => AuthCubit(),
      child: Scaffold(
        appBar: AppBar(title: const Text("Sign Up")),
        body: GenericLayout(
          child: BlocConsumer<AuthCubit, AuthState>(
            listenWhen: (p, c) => (p.registerStatus != c.registerStatus),
            listener: (context, state) async {
              switch (state.registerStatus) {
                case WidgetStatus.error:
                  showDialog<void>(
                    context: context,
                    barrierDismissible: false,
                    builder: (context) => GenericDialog(
                      description: state.errorText,
                      isErrorDialog: true,
                    ),
                  );
                  break;

                case WidgetStatus.success:

                  //  Guardando data en cache
                  await LocalStorage.setUserData(
                    userType: state.responseLogin?.user?.tiprol,
                    token: state.responseLogin?.token?.accessToken,
                  );

                  if (!context.mounted) return;

                  Navigator.pushNamedAndRemoveUntil(
                    context,
                    HomeView.routeName,
                    (Route<dynamic> route) => false,
                  );
                  break;

                default:
                  break;
              }
            },
            buildWhen: (p, c) => (p.registerStatus != c.registerStatus),
            builder: (context, state) {
              return Stack(
                children: [
                  const _View(),
                  if (state.registerStatus == WidgetStatus.loading)
                    const Center(child: LoadingIndicator()),
                ],
              );
            },
          ),
        ),
      ),
    );
  }
}

class _View extends StatefulWidget {
  const _View();

  @override
  State<_View> createState() => _ViewState();
}

class _ViewState extends State<_View> {
  late AuthCubit _cubit;

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  late TextEditingController _usernameCont;
  late TextEditingController _emailCont;
  late TextEditingController _passwordCont;
  late TextEditingController _passwordConfirmCont;
  late TextEditingController _fullnameCont;
  late TextEditingController _phoneCont;

  @override
  void initState() {
    _cubit = context.read<AuthCubit>();
    _usernameCont = TextEditingController();
    _emailCont = TextEditingController();
    _passwordCont = TextEditingController();
    _passwordConfirmCont = TextEditingController();
    _fullnameCont = TextEditingController();
    _phoneCont = TextEditingController();
    super.initState();
  }

  @override
  void dispose() {
    _usernameCont.dispose();
    _emailCont.dispose();
    _passwordCont.dispose();
    _passwordConfirmCont.dispose();
    _fullnameCont.dispose();
    _phoneCont.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Expanded(
          child: Form(
            key: _formKey,
            child: ListView(
              shrinkWrap: true,
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
              children: [
                BlocBuilder<AuthCubit, AuthState>(
                  buildWhen: (p, c) => (p.photo != c.photo),
                  builder: (context, state) {
                    return SelectProfileImage(
                      path: state.photo?.path,
                      onGetImage: (image) => _cubit.setPhoto(image.file),
                    );
                  },
                ),
                const SizedBox(height: 32),
                GenericFormInput(
                  hintText: "Username",
                  textController: _usernameCont,
                  prefixIcon: Icons.person_rounded,
                  textInputType: TextInputType.text,
                  validator: (value) => Validators.usernameValidator(value),
                ),
                const SizedBox(height: 24),
                GenericFormInput(
                  hintText: "Email Address",
                  textController: _emailCont,
                  prefixIcon: Icons.email_rounded,
                  textInputType: TextInputType.emailAddress,
                  validator: (value) => Validators.emailValidation(value),
                ),
                const SizedBox(height: 24),
                BlocBuilder<AuthCubit, AuthState>(
                  buildWhen: (p, c) => (p.showPassword != c.showPassword),
                  builder: (context, state) {
                    return GenericFormInput(
                      hintText: "Password",
                      obscureText: !state.showPassword,
                      textController: _passwordCont,
                      prefixIcon: Icons.key_rounded,
                      textInputType: TextInputType.visiblePassword,
                      validator: (value) =>
                          Validators.registerPasswordValidation(
                            value,
                            _passwordCont.text,
                            _passwordConfirmCont.text,
                          ),
                      suffixPasswordIcon: GestureDetector(
                        onTap: () => _cubit.showOrHidePassword(),
                        child: Icon(
                          state.showPassword
                              ? Icons.visibility
                              : Icons.visibility_off,
                        ),
                      ),
                    );
                  },
                ),
                const SizedBox(height: 24),
                BlocBuilder<AuthCubit, AuthState>(
                  buildWhen: (p, c) => (p.showPassword != c.showPassword),
                  builder: (context, state) {
                    return GenericFormInput(
                      hintText: "Confirm Password",
                      obscureText: !state.showPassword,
                      textController: _passwordConfirmCont,
                      prefixIcon: Icons.key_rounded,
                      textInputType: TextInputType.visiblePassword,
                      validator: (value) =>
                          Validators.registerPasswordValidation(
                            value,
                            _passwordCont.text,
                            _passwordConfirmCont.text,
                          ),
                      suffixPasswordIcon: GestureDetector(
                        onTap: () => _cubit.showOrHidePassword(),
                        child: Icon(
                          state.showPassword
                              ? Icons.visibility
                              : Icons.visibility_off,
                        ),
                      ),
                    );
                  },
                ),
                const SizedBox(height: 24),
                GenericFormInput(
                  hintText: "Name",
                  textController: _fullnameCont,
                  prefixIcon: Icons.person_rounded,
                  textInputType: TextInputType.name,
                  textCapitalization: TextCapitalization.words,
                  validator: (value) => Validators.onlyLettersValidator(value),
                ),
                const SizedBox(height: 24),
                const _GenderSection(),
                const SizedBox(height: 24),
                GenericFormInput(
                  hintText: "Phone Number",
                  textController: _phoneCont,
                  prefixIcon: Icons.phone_rounded,
                  textInputType: TextInputType.phone,
                  validator: (value) => Validators.phoneValidator(value),
                ),
              ],
            ),
          ),
        ),
        BlocBuilder<AuthCubit, AuthState>(
          buildWhen: (p, c) =>
              (p.photo != c.photo || p.genderSelected != c.genderSelected),
          builder: (context, state) {
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
              child: GenericButton(
                text: "Sign Up",
                onTap: (state.photo != null && state.genderSelected != null)
                    ? () async {
                        FocusScope.of(context).unfocus();
                        FocusManager.instance.primaryFocus?.unfocus();

                        if (_formKey.currentState!.validate()) {
                          _cubit.register(
                            userName: _usernameCont.text.toLowerCase().trim(),
                            email: _emailCont.text.trim(),
                            fullName: _fullnameCont.text.trim(),
                            password: _passwordCont.text,
                            phone: _phoneCont.text,
                          );
                        }
                      }
                    : null,
              ),
            );
          },
        ),
      ],
    );
  }
}

class _GenderSection extends StatelessWidget {
  const _GenderSection();

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          "Select your gender identity",
          style: TextStyle(fontWeight: FontWeight.w400),
        ),
        const SizedBox(height: 24),
        BlocBuilder<AuthCubit, AuthState>(
          buildWhen: (p, c) => (p.genderSelected != c.genderSelected),
          builder: (context, state) {
            return Row(
              children: [
                GenderComponent(
                  value: Gender.male,
                  isSelected: (state.genderSelected == Gender.male),
                  onPressed: () {
                    context.read<AuthCubit>().setGender(Gender.male);
                  },
                ),
                const SizedBox(width: 14),
                GenderComponent(
                  value: Gender.female,
                  isSelected: (state.genderSelected == Gender.female),
                  onPressed: () {
                    context.read<AuthCubit>().setGender(Gender.female);
                  },
                ),
                const SizedBox(width: 14),
                GenderComponent(
                  value: Gender.other,
                  isSelected: (state.genderSelected == Gender.other),
                  onPressed: () {
                    context.read<AuthCubit>().setGender(Gender.other);
                  },
                ),
              ],
            );
          },
        ),
      ],
    );
  }
}
