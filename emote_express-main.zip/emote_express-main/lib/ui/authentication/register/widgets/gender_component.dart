import 'package:flutter/material.dart';
import 'package:emote_express/models/generic/generic_enums.dart';
import 'package:emote_express/core/constants/constants_colors.dart';

class GenderComponent extends StatelessWidget {
  const GenderComponent({
    super.key,
    required this.value,
    required this.isSelected,
    required this.onPressed,
  });

  final Gender value;
  final bool isSelected;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Material(
        color: Colors.transparent,
        borderRadius: const BorderRadius.all(Radius.circular(8)),
        child: InkWell(
          onTap: onPressed,
          borderRadius: const BorderRadius.all(Radius.circular(8)),
          child: Ink(
            padding: const EdgeInsets.all(16),
            decoration: const BoxDecoration(
              color: ConstantColors.cff1F2128,
              borderRadius: BorderRadius.all(Radius.circular(8)),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(value.icon, color: Colors.white, size: 26),
                const SizedBox(height: 6),
                Text(
                  value.text,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.w400),
                ),
                Checkbox(
                  value: isSelected,
                  activeColor: ConstantColors.cffF6912E,
                  onChanged: (value) => onPressed(),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
