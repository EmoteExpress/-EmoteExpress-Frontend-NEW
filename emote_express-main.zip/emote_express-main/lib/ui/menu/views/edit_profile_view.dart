import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:emote_express/ui/menu/menu.dart';
import 'package:emote_express/widgets/widgets.dart';
import 'package:emote_express/utils/validators.dart';
import 'package:emote_express/ui/cubit/general_cubit.dart';
import 'package:emote_express/models/generic/generic_enums.dart';
import 'package:emote_express/ui/authentication/register/widgets/gender_component.dart';

class EditProfileView extends StatelessWidget {
  const EditProfileView({super.key});

  static const String routeName = 'edit_profile_view';

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => MenuCubit()..getUserDetails(),
      child: Scaffold(
        appBar: AppBar(title: const Text("Edit Profile")),
        body: BlocBuilder<MenuCubit, MenuState>(
          buildWhen: (p, c) => (p.detailStatus != c.detailStatus),
          builder: (context, state) {
            switch (state.detailStatus) {
              case WidgetStatus.loading:
                return const Center(child: LoadingIndicator());
              case WidgetStatus.error:
                return Center(child: GenericError(text: state.errorText));
              default:
                return BlocConsumer<MenuCubit, MenuState>(
                  listenWhen: (p, c) =>
                      (p.updateDetailsStatus != c.updateDetailsStatus),
                  listener: (context, state) {
                    switch (state.updateDetailsStatus) {
                      case WidgetStatus.error:
                        showDialog<void>(
                          context: context,
                          barrierDismissible: false,
                          builder: (context) => GenericDialog(
                            description: state.errorText,
                            isErrorDialog: true,
                          ),
                        );
                        break;
                      case WidgetStatus.success:
                        context.read<GeneralCubit>().updateLocalProfile(
                          name: state.updatedUserDetail!.name!,
                          url: state.updatedUserDetail!.url!,
                        );

                        showDialog<void>(
                          context: context,
                          barrierDismissible: false,
                          builder: (context) => GenericDialog(
                            title: "Changes Saved",
                            description:
                                '''Your information has been '''
                                '''successfully updated.''',
                            onAccept: () {
                              Navigator.pop(context);
                              Navigator.pop(context);
                            },
                          ),
                        );
                        break;
                      default:
                        break;
                    }
                  },
                  buildWhen: (p, c) =>
                      (p.updateDetailsStatus != c.updateDetailsStatus),
                  builder: (context, state) {
                    return Stack(
                      children: [
                        const _View(),
                        if (state.updateDetailsStatus == WidgetStatus.loading)
                          const Center(child: LoadingIndicator()),
                      ],
                    );
                  },
                );
            }
          },
        ),
      ),
    );
  }
}

class _View extends StatefulWidget {
  const _View();

  @override
  State<_View> createState() => _ViewState();
}

class _ViewState extends State<_View> {
  late MenuCubit _cubit;

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  late TextEditingController _usernameCont;
  //late TextEditingController _emailCont;
  late TextEditingController _fullnameCont;
  late TextEditingController _phoneCont;

  @override
  void initState() {
    _cubit = context.read<MenuCubit>();
    _usernameCont = TextEditingController(
      text: _cubit.state.userDetail?.username,
    );
    // _emailCont = TextEditingController(text: _cubit.state.userDetail?.email);
    _fullnameCont = TextEditingController(text: _cubit.state.userDetail?.name);
    _phoneCont = TextEditingController(text: _cubit.state.userDetail?.phone);
    super.initState();
  }

  @override
  void dispose() {
    _usernameCont.dispose();
    // _emailCont.dispose();
    _fullnameCont.dispose();
    _phoneCont.dispose();
    super.dispose();
  }

  // Validando que al menos un campo del formulario haya sido editado
  bool _isValidForm() {
    if (_usernameCont.text != _cubit.state.userDetail?.username ||
        //_emailCont.text != _cubit.state.userDetail?.email ||
        _fullnameCont.text != _cubit.state.userDetail?.name ||
        _phoneCont.text != _cubit.state.userDetail?.phone ||
        _cubit.state.photo != null ||
        _cubit.state.userDetail?.gender != _cubit.state.genderSelected) {
      return true;
    } else {
      return false;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.max,
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Expanded(
          child: Form(
            key: _formKey,
            child: ListView(
              shrinkWrap: true,
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
              children: [
                BlocBuilder<MenuCubit, MenuState>(
                  buildWhen: (p, c) => (p.photo != c.photo),
                  builder: (context, state) {
                    return SelectProfileImage(
                      path: state.photo?.path ?? state.userDetail?.url,
                      onGetImage: (image) => _cubit.setPhoto(image.file),
                    );
                  },
                ),
                const SizedBox(height: 32),
                GenericFormInput(
                  hintText: "Username",
                  textController: _usernameCont,
                  prefixIcon: Icons.person_rounded,
                  textInputType: TextInputType.text,
                  validator: (value) => Validators.usernameValidator(value),
                  onChanged: (value) => _cubit.setUsername(value),
                ),
                const SizedBox(height: 24),
                // GenericFormInput(
                //   hintText: "Email Address",
                //   textController: _emailCont,
                //   prefixIcon: Icons.email_rounded,
                //   textInputType: TextInputType.emailAddress,
                //   validator: (value) => Validators.emailValidation(value),
                //   onChanged: (value) => _cubit.setEmail(value),
                // ),
                // const SizedBox(height: 24),
                GenericFormInput(
                  hintText: "Name",
                  textController: _fullnameCont,
                  prefixIcon: Icons.person_rounded,
                  textInputType: TextInputType.name,
                  textCapitalization: TextCapitalization.words,
                  validator: (value) => Validators.onlyLettersValidator(value),
                  onChanged: (value) => _cubit.setName(value),
                ),
                const SizedBox(height: 24),
                GenericFormInput(
                  hintText: "Phone Number",
                  textController: _phoneCont,
                  prefixIcon: Icons.phone_rounded,
                  textInputType: TextInputType.phone,
                  validator: (value) => Validators.phoneValidator(value),
                  onChanged: (value) => _cubit.setPhone(value),
                ),
                const SizedBox(height: 24),
                const _GenderSection(),
              ],
            ),
          ),
        ),
        BlocBuilder<MenuCubit, MenuState>(
          buildWhen: (p, c) =>
              (p.username != c.username ||
              p.email != c.email ||
              p.name != c.name ||
              p.phone != c.phone ||
              p.photo != c.photo ||
              p.genderSelected != c.genderSelected),
          builder: (context, state) {
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
              child: GenericButton(
                text: "Update Profile",
                onTap: (_isValidForm())
                    ? () async {
                        FocusScope.of(context).unfocus();
                        FocusManager.instance.primaryFocus?.unfocus();

                        if (_formKey.currentState!.validate()) {
                          _cubit.updateProfile();
                        }
                      }
                    : null,
              ),
            );
          },
        ),
      ],
    );
  }
}

class _GenderSection extends StatelessWidget {
  const _GenderSection();

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          "Select your gender identity",
          style: TextStyle(fontWeight: FontWeight.w400),
        ),
        const SizedBox(height: 24),
        BlocBuilder<MenuCubit, MenuState>(
          buildWhen: (p, c) => (p.genderSelected != c.genderSelected),
          builder: (context, state) {
            return Row(
              children: [
                GenderComponent(
                  value: Gender.male,
                  isSelected: (state.genderSelected == Gender.male),
                  onPressed: () {
                    context.read<MenuCubit>().setGender(Gender.male);
                  },
                ),
                const SizedBox(width: 14),
                GenderComponent(
                  value: Gender.female,
                  isSelected: (state.genderSelected == Gender.female),
                  onPressed: () {
                    context.read<MenuCubit>().setGender(Gender.female);
                  },
                ),
                const SizedBox(width: 14),
                GenderComponent(
                  value: Gender.other,
                  isSelected: (state.genderSelected == Gender.other),
                  onPressed: () {
                    context.read<MenuCubit>().setGender(Gender.other);
                  },
                ),
              ],
            );
          },
        ),
      ],
    );
  }
}
