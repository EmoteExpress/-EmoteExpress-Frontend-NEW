import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:emote_express/ui/menu/menu.dart';
import 'package:emote_express/utils/navigator_utils.dart';
import 'package:emote_express/ui/cubit/general_cubit.dart';
import 'package:emote_express/widgets/generic/generic.dart';
import 'package:emote_express/models/generic/generic_enums.dart';
import 'package:emote_express/widgets/buttons/generic_button.dart';
import 'package:emote_express/core/constants/constants_colors.dart';

class MenuView extends StatelessWidget {
  const MenuView({super.key});

  static const String routeName = 'menu_view';

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => MenuCubit()
        ..init(
          context
                  .read<GeneralCubit>()
                  .state
                  .homeResponseModel
                  ?.isPrivateProfile ??
              false,
        ),
      child: Scaffold(
        appBar: AppBar(title: const Text("Menu")),
        body: BlocBuilder<GeneralCubit, GeneralState>(
          buildWhen: (p, c) => (p.logOutStatus != c.logOutStatus),
          builder: (context, state) {
            return Stack(
              children: [
                const _View(),
                if (state.logOutStatus == WidgetStatus.loading)
                  const Center(child: LoadingIndicator()),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _View extends StatefulWidget {
  const _View();

  @override
  State<_View> createState() => _ViewState();
}

class _ViewState extends State<_View> {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(24, 0, 24, 24),
            children: [
              const _Header(),
              const SizedBox(height: 18),
              _CustomMenuListTile(
                tile: "Edit Profile",
                onTap: () {
                  Navigator.pushNamed(context, EditProfileView.routeName);
                },
              ),
              const SizedBox(height: 18),
              _CustomMenuListTile(tile: "Terms and Conditions", onTap: () {}),
              const SizedBox(height: 18),
              _CustomMenuListTile(tile: "Privacy Policies", onTap: () {}),
              const SizedBox(height: 18),
              BlocConsumer<MenuCubit, MenuState>(
                listenWhen: (p, c) => (p.privacyStatus != c.privacyStatus),
                listener: (context, state) {
                  switch (state.privacyStatus) {
                    case WidgetStatus.success:
                      context.read<GeneralCubit>().updateLocalPrivacy(
                        !state.isPublicAccout,
                      );
                      break;
                    default:
                  }
                },
                buildWhen: (p, c) => (p.isPublicAccout != c.isPublicAccout),
                builder: (context, state) {
                  return _CustomMenuListTile(
                    tile: "Public Account",
                    icon: Switch(
                      value: state.isPublicAccout,
                      activeTrackColor: ConstantColors.cffF6912E,
                      inactiveThumbColor: ConstantColors.cffF6912E,
                      inactiveTrackColor: ConstantColors.cff08080D.withValues(
                        alpha: 0.8,
                      ),
                      trackOutlineColor: WidgetStatePropertyAll(
                        (state.isPublicAccout)
                            ? ConstantColors.cffF6912E
                            : ConstantColors.cff08080D.withValues(alpha: 0.8),
                      ),
                      onChanged: (value) {
                        context.read<MenuCubit>().updateUserPrivacy();
                      },
                    ),
                  );
                },
              ),
            ],
          ),
        ),
        BlocBuilder<GeneralCubit, GeneralState>(
          buildWhen: (p, c) => (p.logOutStatus != c.logOutStatus),
          builder: (context, state) {
            return SafeArea(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: GenericButton(
                  text: "Log out",
                  onTap: () {
                    NavigatorUtils.resetSession(context, needsLogOut: true);
                  },
                ),
              ),
            );
          },
        ),
      ],
    );
  }
}

class _Header extends StatelessWidget {
  const _Header();

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<GeneralCubit, GeneralState>(
      buildWhen: (p, c) => (p.homeResponseModel != c.homeResponseModel),
      builder: (context, state) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ProfileImageComponent(path: state.homeResponseModel?.dataUser?.url),
            const SizedBox(height: 16),
            Text(
              state.homeResponseModel?.dataUser?.name ?? "N/A",
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontSize: 24,
                color: Colors.white,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        );
      },
    );
  }
}

class _CustomMenuListTile extends StatelessWidget {
  final String? tile;
  final Widget? icon;
  final VoidCallback? onTap;

  const _CustomMenuListTile({this.onTap, this.icon, this.tile});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      onTap: onTap,
      title: Text(
        tile ?? "N/A",
        maxLines: 2,
        overflow: TextOverflow.ellipsis,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 16,
          fontWeight: FontWeight.w500,
        ),
      ),
      tileColor: ConstantColors.cff1F2128,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(8)),
      ),
      trailing: (icon != null)
          ? icon
          : const Icon(
              Icons.arrow_forward_ios_rounded,
              color: Colors.white,
              size: 16,
            ),
    );
  }
}
