part of 'menu_cubit.dart';

class MenuState extends Equatable {
  const MenuState({
    this.errorText = '',
    this.isPublicAccout = false,
    this.userDetail,
    this.detailStatus = WidgetStatus.initial,
    this.photo,
    this.genderSelected,
    this.username,
    this.email,
    this.name,
    this.phone,
    this.updateDetailsStatus = WidgetStatus.initial,
    this.updatedUserDetail,
    this.privacyStatus = WidgetStatus.initial,
  });

  // General
  final String errorText;
  final bool isPublicAccout;
  final WidgetStatus? privacyStatus;

  // Edit Profile
  final File? photo;
  final Gender? genderSelected;
  final String? username;
  final String? email;
  final String? name;
  final String? phone;
  final WidgetStatus detailStatus;
  final UserDetailResponseModel? userDetail;
  final WidgetStatus updateDetailsStatus;
  final UserDetailResponseModel? updatedUserDetail;

  @override
  List<Object?> get props => [
        errorText,
        isPublicAccout,
        userDetail,
        detailStatus,
        photo,
        genderSelected,
        username,
        email,
        name,
        phone,
        updateDetailsStatus,
        updatedUserDetail,
        privacyStatus,
      ];

  MenuState copyWith({
    String? errorText,
    bool? isPublicAccout,
    Wrapped<UserDetailResponseModel?>? userDetail,
    WidgetStatus? detailStatus,
    Wrapped<File?>? photo,
    Wrapped<Gender?>? genderSelected,
    Wrapped<String?>? username,
    Wrapped<String?>? email,
    Wrapped<String?>? name,
    Wrapped<String?>? phone,
    WidgetStatus? updateDetailsStatus,
    Wrapped<UserDetailResponseModel?>? updatedUserDetail,
    WidgetStatus? privacyStatus,
  }) {
    return MenuState(
      errorText: errorText ?? this.errorText,
      isPublicAccout: isPublicAccout ?? this.isPublicAccout,
      userDetail: userDetail != null ? userDetail.value : this.userDetail,
      detailStatus: detailStatus ?? this.detailStatus,
      photo: photo != null ? photo.value : this.photo,
      genderSelected:
          genderSelected != null ? genderSelected.value : this.genderSelected,
      username: username != null ? username.value : this.username,
      email: email != null ? email.value : this.email,
      name: name != null ? name.value : this.name,
      phone: phone != null ? phone.value : this.phone,
      updateDetailsStatus: updateDetailsStatus ?? this.updateDetailsStatus,
      updatedUserDetail: updatedUserDetail != null
          ? updatedUserDetail.value
          : this.updatedUserDetail,
      privacyStatus: privacyStatus ?? this.privacyStatus,
    );
  }
}
