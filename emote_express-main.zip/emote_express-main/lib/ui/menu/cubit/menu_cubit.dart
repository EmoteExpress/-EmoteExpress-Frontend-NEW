import 'dart:io';

import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:emote_express/models/generic/wrapped.dart';
import 'package:emote_express/providers/generic_provider.dart';
import 'package:emote_express/models/generic/generic_enums.dart';
import 'package:emote_express/models/generic/user_detail_response_model.dart';
import 'package:emote_express/models/authentication/register_request_model.dart';

part 'menu_state.dart';

class MenuCubit extends Cubit<MenuState> {
  MenuCubit() : super(const MenuState());

  final _genericProvider = GenericProvider();

  void init(bool value) {
    emit(state.copyWith(isPublicAccout: !value));
  }

  // =======================================================================
  // Edit Profile
  // =======================================================================

  void setUsername(String? value) {
    emit(state.copyWith(username: Wrapped.value(value)));
  }

  void setEmail(String? value) {
    emit(state.copyWith(email: Wrapped.value(value)));
  }

  void setName(String? value) {
    emit(state.copyWith(name: Wrapped.value(value)));
  }

  void setPhone(String? value) {
    emit(state.copyWith(phone: Wrapped.value(value)));
  }

  void setPhoto(File? photo) {
    emit(state.copyWith(photo: Wrapped.value(photo)));
  }

  void setGender(Gender? value) {
    emit(state.copyWith(genderSelected: Wrapped.value(value)));
  }

  Future<void> getUserDetails() async {
    emit(state.copyWith(detailStatus: WidgetStatus.loading));

    final response = await _genericProvider.getUserDetails();

    return response.fold((l) {
      emit(state.copyWith(
          detailStatus: WidgetStatus.error, errorText: l.details));
    }, (r) async {
      emit(state.copyWith(
        detailStatus: WidgetStatus.success,
        userDetail: Wrapped.value(r),
        genderSelected: Wrapped.value(r.gender),
      ));
    });
  }

  Future<void> updateProfile() async {
    if (state.updateDetailsStatus == WidgetStatus.loading) return;
    emit(state.copyWith(updateDetailsStatus: WidgetStatus.loading));

    // Enviando unicamente los campos que han sido editados
    final detail = RegisterRequestModel(
      userName: (state.username != state.userDetail?.username)
          ? state.username
          : null,
      email: (state.email != state.userDetail?.email) ? state.email : null,
      fullName: (state.name != state.userDetail?.name) ? state.name : null,
      phone: (state.phone != state.userDetail?.phone) ? state.phone : null,
      gender: (state.genderSelected != state.userDetail?.gender)
          ? state.genderSelected
          : null,
      image: state.photo,
    );

    final response = await _genericProvider.updateUserDetails(detail: detail);

    return response.fold((l) {
      emit(state.copyWith(
          updateDetailsStatus: WidgetStatus.error, errorText: l.details));
    }, (r) async {
      emit(state.copyWith(
        updateDetailsStatus: WidgetStatus.success,
        updatedUserDetail: Wrapped.value(r),
      ));
    });
  }

  void updateUserPrivacy() async {
    emit(state.copyWith(privacyStatus: WidgetStatus.loading));

    final response = await _genericProvider.updateUserPrivacy();

    return response.fold((l) {
      emit(state.copyWith(
          privacyStatus: WidgetStatus.error, errorText: l.details));
    }, (r) async {
      emit(
        state.copyWith(
          privacyStatus: WidgetStatus.success,
          isPublicAccout: !state.isPublicAccout,
        ),
      );
    });
  }
}
