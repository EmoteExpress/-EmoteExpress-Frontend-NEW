import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:emote_express/models/generic/generic.dart';
import 'package:emote_express/providers/auth_provider.dart';
import 'package:emote_express/providers/generic_provider.dart';

part 'general_state.dart';

class GeneralCubit extends Cubit<GeneralState> {
  GeneralCubit() : super(const GeneralState());

  final _authProvider = AuthProvider();
  final _genericProvider = GenericProvider();

  void clean() {
    emit(const GeneralState());
  }

  void setCarouselIndex(int value) {
    emit(state.copyWith(carouselIndex: value));
  }

  // ========================================================================
  // Home
  // ========================================================================

  Future<void> getHome() async {
    emit(state.copyWith(homeStatus: WidgetStatus.loading));

    final response = await _genericProvider.getHome();

    return response.fold((l) {
      emit(
          state.copyWith(homeStatus: WidgetStatus.error, errorText: l.details));
    }, (r) async {
      emit(state.copyWith(
        homeStatus: WidgetStatus.success,
        homeResponseModel: Wrapped.value(r),
      ));
    });
  }

  // Actualizacion de variable local de la informacion del usuario
  void updateLocalProfile({required String name, required String url}) {
    emit(state.copyWith(
        homeResponseModel: Wrapped.value(state.homeResponseModel?.copyWith(
            dataUser: state.homeResponseModel?.dataUser?.copyWith(
      name: name,
      url: url,
    )))));
  }

  void updateLocalPrivacy(bool value) {
    emit(state.copyWith(
        homeResponseModel: Wrapped.value(
            state.homeResponseModel?.copyWith(isPrivateProfile: value))));
  }

  // ========================================================================
  // Log out
  // ========================================================================

  Future<void> logOut() async {
    if (state.logOutStatus == WidgetStatus.loading) return;
    emit(state.copyWith(logOutStatus: WidgetStatus.loading));

    final response = await _authProvider.logOut();

    return response.fold((l) {
      emit(state.copyWith(
          logOutStatus: WidgetStatus.error, errorText: l.details));
    }, (r) async {
      emit(state.copyWith(logOutStatus: WidgetStatus.success));
    });
  }
}
