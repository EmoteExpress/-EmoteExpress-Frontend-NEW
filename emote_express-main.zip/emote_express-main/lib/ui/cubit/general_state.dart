part of 'general_cubit.dart';

class GeneralState extends Equatable {
  const GeneralState({
    this.errorText = '',
    this.carouselIndex = 0,
    this.logOutStatus = WidgetStatus.initial,
    this.homeStatus = WidgetStatus.initial,
    this.homeResponseModel,
  });

  // General
  final String? errorText;

  // Onboarding
  final int carouselIndex;

  // Log out
  final WidgetStatus logOutStatus;

  // Home
  final WidgetStatus homeStatus;
  final HomeResponseModel? homeResponseModel;

  @override
  List<Object?> get props => [
        errorText,
        carouselIndex,
        logOutStatus,
        homeStatus,
        homeResponseModel,
      ];

  GeneralState copyWith({
    String? errorText,
    int? carouselIndex,
    WidgetStatus? logOutStatus,
    WidgetStatus? homeStatus,
    Wrapped<HomeResponseModel?>? homeResponseModel,
  }) {
    return GeneralState(
      errorText: errorText ?? this.errorText,
      carouselIndex: carouselIndex ?? this.carouselIndex,
      logOutStatus: logOutStatus ?? this.logOutStatus,
      homeStatus: homeStatus ?? this.homeStatus,
      homeResponseModel: homeResponseModel != null
          ? homeResponseModel.value
          : this.homeResponseModel,
    );
  }
}
