import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:emote_express/ui/home/views/search_word_view.dart';
import 'package:emote_express/core/constants/constants_icons.dart';
import 'package:emote_express/core/constants/constants_images.dart';
import 'package:emote_express/core/constants/constants_colors.dart';

class EmotionCard extends StatelessWidget {
  const EmotionCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 200,
      margin: const EdgeInsets.symmetric(horizontal: 20),
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(17)),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.black..withValues(alpha: 0.8),
          borderRadius: BorderRadius.circular(17),
        ),
        child: Row(
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 24, right: 12),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SvgPicture.asset(
                    ConstantIcons.logoWhite,
                    height: 40,
                    width: 41,
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    "How are\nyou feeling\ntoday?",
                    style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(height: 8),
                  _Button(
                    text: "Express Myself",
                    color: ConstantColors.cffF6912E,
                    onTap: () {
                      Navigator.pushNamed(context, SearchWordView.routeName);
                    },
                  ),
                ],
              ),
            ),
            Expanded(
              child: Image.asset(
                ConstantImages.imagesGroup,
                fit: BoxFit.fill,
                filterQuality: FilterQuality.high,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Button extends StatelessWidget {
  final String text;
  final Color color;
  final VoidCallback? onTap;

  const _Button({
    required this.text,
    this.color = ConstantColors.cffF6912E,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: onTap,
      style: ButtonStyle(
        padding: const WidgetStatePropertyAll(
          EdgeInsets.symmetric(vertical: 7, horizontal: 20),
        ),
        shape: const WidgetStatePropertyAll(
          RoundedRectangleBorder(
            side: BorderSide(color: Color(0xFF4C4D56), width: 1),
            borderRadius: BorderRadius.all(Radius.circular(8)),
          ),
        ),
        backgroundColor: (onTap != null) ? WidgetStatePropertyAll(color) : null,
      ),
      child: Text(
        text,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w700,
          color: (onTap != null) ? ConstantColors.white : Colors.grey,
        ),
      ),
    );
  }
}
