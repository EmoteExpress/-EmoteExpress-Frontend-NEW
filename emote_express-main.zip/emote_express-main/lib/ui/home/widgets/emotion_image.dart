import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:emote_express/core/constants/constants_icons.dart';
import 'package:emote_express/widgets/generic/generic_network_image.dart';

class EmotionImage extends StatelessWidget {
  const EmotionImage(
      {super.key, this.path, this.text, this.profileUrl, this.onPressed});

  final String? path;
  final String? text;
  final String? profileUrl;
  final VoidCallback? onPressed;

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        GestureDetector(
          onTap: onPressed,
          child: ClipRRect(
            borderRadius: const BorderRadius.all(Radius.circular(12)),
            child: Container(
              color: Colors.grey,
              width: double.infinity,
              height: double.infinity,
              child: CachedNetworkImage(
                imageUrl: path ?? '',
                fit: BoxFit.cover,
                filterQuality: FilterQuality.medium,
                errorWidget: (context, url, error) {
                  return const Center(
                    child: Icon(
                      Icons.error_rounded,
                      size: 50,
                      color: Colors.white,
                    ),
                  );
                },
                placeholder: (context, url) {
                  return Center(
                    child: SvgPicture.asset(ConstantIcons.logoWhite),
                  );
                },
              ),
            ),
          ),
        ),
        ((text ?? "").isNotEmpty)
            ? Align(
                alignment: Alignment.bottomLeft,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Flexible(
                          child: _EmotionTagComponent(
                            text: text!,
                            profileUrl: profileUrl,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              )
            : const SizedBox.shrink(),
      ],
    );
  }
}

class _EmotionTagComponent extends StatelessWidget {
  const _EmotionTagComponent({
    required this.text,
    this.profileUrl,
    //this.padding = const EdgeInsets.all(5),
  });

  final String text;
  final String? profileUrl;
  //final EdgeInsets padding;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(8),
      padding: const EdgeInsets.all(5),
      alignment: Alignment.center,
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.all(Radius.circular(20)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (profileUrl != null)
            GenericNetworkImage(
              path: profileUrl,
              size: 24,
            ),
          if (profileUrl != null) const SizedBox(width: 5),
          Flexible(
            child: Text(
              text,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: Color(0xFF334155),
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
