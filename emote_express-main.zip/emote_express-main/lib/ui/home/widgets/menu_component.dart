import 'package:flutter/material.dart';
import 'package:emote_express/ui/menu/views/menu_view.dart';
import 'package:emote_express/ui/posts/views/feed_view.dart';
import 'package:emote_express/ui/posts/views/posts_view.dart';
import 'package:emote_express/core/constants/constants_colors.dart';
import 'package:emote_express/ui/activity/views/brain_activity_view.dart';

class MenuComponent extends StatelessWidget {
  const MenuComponent({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Container(
        color: ConstantColors.cff111114,
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Expanded(
              child: _CustomMenuButton(
                title: "Feed",
                isSelected: false,
                icon: Icons.auto_awesome_mosaic_rounded,
                onPressed: () =>
                    Navigator.pushNamed(context, FeedView.routeName),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _CustomMenuButton(
                title: "Activity",
                isSelected: false,
                icon: Icons.psychology_alt_rounded,
                onPressed: () =>
                    Navigator.pushNamed(context, BrainActivityView.routeName),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _CustomMenuButton(
                title: "Post",
                isSelected: false,
                icon: Icons.feed_rounded,
                onPressed: () =>
                    Navigator.pushNamed(context, PostsView.routeName),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _CustomMenuButton(
                title: "Menu",
                isSelected: false,
                icon: Icons.menu_rounded,
                onPressed: () =>
                    Navigator.pushNamed(context, MenuView.routeName),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _CustomMenuButton extends StatelessWidget {
  const _CustomMenuButton({
    required this.title,
    required this.icon,
    required this.isSelected,
    required this.onPressed,
  });

  final String title;
  final IconData icon;
  final bool isSelected;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return IconButton(
      onPressed: onPressed,
      color: (isSelected) ? Colors.red : Colors.white,
      icon: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon),
          const SizedBox(height: 3),
          Text(
            title,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontWeight: FontWeight.w500),
          ),
        ],
      ),
    );
  }
}
