import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:emote_express/models/generic/generic.dart';
import 'package:emote_express/providers/generic_provider.dart';

part 'home_state.dart';

class HomeCubit extends Cubit<HomeState> {
  HomeCubit() : super(const HomeState());

  final _genericProvider = GenericProvider();

  void setQuery(String value) {
    (value.isEmpty)
        ? emit(state.copyWith(query: value, isEmoteExpress: true))
        : emit(state.copyWith(query: value));
  }

  // TODO integrar paginado
  Future<void> searchEmotions() async {
    emit(state.copyWith(getEmotionsStatus: WidgetStatus.loading));

    final response = await _genericProvider.searchEmotions(query: state.query);

    return response.fold((l) {
      emit(state.copyWith(
          getEmotionsStatus: WidgetStatus.error, errorText: l.details));
    }, (r) async {
      emit(state.copyWith(
        getEmotionsStatus: WidgetStatus.success,
        emotions: Wrapped.value(r),
      ));
    });
  }

  // ======================================================================
  // Recommended for you
  // ======================================================================

  // TODO integrar paginado
  Future<void> getRecommended() async {
    emit(state.copyWith(recommendedStatus: WidgetStatus.loading));

    final response = await _genericProvider.getRecommendations();

    return response.fold((l) {
      emit(state.copyWith(
          recommendedStatus: WidgetStatus.error, errorText: l.details));
    }, (r) async {
      emit(state.copyWith(
        recommendedStatus: WidgetStatus.success,
        recommendedModel: Wrapped.value(r),
      ));
    });
  }
}
