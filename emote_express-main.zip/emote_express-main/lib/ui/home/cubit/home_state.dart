part of 'home_cubit.dart';

class HomeState extends Equatable {
  const HomeState({
    this.errorText = '',
    this.getEmotionsStatus = WidgetStatus.initial,
    this.emotions,
    this.query = "",
    this.recommendedStatus = WidgetStatus.initial,
    this.recommendedModel,
    this.isEmoteExpress = false,
  });

  // General
  final String errorText;
  final bool isEmoteExpress;
  final String query;

  // Search word view
  final WidgetStatus getEmotionsStatus;
  final ListSearchEmotionsResponseModel? emotions;

  // Recommended for you
  final WidgetStatus recommendedStatus;
  final ListRecommendedEmotionsResponseModel? recommendedModel;

  @override
  List<Object?> get props => [
        errorText,
        getEmotionsStatus,
        emotions,
        query,
        recommendedStatus,
        recommendedModel,
        isEmoteExpress,
      ];

  HomeState copyWith({
    String? errorText,
    WidgetStatus? getEmotionsStatus,
    Wrapped<ListSearchEmotionsResponseModel?>? emotions,
    String? query,
    WidgetStatus? recommendedStatus,
    Wrapped<ListRecommendedEmotionsResponseModel?>? recommendedModel,
    bool? isEmoteExpress,
  }) {
    return HomeState(
      errorText: errorText ?? this.errorText,
      getEmotionsStatus: getEmotionsStatus ?? this.getEmotionsStatus,
      emotions: emotions != null ? emotions.value : this.emotions,
      query: query ?? this.query,
      recommendedStatus: recommendedStatus ?? this.recommendedStatus,
      recommendedModel: recommendedModel != null
          ? recommendedModel.value
          : this.recommendedModel,
      isEmoteExpress: isEmoteExpress ?? this.isEmoteExpress,
    );
  }
}
