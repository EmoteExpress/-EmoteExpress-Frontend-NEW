import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:emote_express/ui/home/home.dart';
import 'package:emote_express/ui/cubit/cubit.dart';
import 'package:emote_express/widgets/widgets.dart';
import 'package:emote_express/ui/survey/survey.dart';
import 'package:emote_express/models/generic/generic_enums.dart';
import 'package:emote_express/core/constants/constants_colors.dart';

class HomeView extends StatelessWidget {
  const HomeView({super.key});

  static const String routeName = 'home_view';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: BlocConsumer<GeneralCubit, GeneralState>(
        listenWhen: (p, c) => (p.homeStatus != c.homeStatus),
        listener: (context, state) {
          switch (state.homeStatus) {
            case WidgetStatus.error:
              showDialog<void>(
                context: context,
                barrierDismissible: false,
                builder: (context) => GenericDialog(
                  description: state.errorText,
                  isErrorDialog: true,
                ),
              );
              break;

            case WidgetStatus.success:

              // Daily Survey
              if (state.homeResponseModel?.quizCompleted == false) {
                showDialog<void>(
                  context: context,
                  barrierDismissible: false,
                  builder: (context) => PopScope(
                    canPop: false,
                    child: GenericDialog(
                      title: "How are you feeling today?",
                      description:
                          '''Check in with yourself! How are you '''
                          '''feeling emotionally? Take a quick survey to '''
                          '''help us understand your well-being.''',
                      onAccept: () {
                        Navigator.pop(context);
                        Navigator.pushNamed(context, SurveyView.routeName);
                      },
                    ),
                  ),
                );
              }
              break;

            default:
              break;
          }
        },
        buildWhen: (p, c) => (p.homeStatus != c.homeStatus),
        builder: (context, state) {
          return Stack(
            children: [
              const Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Expanded(child: GenericLayout(child: _View())),
                  MenuComponent(),
                ],
              ),
              if (state.homeStatus == WidgetStatus.loading)
                const Center(child: LoadingIndicator()),
            ],
          );
        },
      ),
    );
  }
}

class _View extends StatefulWidget {
  const _View();

  @override
  State<_View> createState() => _ViewState();
}

class _ViewState extends State<_View> {
  late GeneralCubit _cubit;

  @override
  void initState() {
    _cubit = context.read<GeneralCubit>();
    _cubit.getHome();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SafeArea(
          child: BlocBuilder<GeneralCubit, GeneralState>(
            buildWhen: (p, c) => (p.homeResponseModel != c.homeResponseModel),
            builder: (context, state) {
              return _WelcomeText(state.homeResponseModel?.dataUser?.name);
            },
          ),
        ),
        const EmotionCard(),
        const SizedBox(height: 8),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Row(
            mainAxisSize: MainAxisSize.max,
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Flexible(
                child: Text(
                  "Recommended for you",
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontWeight: FontWeight.w600, fontSize: 18),
                ),
              ),
              const SizedBox(width: 10),
              TextButton(
                onPressed: () {
                  Navigator.pushNamed(context, RecommendationView.routeName);
                },
                child: const Text(
                  "Show All",
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    color: ConstantColors.cffFFBE26,
                  ),
                ),
              ),
            ],
          ),
        ),
        BlocBuilder<GeneralCubit, GeneralState>(
          buildWhen: (p, c) => (p.homeResponseModel != c.homeResponseModel),
          builder: (context, state) {
            final int length =
                ((state.homeResponseModel?.recommended ?? [])).length;

            return Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  vertical: 12,
                  horizontal: 20,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Expanded(
                      child: Row(
                        children: [
                          (length > 1)
                              ? _RecommendedEmotion(
                                  path: state
                                      .homeResponseModel
                                      ?.recommended?[0]
                                      .url,
                                  value: state
                                      .homeResponseModel
                                      ?.recommended?[0]
                                      .emotion,
                                )
                              : const SizedBox.shrink(),
                          (length >= 2)
                              ? const SizedBox(width: 16)
                              : const SizedBox.shrink(),
                          (length >= 2)
                              ? _RecommendedEmotion(
                                  path: state
                                      .homeResponseModel
                                      ?.recommended?[1]
                                      .url,
                                  value: state
                                      .homeResponseModel
                                      ?.recommended?[1]
                                      .emotion,
                                )
                              : const SizedBox.shrink(),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    Expanded(
                      child: Row(
                        children: [
                          (length >= 3)
                              ? _RecommendedEmotion(
                                  path: state
                                      .homeResponseModel
                                      ?.recommended?[2]
                                      .url,
                                  value: state
                                      .homeResponseModel
                                      ?.recommended?[2]
                                      .emotion,
                                )
                              : const SizedBox.shrink(),
                          (length >= 4)
                              ? const SizedBox(width: 16)
                              : const SizedBox.shrink(),
                          (length >= 4)
                              ? _RecommendedEmotion(
                                  path: state
                                      .homeResponseModel
                                      ?.recommended?[3]
                                      .url,
                                  value: state
                                      .homeResponseModel
                                      ?.recommended?[3]
                                      .emotion,
                                )
                              : const SizedBox.shrink(),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ],
    );
  }
}

class _RecommendedEmotion extends StatelessWidget {
  const _RecommendedEmotion({this.path, this.value});

  final String? path;
  final String? value;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: EmotionImage(
        path: path,
        text: value,
        onPressed: (value != null && path != null)
            ? () {
                Navigator.push<void>(
                  context,
                  MaterialPageRoute(
                    builder: (context) => SearchWordView(query: value),
                  ),
                );
              }
            : null,
      ),
    );
  }
}

class _WelcomeText extends StatelessWidget {
  const _WelcomeText(this.name);

  final String? name;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
      child: RichText(
        text: TextSpan(
          style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 20),
          children: [
            TextSpan(text: (name != null) ? "Hello $name, " : "... "),
            const TextSpan(
              text: "empower yourself today.",
              style: TextStyle(fontWeight: FontWeight.w300),
            ),
          ],
        ),
      ),
    );
  }
}
