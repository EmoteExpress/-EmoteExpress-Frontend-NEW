import 'package:flutter/material.dart';
import 'package:emote_express/utils/navigator_utils.dart';
import 'package:emote_express/widgets/buttons/generic_button.dart';

class HomeDefaultView extends StatelessWidget {
  const HomeDefaultView({super.key});

  static const String routeName = 'home_default_view';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text("Home Default Page"),
              const SizedBox(height: 24),
              GenericButton(
                text: "Log out",
                onTap: () {
                  NavigatorUtils.resetSession(context, needsLogOut: true);
                },
              )
            ],
          ),
        ),
      ),
    );
  }
}
