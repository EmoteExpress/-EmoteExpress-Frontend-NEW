import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:emote_express/ui/home/home.dart';
import 'package:emote_express/ui/posts/views/views.dart';
import 'package:emote_express/widgets/generic/generic.dart';
import 'package:emote_express/widgets/input/search_input.dart';
import 'package:emote_express/models/generic/generic_enums.dart';

class SearchWordView extends StatelessWidget {
  const SearchWordView({super.key, this.query});

  static const String routeName = 'search_word_view';

  final String? query;

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (BuildContext context) => HomeCubit()..setQuery(query ?? ""),
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: AppBar(
          title: (query != null)
              ? const Text("Search Emotions")
              : const Text("Emote Express"),
        ),
        floatingActionButton: (query == null)
            ? BlocBuilder<HomeCubit, HomeState>(
                buildWhen: (p, c) => (p.isEmoteExpress != c.isEmoteExpress ||
                    p.getEmotionsStatus != c.getEmotionsStatus),
                builder: (context, state) {
                  return (state.getEmotionsStatus == WidgetStatus.success &&
                          state.isEmoteExpress == true)
                      ? CustomFloatingButton(
                          onPressed: () {
                            final cubit = context.read<HomeCubit>();
                            cubit.searchEmotions();
                          },
                        )
                      : const SizedBox.shrink();
                })
            : null,
        floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
        body: const _View(),
      ),
    );
  }
}

class _View extends StatefulWidget {
  const _View();

  @override
  State<_View> createState() => _ViewState();
}

class _ViewState extends State<_View> {
  late HomeCubit _cubit;
  late TextEditingController _controller;

  @override
  void initState() {
    _cubit = context.read<HomeCubit>();
    _controller = TextEditingController(text: _cubit.state.query);
    _cubit.searchEmotions();
    super.initState();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        BlocListener<HomeCubit, HomeState>(
          listenWhen: (p, c) => (p.query != c.query),
          listener: (context, state) {
            _controller.text = state.query;
          },
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 0, horizontal: 16),
            child: SearchInput(
              hintText: "Search emotions",
              textController: _controller,
              onChanged: (value) {
                _cubit.setQuery(value ?? "");

                if ((value ?? "").isNotEmpty) {
                  _cubit.searchEmotions();
                }
              },
            ),
          ),
        ),
        const SizedBox(height: 16),
        BlocBuilder<HomeCubit, HomeState>(
          buildWhen: (p, c) => (p.getEmotionsStatus != c.getEmotionsStatus),
          builder: (context, state) {
            switch (state.getEmotionsStatus) {
              case WidgetStatus.loading:
                return const Expanded(child: Center(child: LoadingAnimation()));
              case WidgetStatus.error:
                return Expanded(
                  child: Center(child: GenericError(text: state.errorText)),
                );
              default:
                return const Expanded(child: SafeArea(child: _RenderContent()));
            }
          },
        )
      ],
    );
  }
}

class _RenderContent extends StatelessWidget {
  const _RenderContent();

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<HomeCubit, HomeState>(
        buildWhen: (p, c) => (p.emotions != c.emotions),
        builder: (context, state) {
          if ((state.emotions?.data ?? []).isEmpty) {
            return const Center(
              child: Padding(
                padding: EdgeInsets.all(24.0),
                child: Text(
                  '''Sorry! No result found :( We're sorry what you were '''
                  '''looking for. Please try another word.''',
                  textAlign: TextAlign.center,
                ),
              ),
            );
          }

          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: 40,
                child: ListView.separated(
                  itemCount: state.emotions?.tags?.length ?? 0,
                  shrinkWrap: true,
                  scrollDirection: Axis.horizontal,
                  padding:
                      const EdgeInsets.symmetric(vertical: 0, horizontal: 16),
                  itemBuilder: (context, index) {
                    return GestureDetector(
                      onTap: () {
                        final cubit = context.read<HomeCubit>();

                        cubit.setQuery(state.emotions?.tags?[index] ?? "");
                        cubit.searchEmotions();
                      },
                      child: TagComponent(
                        text: state.emotions?.tags?[index] ?? "N/A",
                        padding: const EdgeInsets.symmetric(horizontal: 10),
                      ),
                    );
                  },
                  separatorBuilder: (context, index) =>
                      const SizedBox(width: 10),
                ),
              ),
              const SizedBox(height: 16),
              Expanded(
                child: GridView.builder(
                  itemCount: state.emotions?.data?.length ?? 0,
                  shrinkWrap: true,
                  keyboardDismissBehavior:
                      ScrollViewKeyboardDismissBehavior.onDrag,
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    mainAxisSpacing: 16,
                    crossAxisSpacing: 16,
                    childAspectRatio: 0.8,
                  ),
                  itemBuilder: (context, index) {
                    return EmotionImage(
                      path: state.emotions?.data?[index].url,
                      onPressed: () {
                        Navigator.push<void>(
                            context,
                            MaterialPageRoute(
                              builder: (context) => CreatePostView(
                                emotion: state.emotions?.data?[index],
                              ),
                            ));
                      },
                    );
                  },
                ),
              ),
            ],
          );
        });
  }
}

class TagComponent extends StatelessWidget {
  const TagComponent({
    super.key,
    required this.text,
    this.padding = const EdgeInsets.all(5),
  });

  final String text;
  final EdgeInsets padding;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding,
      alignment: Alignment.center,
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.all(Radius.circular(20)),
      ),
      child: Text(
        text,
        style: const TextStyle(
          color: Color(0xFF334155),
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }
}
