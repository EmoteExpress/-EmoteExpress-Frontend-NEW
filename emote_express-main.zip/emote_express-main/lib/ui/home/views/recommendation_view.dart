import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:emote_express/ui/home/home.dart';
import 'package:emote_express/widgets/generic/generic.dart';
import 'package:emote_express/models/generic/generic_enums.dart';

class RecommendationView extends StatelessWidget {
  const RecommendationView({super.key});

  static const String routeName = 'recommendation_view';

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => HomeCubit()..getRecommended(),
      child: Scaffold(
        appBar: AppBar(
          title: const Text("Recommended for you"),
        ),
        body: const SafeArea(child: _View()),
      ),
    );
  }
}

class _View extends StatelessWidget {
  const _View();

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<HomeCubit, HomeState>(
      buildWhen: (p, c) => (p.recommendedStatus != c.recommendedStatus),
      builder: (context, state) {
        switch (state.recommendedStatus) {
          case WidgetStatus.loading:
            return const Center(child: LoadingAnimation());
          case WidgetStatus.error:
            return Center(child: GenericError(text: state.errorText));
          default:
            return GridView.builder(
              itemCount: state.recommendedModel?.data?.length,
              shrinkWrap: true,
              padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 20),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 16,
                crossAxisSpacing: 16,
                childAspectRatio: 0.8,
              ),
              itemBuilder: (context, index) {
                return EmotionImage(
                  path: state.recommendedModel?.data?[index].url,
                  text: state.recommendedModel?.data?[index].emotion,
                  onPressed: () {
                    Navigator.push<void>(
                      context,
                      MaterialPageRoute(
                        builder: (context) => SearchWordView(
                            query:
                                state.recommendedModel?.data?[index].emotion),
                      ),
                    );
                  },
                );
              },
            );
        }
      },
    );
  }
}
