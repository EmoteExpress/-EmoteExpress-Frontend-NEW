import 'package:flutter/material.dart';
import 'package:emote_express/core/constants/constants_colors.dart';

class CustomFloatingButton extends StatelessWidget {
  const CustomFloatingButton({super.key, required this.onPressed});

  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return FloatingActionButton.extended(
      backgroundColor: ConstantColors.checkboxColor,
      elevation: 0,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(48)),
      ),
      label: const Icon(
        Icons.auto_awesome_rounded,
        color: Colors.white,
      ),
      icon: const Text(
        "New Emotion",
        style: TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.w500,
        ),
      ),
      onPressed: onPressed,
    );
  }
}
