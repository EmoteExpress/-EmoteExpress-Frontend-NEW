import 'package:emote_express/models/generic/links_model.dart';
import 'package:emote_express/models/generic/emotion_response_model.dart';

class ListRecommendedEmotionsResponseModel {
  final LinksModel? links;
  final int? total;
  final List<EmotionResponseModel>? data;

  ListRecommendedEmotionsResponseModel({
    this.links,
    this.total,
    this.data,
  });

  ListRecommendedEmotionsResponseModel copyWith({
    LinksModel? links,
    int? total,
    List<EmotionResponseModel>? data,
  }) =>
      ListRecommendedEmotionsResponseModel(
        links: links ?? this.links,
        total: total ?? this.total,
        data: data ?? this.data,
      );

  factory ListRecommendedEmotionsResponseModel.fromJson(
          Map<String, dynamic> json) =>
      ListRecommendedEmotionsResponseModel(
        links:
            json["links"] == null ? null : LinksModel.fromJson(json["links"]),
        total: json["total"],
        data: json["data"] == null
            ? []
            : List<EmotionResponseModel>.from(
                json["data"]!.map((x) => EmotionResponseModel.fromJson(x))),
      );
}
