import 'package:flutter/material.dart';
import 'package:emote_express/models/generic/wrapped.dart';

enum WidgetStatus { initial, loading, success, error }

enum AppState {
  onboarding,
  loggedUser,
  //loggedAdmin,
  logOut,
  error,
}

enum Gender {
  male,
  female,
  other;

  String get text {
    switch (this) {
      case Gender.male:
        return "Male";
      case Gender.female:
        return "Female";
      case Gender.other:
        return "Other";
    }
  }

  IconData get icon {
    switch (this) {
      case Gender.male:
        return Icons.male_rounded;
      case Gender.female:
        return Icons.female_rounded;
      case Gender.other:
        return Icons.transgender_rounded;
    }
  }

  String toEndpoint() {
    switch (this) {
      case Gender.male:
        return "m";
      case Gender.female:
        return "f";
      case Gender.other:
        return "o";
    }
  }

  String toEndpointGallery() {
    switch (this) {
      case Gender.male:
        return "m";
      case Gender.female:
        return "f";
      case Gender.other:
        return "";
    }
  }
}

final genderValues = EnumValues({
  "M": Gender.male,
  "F": Gender.female,
  "O": Gender.other,
});
