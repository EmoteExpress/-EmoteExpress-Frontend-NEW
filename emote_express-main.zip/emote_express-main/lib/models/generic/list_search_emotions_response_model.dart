import 'package:emote_express/models/generic/links_model.dart';
import 'package:emote_express/models/generic/emotion_response_model.dart';

class ListSearchEmotionsResponseModel {
  final LinksModel? links;
  final int? total;
  final List<String>? tags;
  final List<EmotionResponseModel>? data;

  ListSearchEmotionsResponseModel({
    this.links,
    this.total,
    this.tags,
    this.data,
  });

  factory ListSearchEmotionsResponseModel.fromJson(Map<String, dynamic> json) =>
      ListSearchEmotionsResponseModel(
        links:
            json["links"] == null ? null : LinksModel.fromJson(json["links"]),
        total: json["total"],
        tags: json["tags"] == null
            ? []
            : List<String>.from(json["tags"]!.map((x) => x)),
        data: json["data"] == null
            ? []
            : List<EmotionResponseModel>.from(
                json["data"]!.map((x) => EmotionResponseModel.fromJson(x))),
      );
}
