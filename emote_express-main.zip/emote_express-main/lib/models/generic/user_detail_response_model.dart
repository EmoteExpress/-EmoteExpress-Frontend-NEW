import 'package:emote_express/models/generic/generic_enums.dart';

class UserDetailResponseModel {
  final int? id;
  final String? username;
  final String? email;
  final String? name;
  final String? lastEmotion;
  final String? phone;
  final Gender? gender;
  final String? url;

  final bool? alreadyFollow;
  final int? followers;
  final int? followed;

  UserDetailResponseModel({
    this.id,
    this.username,
    this.email,
    this.name,
    this.lastEmotion,
    this.phone,
    this.gender,
    this.url,
    this.alreadyFollow,
    this.followers,
    this.followed,
  });

  factory UserDetailResponseModel.fromJson(Map<String, dynamic> json) =>
      UserDetailResponseModel(
        id: json["id"],
        username: json["username"],
        email: json["email"],
        name: json["name"],
        lastEmotion: json["emotion"],
        phone: json["phone"],
        gender: (json["gender"] != null)
            ? genderValues.map[json["gender"]]
            : null,
        url: json["url_img"],
        alreadyFollow: json["follow"],
        followers: json["followers"],
        followed: json["followed"],
      );

  UserDetailResponseModel copyWith({
    int? id,
    String? username,
    String? email,
    String? name,
    String? lastEmotion,
    String? phone,
    Gender? gender,
    String? url,
    bool? alreadyFollow,
    int? followers,
    int? followed,
  }) {
    return UserDetailResponseModel(
      id: id ?? this.id,
      username: username ?? this.username,
      email: email ?? this.email,
      name: name ?? this.name,
      lastEmotion: lastEmotion ?? this.lastEmotion,
      phone: phone ?? this.phone,
      gender: gender ?? this.gender,
      url: url ?? this.url,
      alreadyFollow: alreadyFollow ?? this.alreadyFollow,
      followers: followers ?? this.followers,
      followed: followed ?? this.followed,
    );
  }
}
