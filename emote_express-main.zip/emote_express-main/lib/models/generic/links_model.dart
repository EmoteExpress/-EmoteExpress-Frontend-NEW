class LinksModel {
  final String? next;
  final String? previous;

  LinksModel({
    this.next,
    this.previous,
  });

  factory LinksModel.fromJson(Map<String, dynamic> json) => LinksModel(
        next: json["next"],
        previous: json["previous"],
      );

  Map<String, dynamic> toJson() => {
        "next": next,
        "previous": previous,
      };
}
