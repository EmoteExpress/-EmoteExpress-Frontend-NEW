import 'package:emote_express/models/generic/emotion_response_model.dart';
import 'package:emote_express/models/generic/user_detail_response_model.dart';

class HomeResponseModel {
  final bool? quizCompleted;
  final bool? isPrivateProfile;
  final UserDetailResponseModel? dataUser;
  final List<EmotionResponseModel>? recommended;

  HomeResponseModel({
    this.quizCompleted,
    this.isPrivateProfile,
    this.dataUser,
    this.recommended,
  });

  factory HomeResponseModel.fromJson(Map<String, dynamic> json) =>
      HomeResponseModel(
        quizCompleted: json["quiz_completed"],
        isPrivateProfile: json["private_profile"],
        dataUser: json["data_user"] == null
            ? null
            : UserDetailResponseModel.fromJson(json["data_user"]),
        recommended: json["recomended"] == null
            ? []
            : List<EmotionResponseModel>.from(json["recomended"]!
                .map((x) => EmotionResponseModel.fromJson(x))),
      );

  HomeResponseModel copyWith({
    bool? quizCompleted,
    bool? isPrivateProfile,
    UserDetailResponseModel? dataUser,
    List<EmotionResponseModel>? recommended,
  }) =>
      HomeResponseModel(
        quizCompleted: quizCompleted ?? this.quizCompleted,
        isPrivateProfile: isPrivateProfile ?? this.isPrivateProfile,
        dataUser: dataUser ?? this.dataUser,
        recommended: recommended ?? this.recommended,
      );
}
