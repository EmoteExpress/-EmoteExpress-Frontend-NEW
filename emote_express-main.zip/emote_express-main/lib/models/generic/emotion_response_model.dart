class EmotionResponseModel {
  /// [postId] hace referencia a un post creado
  final int? postId;
  final String? emotion;
  final String? url;
  final String? profileUrl;

  EmotionResponseModel({this.postId, this.emotion, this.url, this.profileUrl});

  factory EmotionResponseModel.fromJson(Map<String, dynamic> json) =>
      EmotionResponseModel(
        postId: json["id"],
        emotion: json["emotion"],
        url: json["url"],
        profileUrl: json["url_img"],
      );
}
