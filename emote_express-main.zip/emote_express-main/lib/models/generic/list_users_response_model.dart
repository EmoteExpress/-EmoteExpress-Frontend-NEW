import 'package:emote_express/models/generic/links_model.dart';
import 'package:emote_express/models/generic/user_detail_response_model.dart';

class ListUsersResponseModel {
  final LinksModel? links;
  final int? total;
  final List<UserDetailResponseModel>? data;

  ListUsersResponseModel({this.links, this.total, this.data});

  ListUsersResponseModel copyWith({
    LinksModel? links,
    int? total,
    List<UserDetailResponseModel>? data,
  }) {
    return ListUsersResponseModel(
      links: links ?? this.links,
      total: total ?? this.total,
      data: data ?? this.data,
    );
  }

  factory ListUsersResponseModel.fromJson(Map<String, dynamic> json) =>
      ListUsersResponseModel(
        links: json["links"] == null
            ? null
            : LinksModel.fromJson(json["links"]),
        total: json["total"],
        data: json["data"] == null
            ? []
            : List<UserDetailResponseModel>.from(
                json["data"]!.map((x) => UserDetailResponseModel.fromJson(x)),
              ),
      );
}
