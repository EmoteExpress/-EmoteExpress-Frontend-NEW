import 'package:emote_express/models/generic/links_model.dart';

class ListThreadsResponseModel {
  final LinksModel? links;
  final int? total;
  final List<ThreadModel>? data;

  ListThreadsResponseModel({this.links, this.total, this.data});

  ListThreadsResponseModel copyWith({
    LinksModel? links,
    int? total,
    List<ThreadModel>? data,
  }) => ListThreadsResponseModel(
    links: links ?? this.links,
    total: total ?? this.total,
    data: data ?? this.data,
  );

  factory ListThreadsResponseModel.fromJson(Map<String, dynamic> json) =>
      ListThreadsResponseModel(
        links: json["links"] == null
            ? null
            : LinksModel.fromJson(json["links"]),
        total: json["total"],
        data: json["data"] == null
            ? []
            : List<ThreadModel>.from(
                json["data"]!.map((x) => ThreadModel.fromJson(x)),
              ),
      );
}

class ThreadModel {
  final int? id;
  final String? idThread;
  final String? message;
  final DateTime? dateMessage;

  ThreadModel({this.id, this.idThread, this.message, this.dateMessage});

  ThreadModel copyWith({
    int? id,
    String? idThread,
    String? message,
    DateTime? dateMessage,
  }) => ThreadModel(
    id: id ?? this.id,
    idThread: idThread ?? this.idThread,
    message: message ?? this.message,
    dateMessage: dateMessage ?? this.dateMessage,
  );

  factory ThreadModel.fromJson(Map<String, dynamic> json) => ThreadModel(
    id: json["id"],
    idThread: json["id_thread"],
    message: json["message"],
    dateMessage: json["date_message"] == null
        ? null
        : DateTime.parse(json["date_message"]),
  );
}
