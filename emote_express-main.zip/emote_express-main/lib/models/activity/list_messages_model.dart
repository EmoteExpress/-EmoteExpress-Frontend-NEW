import 'package:emote_express/models/generic/links_model.dart';

class ListMessagesResponseModel {
  final LinksModel? links;
  final int? total;
  final String? idThread;
  final List<MessageModel>? data;

  ListMessagesResponseModel({this.links, this.total, this.idThread, this.data});

  ListMessagesResponseModel copyWith({
    LinksModel? links,
    int? total,
    String? idThread,
    List<MessageModel>? data,
  }) => ListMessagesResponseModel(
    links: links ?? this.links,
    total: total ?? this.total,
    idThread: idThread ?? this.idThread,
    data: data ?? this.data,
  );

  factory ListMessagesResponseModel.fromJson(Map<String, dynamic> json) =>
      ListMessagesResponseModel(
        links: json["links"] == null
            ? null
            : LinksModel.fromJson(json["links"]),
        total: json["total"],
        idThread: json["id_thread"],
        data: json["data"] == null
            ? []
            : List<MessageModel>.from(
                json["data"]!.map((x) => MessageModel.fromJson(x)),
              ),
      );
}

class MessageModel {
  final String? id;
  final String? message;
  final bool? question;
  final DateTime? createdAt;

  MessageModel({this.id, this.message, this.question, this.createdAt});

  MessageModel copyWith({
    String? id,
    String? message,
    bool? question,
    DateTime? createdAt,
  }) => MessageModel(
    id: id ?? this.id,
    message: message ?? this.message,
    question: question ?? this.question,
    createdAt: createdAt ?? this.createdAt,
  );

  factory MessageModel.fromJson(Map<String, dynamic> json) => MessageModel(
    id: json["id"],
    message: json["message"],
    question: json["question"],
    createdAt: json["created_at"] == null
        ? null
        : DateTime.parse(json["created_at"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "message": message,
    "question": question,
    "created_at": createdAt?.toIso8601String(),
  };
}

class SendMessageModel {
  final String? idThread;
  final String? audioUrl;
  final String? prompt;
  final String? text;

  SendMessageModel({this.idThread, this.audioUrl, this.prompt, this.text});

  SendMessageModel copyWith({
    String? idThread,
    String? audioUrl,
    String? prompt,
    String? text,
  }) => SendMessageModel(
    idThread: idThread ?? this.idThread,
    audioUrl: audioUrl ?? this.audioUrl,
    prompt: prompt ?? this.prompt,
    text: text ?? this.text,
  );

  factory SendMessageModel.fromJson(Map<String, dynamic> json) =>
      SendMessageModel(
        idThread: json["id_thread"],
        audioUrl: json["audio_url"],
        prompt: json["prompt"],
        text: json["text"],
      );
}
