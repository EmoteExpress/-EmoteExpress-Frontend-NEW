class ImageSymbolListResponseModel {
  final List<String>? tags;
  final int? nextPage;
  final List<ImageSymbolModel>? data;

  ImageSymbolListResponseModel({
    this.tags,
    this.nextPage,
    this.data,
  });

  ImageSymbolListResponseModel copyWith({
    List<String>? tags,
    int? nextPage,
    List<ImageSymbolModel>? data,
  }) =>
      ImageSymbolListResponseModel(
        tags: tags ?? this.tags,
        nextPage: nextPage ?? this.nextPage,
        data: data ?? this.data,
      );

  factory ImageSymbolListResponseModel.fromJson(Map<String, dynamic> json) =>
      ImageSymbolListResponseModel(
        tags: json["tags"] == null
            ? []
            : List<String>.from(json["tags"]!.map((x) => x)),
        nextPage: json["next_page"],
        data: json["data"] == null
            ? []
            : List<ImageSymbolModel>.from(
                json["data"]!.map((x) => ImageSymbolModel.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "tags": tags == null ? [] : List<dynamic>.from(tags!.map((x) => x)),
        "next_page": nextPage,
        "data": data == null
            ? []
            : List<dynamic>.from(data!.map((x) => x.toJson())),
      };
}

class ImageSymbolModel {
  final String? emotion;
  final String? quote;

  ImageSymbolModel({
    this.emotion,
    this.quote,
  });

  ImageSymbolModel copyWith({
    String? emotion,
    String? quote,
  }) =>
      ImageSymbolModel(
        emotion: emotion ?? this.emotion,
        quote: quote ?? this.quote,
      );

  factory ImageSymbolModel.fromJson(Map<String, dynamic> json) =>
      ImageSymbolModel(
        emotion: json["emotion"],
        quote: json["quote"],
      );

  Map<String, dynamic> toJson() => {
        "emotion": emotion,
        "quote": quote,
      };
}
