import 'dart:io';

import 'package:dio/dio.dart';

class ImageSymbolRequestModel {
  final String? emotion;
  final String? description;
  final File? image;

  ImageSymbolRequestModel({
    this.emotion,
    this.description,
    this.image,
  });

  Future<Map<String, dynamic>> toJson() async {
    var map = {
      "emotion": emotion,
      "description": description,
      "image": await MultipartFile.fromFile(image!.path,
          filename: image!.path.split("/").last),
    };

    return map;
  }

  // Future<FormData> toJsonUpdate() async {
  //   Map<String, dynamic> map = {};
  //
  //   if ((userName ?? "").isNotEmpty) {
  //     map.addAll({"username": userName});
  //   }
  //
  //   if ((email ?? "").isNotEmpty) {
  //     map.addAll({"email": email});
  //   }
  //   if (image != null) {
  //     map.addAll({
  //       "image": await MultipartFile.fromFile(image!.path,
  //           filename: image!.path.split("/").last),
  //     });
  //   }
  //
  //   return FormData.fromMap(map);
  // }
}
