class CalendarDayModel {
  final int? idEmotion;
  final String? emotion;
  final DateTime? date;
  final String? dayOfWeek;
  final String? url;

  CalendarDayModel(
      {this.idEmotion, this.emotion, this.date, this.dayOfWeek, this.url});

  CalendarDayModel copyWith({
    int? idEmotion,
    String? emotion,
    DateTime? date,
    String? dayOfWeek,
    String? url,
  }) =>
      CalendarDayModel(
        idEmotion: idEmotion ?? this.idEmotion,
        emotion: emotion ?? this.emotion,
        date: date ?? this.date,
        dayOfWeek: dayOfWeek ?? this.dayOfWeek,
        url: url ?? this.url,
      );

  factory CalendarDayModel.fromJson(Map<String, dynamic> json) =>
      CalendarDayModel(
        idEmotion: json["id_emotion"],
        emotion: json["emotion"],
        date: (json["date"] == null) ? null : DateTime.tryParse(json["date"]),
        dayOfWeek: json["day_of_week"],
        url: json["url"],
      );

  Map<String, dynamic> toJson() => {
        "id_emotion": idEmotion,
        "emotion": emotion,
        "date": date?.toIso8601String(),
        "day_of_week": dayOfWeek,
        "url": url,
      };

  bool get isEmptyDay => (date == null) ? true : false;
}
