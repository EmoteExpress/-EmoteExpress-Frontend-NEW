class EmotionDescriptionResponseModel {
  final String? emotion;
  final String? description;
  final String? url;
  final String? recommendation;
  final List<TagModel>? tags;

  EmotionDescriptionResponseModel({
    this.emotion,
    this.description,
    this.url,
    this.recommendation,
    this.tags,
  });

  factory EmotionDescriptionResponseModel.fromJson(Map<String, dynamic> json) =>
      EmotionDescriptionResponseModel(
        emotion: json["emotion"],
        description: json["description"],
        url: json["url"],
        recommendation: json["recommendation"],
        tags: json["tags"] == null
            ? []
            : List<TagModel>.from(
                json["tags"]!.map((x) => TagModel.fromJson(x))),
      );
}

class TagModel {
  final String? subtitle;
  final String? concept;

  TagModel({
    this.subtitle,
    this.concept,
  });

  factory TagModel.fromJson(Map<String, dynamic> json) => TagModel(
        subtitle: json["subtitle"],
        concept: json["concept"],
      );
}
