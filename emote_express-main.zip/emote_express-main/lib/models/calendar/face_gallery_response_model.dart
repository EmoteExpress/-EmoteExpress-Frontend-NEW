import 'package:emote_express/models/generic/emotion_response_model.dart';
import 'package:emote_express/models/generic/user_detail_response_model.dart';

class FaceGalleryResponseModel {
  final List<DataTrending>? dataTrending;
  final List<EmotionResponseModel>? recommendedPosts;

  FaceGalleryResponseModel({this.dataTrending, this.recommendedPosts});

  // FaceGalleryResponseModel copyWith({
  //   List<DataTrending>? dataTrending,
  //   List<EmotionResponseModel>? otherPosts,
  // }) =>
  //     FaceGalleryResponseModel(
  //       dataTrending: dataTrending ?? this.dataTrending,
  //       otherPosts: otherPosts ?? this.otherPosts,
  //     );

  factory FaceGalleryResponseModel.fromJson(Map<String, dynamic> json) =>
      FaceGalleryResponseModel(
        dataTrending: json["data_trending"] == null
            ? []
            : List<DataTrending>.from(
                json["data_trending"]!.map((x) => DataTrending.fromJson(x)),
              ),
        recommendedPosts: json["other_users"] == null
            ? []
            : List<EmotionResponseModel>.from(
                json["other_users"]!.map(
                  (x) => EmotionResponseModel.fromJson(x),
                ),
              ),
      );
}

class DataTrending {
  final int? idPost;
  final UserDetailResponseModel? user;
  final String? emotion;
  final String? description;
  final String? url;
  final int? totalLikes;
  final int? totalComments;
  final DateTime? createdAt;

  DataTrending({
    this.idPost,
    this.user,
    this.emotion,
    this.description,
    this.url,
    this.totalLikes,
    this.totalComments,
    this.createdAt,
  });

  // DataTrending copyWith({
  //     int? idPost,
  //     String? emotion,
  //     String? description,
  //     String? url,
  //     int? totalLikes,
  //     int? totalComments,
  //     DateTime? createdAt,
  // }) =>
  //     DataTrending(
  //         idPost: idPost ?? this.idPost,
  //         emotion: emotion ?? this.emotion,
  //         description: description ?? this.description,
  //         url: url ?? this.url,
  //         totalLikes: totalLikes ?? this.totalLikes,
  //         totalComments: totalComments ?? this.totalComments,
  //         createdAt: createdAt ?? this.createdAt,
  //     );

  factory DataTrending.fromJson(Map<String, dynamic> json) => DataTrending(
    idPost: json["id"],
    user: json["user"] == null
        ? null
        : UserDetailResponseModel.fromJson(json["user"]),
    emotion: json["emotion"],
    description: json["description"],
    url: json["url"],
    totalLikes: json["total_likes"],
    totalComments: json["total_comments"],
    createdAt: json["created_at"] == null
        ? null
        : DateTime.parse(json["created_at"]),
  );
}
