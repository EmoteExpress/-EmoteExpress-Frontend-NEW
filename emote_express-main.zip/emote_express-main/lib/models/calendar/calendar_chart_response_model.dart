class CalendarChartResponseModel {
  final double? minX;
  final double? maxX;
  final List<CoordinateModel>? coordinates;

  CalendarChartResponseModel({this.minX, this.maxX, this.coordinates});

  factory CalendarChartResponseModel.fromJson(Map<String, dynamic> json) =>
      CalendarChartResponseModel(
        minX: double.tryParse(json["min_x"].toString()),
        maxX: double.tryParse(json["max_x"].toString()),
        coordinates: json["coordinates"] == null
            ? []
            : List<CoordinateModel>.from(
                json["coordinates"]!.map((x) => CoordinateModel.fromJson(x))),
      );
}

class CoordinateModel {
  final double? valueY;
  final double? valueX;

  CoordinateModel({
    this.valueY,
    this.valueX,
  });

  factory CoordinateModel.fromJson(Map<String, dynamic> json) =>
      CoordinateModel(
        valueY: double.tryParse(json["value_y"].toString()),
        valueX: double.tryParse(json["value_x"].toString()),
      );
}
