class LoginResponseModel {
  final User? user;
  final Token? token;

  LoginResponseModel({this.user, this.token});

  factory LoginResponseModel.fromJson(Map<String, dynamic> json) =>
      LoginResponseModel(
        user: json["user"] == null ? null : User.fromJson(json["user"]),
        token: json["token"] == null ? null : Token.fromJson(json["token"]),
      );
}

class Token {
  final String? accessToken;
  final String? tokenTypes;

  Token({
    this.accessToken,
    this.tokenTypes,
  });

  factory Token.fromJson(Map<String, dynamic> json) => Token(
        accessToken: json["access_token"],
        tokenTypes: json["token_types"],
      );
}

class User {
  final int? id;
  final String? tiprol;

  User({this.id, this.tiprol});

  factory User.fromJson(Map<String, dynamic> json) => User(
        id: json["id"],
        tiprol: json["tiprol"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "tiprol": tiprol,
      };
}
