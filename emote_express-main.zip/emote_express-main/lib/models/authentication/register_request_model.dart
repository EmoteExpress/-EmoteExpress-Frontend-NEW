import 'dart:io';

import 'package:dio/dio.dart';
import 'package:emote_express/models/generic/generic_enums.dart';

class RegisterRequestModel {
  final String? userName;
  final String? email;
  final String? password;
  final String? fullName;
  final String? phone;
  final Gender? gender;
  final File? image;

  RegisterRequestModel({
    this.userName,
    this.email,
    this.password,
    this.fullName,
    this.phone,
    this.gender,
    this.image,
  });

  Future<Map<String, dynamic>> toJson() async {
    var map = {
      "username": userName,
      "email": email,
      "password": password,
      "full_name": fullName,
      "phone": phone,
      "gender": gender!.toEndpoint(),
      "image": await MultipartFile.fromFile(image!.path,
          filename: image!.path.split("/").last),
    };

    return map;
  }

  Future<FormData> toJsonUpdate() async {
    Map<String, dynamic> map = {};

    if ((userName ?? "").isNotEmpty) {
      map.addAll({"username": userName});
    }

    if ((email ?? "").isNotEmpty) {
      map.addAll({"email": email});
    }

    if ((fullName ?? "").isNotEmpty) {
      map.addAll({"full_name": fullName});
    }

    if (gender != null) {
      map.addAll({
        "gender": gender!.toEndpoint(),
      });
    }

    if ((phone ?? "").isNotEmpty) {
      map.addAll({"phone": phone});
    }

    if (image != null) {
      map.addAll({
        "image": await MultipartFile.fromFile(image!.path,
            filename: image!.path.split("/").last),
      });
    }

    return FormData.fromMap(map);
  }
}
