import 'package:emote_express/models/generic/links_model.dart';

class ListEmotionsResponseModel {
  final LinksModel? links;
  final int? total;
  final List<String>? data;

  ListEmotionsResponseModel({
    this.links,
    this.total,
    this.data,
  });

  ListEmotionsResponseModel copyWith({
    LinksModel? links,
    int? total,
    List<String>? data,
  }) =>
      ListEmotionsResponseModel(
        links: links ?? this.links,
        total: total ?? this.total,
        data: data ?? this.data,
      );

  factory ListEmotionsResponseModel.fromJson(Map<String, dynamic> json) =>
      ListEmotionsResponseModel(
        links:
            json["links"] == null ? null : LinksModel.fromJson(json["links"]),
        total: json["total"],
        data: json["data"] == null
            ? []
            : List<String>.from(json["data"]!.map((x) => x)),
      );
}
