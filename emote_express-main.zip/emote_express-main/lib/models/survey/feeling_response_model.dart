class FeelingResponseModel {
  final int? id;
  final String? emotion;
  final String? url;

  FeelingResponseModel({this.id, this.emotion, this.url});

  factory FeelingResponseModel.fromJson(Map<String, dynamic> json) =>
      FeelingResponseModel(
        id: json["id"],
        emotion: json["emotion"],
        url: json["url"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "emotion": emotion,
        "url": url,
      };
}
