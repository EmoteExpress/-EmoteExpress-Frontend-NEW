import 'package:emote_express/models/generic/emotion_response_model.dart';
import 'package:emote_express/models/generic/user_detail_response_model.dart';

class PostResponseModel {
  final DataPost? dataPost;
  final UserDetailResponseModel? dataUser;
  final List<String>? tagsEmotions;
  final List<EmotionResponseModel>? recommended;

  PostResponseModel({
    this.dataPost,
    this.dataUser,
    this.tagsEmotions,
    this.recommended,
  });

  PostResponseModel copyWith({
    DataPost? dataPost,
    UserDetailResponseModel? dataUser,
    List<String>? tagsEmotions,
    List<EmotionResponseModel>? recommended,
  }) => PostResponseModel(
    dataPost: dataPost ?? this.dataPost,
    dataUser: dataUser ?? this.dataUser,
    tagsEmotions: tagsEmotions ?? this.tagsEmotions,
    recommended: recommended ?? this.recommended,
  );

  factory PostResponseModel.fromJson(Map<String, dynamic> json) =>
      PostResponseModel(
        dataPost: json["data_post"] == null
            ? null
            : DataPost.fromJson(json["data_post"]),
        dataUser: json["data_user"] == null
            ? null
            : UserDetailResponseModel.fromJson(json["data_user"]),
        tagsEmotions: json["tags_emotions"] == null
            ? []
            : List<String>.from(json["tags_emotions"]!.map((x) => x)),
        recommended: json["recommended"] == null
            ? []
            : List<EmotionResponseModel>.from(
                json["recommended"]!.map(
                  (x) => EmotionResponseModel.fromJson(x),
                ),
              ),
      );

  // Map<String, dynamic> toJson() => {
  //     "id": id,
  //     "data_post": dataPost?.toJson(),
  //     "data_user": dataUser?.toJson(),
  //     "tags_emotions": tagsEmotions == null ? [] : List<dynamic>.from(tagsEmotions!.map((x) => x)),
  //     "recommended": recommended == null ? [] : List<dynamic>.from(recommended!.map((x) => x.toJson())),
  // };
}

class DataPost {
  final int? id;
  final String? emotion;
  final String? description;
  final String? url;
  final AudioModel? audio;
  final bool? isLiked;
  final int? totalLikes;
  final int? totalComments;
  final bool? ownPost;
  final bool? isFavorite;
  final DateTime? createdAt;
  final bool? updated;

  DataPost({
    this.id,
    this.emotion,
    this.description,
    this.url,
    this.audio,
    this.isLiked,
    this.totalLikes,
    this.totalComments,
    this.ownPost,
    this.isFavorite,
    this.createdAt,
    this.updated,
  });

  DataPost copyWith({
    int? id,
    String? emotion,
    String? description,
    String? url,
    AudioModel? audio,
    bool? isLiked,
    int? totalLikes,
    int? totalComments,
    bool? ownPost,
    bool? isFavorite,
    DateTime? createdAt,
    bool? updated,
  }) => DataPost(
    id: id ?? this.id,
    emotion: emotion ?? this.emotion,
    description: description ?? this.description,
    url: url ?? this.url,
    audio: audio ?? this.audio,
    isLiked: isLiked ?? this.isLiked,
    totalLikes: totalLikes ?? this.totalLikes,
    totalComments: totalComments ?? this.totalComments,
    ownPost: ownPost ?? this.ownPost,
    isFavorite: isFavorite ?? this.isFavorite,
    createdAt: createdAt ?? this.createdAt,
    updated: updated ?? this.updated,
  );

  factory DataPost.fromJson(Map<String, dynamic> json) => DataPost(
    id: json["id"],
    emotion: json["emotion"],
    description: json["description"],
    url: json["url"],
    audio: json["audio"] == null ? null : AudioModel.fromJson(json["audio"]),
    isLiked: json["like_user"],
    totalLikes: json["total_likes"],
    totalComments: json["total_comments"],
    ownPost: json["own_post"],
    isFavorite: json["favorite_post"],
    createdAt: json["created_at"] == null
        ? null
        : DateTime.parse(json["created_at"]),
    updated: json["updated"],
  );

  //Map<String, dynamic> toJson() => {
  //  "emotion": emotion,
  //  "description": description,
  //  "url": url,
  //  "like_user": isLiked,
  //  "total_likes": totalLikes,
  //  "total_comments": totalComments,
  //  "own_post": ownPost,
  //  "favorite_post": isFavorite,
  //  "created_at": createdAt?.toIso8601String(),
  //  "updated": updated,
  //};
}

class AudioModel {
  final String? url;
  final int? initSecond;
  final int? endSecond;

  // Local
  final int id;
  final String? name;

  AudioModel({
    required this.id,
    required this.name,
    this.url,
    this.initSecond,
    this.endSecond,
  });

  AudioModel copyWith({
    int? id,
    String? name,
    String? url,
    int? initSecond,
    int? endSecond,
  }) => AudioModel(
    id: id ?? this.id,
    name: name ?? this.name,
    url: url ?? this.url,
    initSecond: initSecond ?? this.initSecond,
    endSecond: endSecond ?? this.endSecond,
  );

  factory AudioModel.fromJson(Map<String, dynamic> json) => AudioModel(
    id: -1,
    name: json["name"],
    url: json["url"],
    initSecond: json["init_second"],
    endSecond: json["end_second"],
  );

  Map<String, dynamic> toJson() => {
    "name": name,
    "url": url,
    "init_second": initSecond,
    "end_second": endSecond,
  };
}
