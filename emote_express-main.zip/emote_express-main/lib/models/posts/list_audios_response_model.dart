import 'package:emote_express/models/generic/links_model.dart';

class ListAudiosResponseModel {
  final LinksModel? links;
  final int? total;
  final List<GalleryAudioModel> data;

  ListAudiosResponseModel({this.links, this.total, this.data = const []});

  ListAudiosResponseModel copyWith({
    LinksModel? links,
    int? total,
    List<GalleryAudioModel>? data,
  }) => ListAudiosResponseModel(
    links: links ?? this.links,
    total: total ?? this.total,
    data: data ?? this.data,
  );

  factory ListAudiosResponseModel.fromJson(Map<String, dynamic> json) =>
      ListAudiosResponseModel(
        links: json["links"] == null
            ? null
            : LinksModel.fromJson(json["links"]),
        total: json["total"],
        data: json["data"] == null
            ? []
            : List<GalleryAudioModel>.from(
                json["data"]!.map((x) => GalleryAudioModel.fromJson(x)),
              ),
      );

  Map<String, dynamic> toJson() => {
    "links": links?.toJson(),
    "total": total,
    "data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class GalleryAudioModel {
  final int? id;
  final String? name;
  final PreviewsModel? previews;

  GalleryAudioModel({this.id, this.name, this.previews});

  GalleryAudioModel copyWith({
    int? id,
    String? name,
    PreviewsModel? previews,
  }) => GalleryAudioModel(
    id: id ?? this.id,
    name: name ?? this.name,
    previews: previews ?? this.previews,
  );

  String get cleanName => name?.split('.').firstOrNull ?? "N/A";

  factory GalleryAudioModel.fromJson(Map<String, dynamic> json) =>
      GalleryAudioModel(
        id: json["id"],
        name: json["name"],
        previews: json["previews"] == null
            ? null
            : PreviewsModel.fromJson(json["previews"]),
      );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
    "previews": previews?.toJson(),
  };
}

class PreviewsModel {
  final String? previewHqMp3;
  final String? previewHqOgg;
  final String? previewLqMp3;
  final String? previewLqOgg;

  PreviewsModel({
    this.previewHqMp3,
    this.previewHqOgg,
    this.previewLqMp3,
    this.previewLqOgg,
  });

  PreviewsModel copyWith({
    String? previewHqMp3,
    String? previewHqOgg,
    String? previewLqMp3,
    String? previewLqOgg,
  }) => PreviewsModel(
    previewHqMp3: previewHqMp3 ?? this.previewHqMp3,
    previewHqOgg: previewHqOgg ?? this.previewHqOgg,
    previewLqMp3: previewLqMp3 ?? this.previewLqMp3,
    previewLqOgg: previewLqOgg ?? this.previewLqOgg,
  );

  factory PreviewsModel.fromJson(Map<String, dynamic> json) => PreviewsModel(
    previewHqMp3: json["preview-hq-mp3"],
    previewHqOgg: json["preview-hq-ogg"],
    previewLqMp3: json["preview-lq-mp3"],
    previewLqOgg: json["preview-lq-ogg"],
  );

  Map<String, dynamic> toJson() => {
    "preview-hq-mp3": previewHqMp3,
    "preview-hq-ogg": previewHqOgg,
    "preview-lq-mp3": previewLqMp3,
    "preview-lq-ogg": previewLqOgg,
  };
}
