import 'package:emote_express/models/generic/links_model.dart';
import 'package:emote_express/models/generic/user_detail_response_model.dart';

class ListCommentsResponseModel {
  final LinksModel? links;
  final int? total;
  final List<CommentModel>? data;

  ListCommentsResponseModel({
    this.links,
    this.total,
    this.data,
  });

  ListCommentsResponseModel copyWith({
    LinksModel? links,
    int? total,
    List<CommentModel>? data,
  }) =>
      ListCommentsResponseModel(
        links: links ?? this.links,
        total: total ?? this.total,
        data: data ?? this.data,
      );

  factory ListCommentsResponseModel.fromJson(Map<String, dynamic> json) =>
      ListCommentsResponseModel(
        links:
            json["links"] == null ? null : LinksModel.fromJson(json["links"]),
        total: json["total"],
        data: json["data"] == null
            ? []
            : List<CommentModel>.from(
                json["data"]!.map((x) => CommentModel.fromJson(x))),
      );
}

class CommentModel {
  final int? id;
  final String? text;
  final int? likeCount;
  final bool? isLiked;
  final bool? ownComment;
  final UserDetailResponseModel? dataUser;
  final DateTime? createdAt;

  CommentModel({
    this.id,
    this.text,
    this.likeCount,
    this.ownComment,
    this.isLiked,
    this.dataUser,
    this.createdAt,
  });

  CommentModel copyWith({
    int? id,
    String? text,
    int? likeCount,
    bool? isLiked,
    bool? ownComment,
    UserDetailResponseModel? dataUser,
    DateTime? createdAt,
  }) =>
      CommentModel(
        id: id ?? this.id,
        text: text ?? this.text,
        likeCount: likeCount ?? this.likeCount,
        ownComment: ownComment ?? this.ownComment,
        isLiked: isLiked ?? this.isLiked,
        dataUser: dataUser ?? this.dataUser,
        createdAt: createdAt ?? this.createdAt,
      );

  factory CommentModel.fromJson(Map<String, dynamic> json) => CommentModel(
        id: json["id"],
        text: json["comment"],
        likeCount: json["likes"],
        isLiked: json["is_liked"],
        ownComment: json["own_comment"],
        dataUser: json["data_user"] == null
            ? null
            : UserDetailResponseModel.fromJson(json["data_user"]),
        createdAt: json["created_at"] == null
            ? null
            : DateTime.parse(json["created_at"]),
      );
}
