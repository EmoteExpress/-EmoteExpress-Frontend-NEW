import 'package:emote_express/models/generic/links_model.dart';
import 'package:emote_express/models/generic/emotion_response_model.dart';
import 'package:emote_express/models/generic/user_detail_response_model.dart';

class ListPostsResponseModel {
  final LinksModel? links;
  final int? total;
  final UserDetailResponseModel? dataUser;
  final List<EmotionResponseModel>? data;

  ListPostsResponseModel({
    this.links,
    this.total,
    this.dataUser,
    this.data,
  });

  ListPostsResponseModel copyWith({
    LinksModel? links,
    int? total,
    UserDetailResponseModel? dataUser,
    List<EmotionResponseModel>? data,
  }) =>
      ListPostsResponseModel(
        links: links ?? this.links,
        total: total ?? this.total,
        dataUser: dataUser ?? this.dataUser,
        data: data ?? this.data,
      );

  factory ListPostsResponseModel.fromJson(Map<String, dynamic> json) =>
      ListPostsResponseModel(
        links:
            json["links"] == null ? null : LinksModel.fromJson(json["links"]),
        total: json["total"],
        dataUser: json["data_user"] == null
            ? null
            : UserDetailResponseModel.fromJson(json["data_user"]),
        data: json["data"] == null
            ? []
            : List<EmotionResponseModel>.from(
                json["data"]!.map((x) => EmotionResponseModel.fromJson(x))),
      );
}
