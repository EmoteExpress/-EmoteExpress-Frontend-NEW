import 'ui/cubit/general_cubit.dart';
import 'package:flutter/services.dart';
import 'package:flutter/material.dart';
import 'package:emote_express/core/core.dart';
import 'package:emote_express/utils/utils.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await LocalStorage.init();

  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);

  runApp(
    MultiBlocProvider(
      providers: [
        BlocProvider<GeneralCubit>(
          create: (BuildContext context) => GeneralCubit(),
        ),
      ],
      child: const MainApp(),
    ),
  );
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Emote Express',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        fontFamily: 'Poppins',
        appBarTheme: Theme.of(context).appBarTheme.copyWith(
          backgroundColor: Colors.transparent,
          iconTheme: const IconThemeData(color: Colors.white),
          centerTitle: true,
          titleTextStyle: const TextStyle(
            fontSize: 17,
            color: Colors.white,
            fontWeight: FontWeight.w700,
          ),
        ),
        scaffoldBackgroundColor: ConstantColors.cff08080D,
        textTheme: Theme.of(context).textTheme.apply(
          fontFamily: 'Poppins',
          bodyColor: ConstantColors.white,
          displayColor: ConstantColors.white,
        ),
        checkboxTheme: Theme.of(context).checkboxTheme.copyWith(
          fillColor: const WidgetStatePropertyAll(ConstantColors.checkboxColor),
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(4)),
          ),
          visualDensity: VisualDensity.compact,
          side: WidgetStateBorderSide.resolveWith((states) {
            return const BorderSide(color: ConstantColors.cff2D3441);
          }),
          checkColor: const WidgetStatePropertyAll(Colors.white),
        ),
        bottomSheetTheme: const BottomSheetThemeData(
          dragHandleSize: Size(60, 4),
          dragHandleColor: Color(0xFF292929),
        ),
      ),
      routes: AppRouter.routes,
    );
  }
}
