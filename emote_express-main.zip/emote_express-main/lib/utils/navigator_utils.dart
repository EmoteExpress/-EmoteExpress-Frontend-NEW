import 'package:flutter/material.dart';
import 'package:emote_express/ui/ui.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:emote_express/utils/local_storage.dart';

class NavigatorUtils {
  /// Redirecciona al inicio del stack de navegacion
  static void popUntilInitialRoute(BuildContext context) {
    Navigator.of(context).popUntil((route) {
      switch (route.settings.name) {
        case "/":
          return true;
        case LoginView.routeName:
          return true;
        case HomeView.routeName:
          return true;
        case HomeDefaultView.routeName:
          return true;
        default:
          return false;
      }
    });
  }

  /// Resetea los cubits generales, cierra sesión y redirecciona al Login
  static Future<void> resetSession(
    BuildContext context, {
    bool needsLogOut = true,
  }) async {
    final genericCubit = context.read<GeneralCubit>();

    if (needsLogOut) {
      await genericCubit.logOut();
    }

    await LocalStorage.deleteUserData().then((_) {
      genericCubit.clean();

      if (!context.mounted) return;
      Navigator.pushNamedAndRemoveUntil(context, "/", (r) => false);
    });
  }
}
