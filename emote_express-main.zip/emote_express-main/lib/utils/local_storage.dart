import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class LocalStorage {
  static const FlutterSecureStorage _secureStorage = FlutterSecureStorage();

  // =========================================================================
  // CLAVES Y CACHÉ SÍNCRONO
  // =========================================================================

  // Claves para el almacenamiento seguro.
  static const String _tokenKey = "tokenKey";
  static const String _userTypeKey = "userTypeKey";
  static const String _emailKey = "emailKey";
  static const String _passwordKey = "passwordKey";
  static const String _onboardingSeenKey = "onboardingSeenKey";

  // Caché SÍNCRONO para acceso rápido después de la inicialización.
  static String? _cachedToken;
  static String? _cachedUserType;
  static String? _cachedEmail;
  static String? _cachedPassword;
  static bool? _cachedOnboardingSeen;

  // =========================================================================
  // 1. INIT (Carga inicial y cacheo)
  // =========================================================================

  /// Inicializa la caché leyendo todos los valores sensibles del almacenamiento seguro.
  /// DEBE ser llamado al inicio de la aplicación (antes de runApp).
  static Future<void> init() async {
    try {
      final all = await _secureStorage.readAll();
      _cachedToken = all[_tokenKey];
      _cachedUserType = all[_userTypeKey];
      _cachedEmail = all[_emailKey];
      _cachedPassword = all[_passwordKey];
      _cachedOnboardingSeen = ((all[_onboardingSeenKey]) == "true")
          ? true
          : false;
    } catch (e) {
      // print("Error inicializando LocalStorage: $e");
    }
  }

  // =========================================================================
  // 2. WRITE (Escribe y actualiza la caché)
  // =========================================================================

  static Future<void> setUserData({
    required String? token,
    required String? userType,
  }) async {
    if ((token ?? "").isEmpty) {
      assert(false, "El token no puede ser nulo o vacío.");
      throw Exception("El token no puede ser nulo o vacío.");
    }
    if ((userType ?? "").isEmpty) {
      assert(false, "El user type no puede ser nulo o vacío.");
      throw Exception("El user type no puede ser nulo o vacío.");
    }

    await _secureStorage.write(key: _tokenKey, value: token!);
    await _secureStorage.write(key: _userTypeKey, value: userType!);

    _cachedToken = token;
    _cachedUserType = userType;
  }

  static Future<void> setLogInCredentials({
    required String? email,
    required String? password,
  }) async {
    if ((email ?? "").isEmpty) {
      assert(false, "El Email no puede ser nulo o vacío.");
      throw Exception("El Email no puede ser nulo o vacío.");
    }
    if ((password ?? "").isEmpty) {
      assert(false, "El Password no puede ser nulo o vacío.");
      throw Exception("El Password no puede ser nulo o vacío.");
    }

    await _secureStorage.write(key: _emailKey, value: email!);
    await _secureStorage.write(key: _passwordKey, value: password!);

    _cachedEmail = email;
    _cachedPassword = password;
  }

  static Future<void> setOnboarding() async {
    await _secureStorage.write(key: _onboardingSeenKey, value: "true");
    _cachedOnboardingSeen = true;
  }

  // =========================================================================
  // 3. READ (Acceso SÍNCRONO)
  // =========================================================================

  /// Devuelve el token cacheado. SÍNCRONO.
  static String? getToken() => _cachedToken;
  static String? getUserType() => _cachedUserType;
  static String? getEmail() => _cachedEmail;
  static String? getPassword() => _cachedPassword;
  static bool? hasSeenOnboarding() => _cachedOnboardingSeen;

  // =========================================================================
  // 4. DELETE (Elimina del almacenamiento y de la caché)
  // =========================================================================

  /// Elimina el token del almacenamiento seguro y de la caché.
  static Future<void> deleteUserData() async {
    await _secureStorage.delete(key: _tokenKey);
    await _secureStorage.delete(key: _userTypeKey);
    _cachedUserType = null;
    _cachedToken = null;
  }

  /// Elimina las credenciales de inicio de sesión del almacenamiento seguro y de la caché.
  static Future<void> deleteLogInCredentials() async {
    await _secureStorage.delete(key: _emailKey);
    await _secureStorage.delete(key: _passwordKey);
    _cachedEmail = null;
    _cachedPassword = null;
  }

  /// Elimina TODOS los datos almacenados por flutter_secure_storage y limpia la caché.
  static Future<void> clearAllData() async {
    await _secureStorage.deleteAll();
    _cachedToken = null;
    _cachedUserType = null;
    _cachedEmail = null;
    _cachedPassword = null;
    _cachedOnboardingSeen = null;
  }
}
