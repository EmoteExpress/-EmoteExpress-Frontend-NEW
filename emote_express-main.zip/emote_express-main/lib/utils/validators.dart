class Validators {
  static String? onlyLettersValidator(String? value) {
    if (value == null || value.isEmpty) {
      return 'Please enter a valid text.';
    } else if (!RegExp(
            r'^[a-zA-ZàèìòùÀÈÌÒÙáéíóúýÁÉÍÓÚÝâêîôûÂÊÎÔÛãñõÃÑÕäëïöüÿÄËÏÖÜŸçÇßØøÅåÆæœñ ]+$')
        .hasMatch(value.trim())) {
      return 'Not allowed.';
    }
    return null;
  }

  static String? usernameValidator(String? value) {
    if (value == null || value.isEmpty) {
      return 'Please enter a valid text.';
    } else if (value.length < 4) {
      return "Username must have at least 4 characters.";
    } else if (!RegExp(r"^[a-zA-Z0-9]{4,}$").hasMatch(value.trim())) {
      return 'Not allowed.';
    }
    return null;
  }

  static bool isValidUrl(String url) {
    if (url.isEmpty) return false;
    RegExp urlRegex = RegExp(
      r'^(https?:\/\/)?[\w-]+(\.[\w-]+)+([\w.,@?^=%&amp;:/~+#-]*[\w@?^=%&amp;/~+#-])?',
    );
    return urlRegex.hasMatch(url);
  }

  static String? phoneValidator(String? value) {
    if (value == null || value.isEmpty) {
      return 'Please enter a valid phone number.';
    } else if (value.length < 6) {
      return "Phone number must contain at least 6 digits.";
    }
    return null;
  }

  static String? emailValidation(String? value) {
    if (value == null || value.isEmpty || value.replaceAll('\n', '').isEmpty) {
      return 'Please enter an email address.';
    } else if (!RegExp(
            r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$')
        .hasMatch(value.trim())) {
      return 'Wrong or Invalid email address.';
    }
    return null;
  }

  static String? loginPasswordValidation(String? value) {
    if (value == null || value.isEmpty) {
      return 'Please enter a password.';
    } else if (value.length < 6) {
      return "Password must contain at least 6 characters.";
    }
    return null;
  }

  static String? registerPasswordValidation(
      String? value, String password, String cPassword) {
    if (value == null || value.isEmpty) {
      return 'Please enter a password.';
    } else if (value.length < 6) {
      return "The password must contain at least 6 characters.";
    } else if (password != cPassword) {
      return "Passwords must match.";
    }
    return null;
  }
}
