import 'package:intl/intl.dart';

class GenericUtils {
  /// Format 27/12/24 10:30 AM
  static String parseDate(DateTime? date) {
    if (date == null) return "Unknown";
    // 'jm' añade la hora y minutos en formato local (AM/PM para en_US)
    return DateFormat('dd/MM/yy hh:mm a', "en_US").format(date);
  }

  /// Get page from url example/dev/api/user/example/page=2
  static int? getPage(String url) {
    final RegExp exp = RegExp(r'page=(\d+)');
    Match? match = exp.firstMatch(url);

    if (match != null) {
      return int.tryParse(match.group(1)!);
    } else {
      return null;
    }
  }

  /// Format 18h 8min
  static String timeAgo(DateTime date) {
    final now = DateTime.now();
    final diff = now.difference(date);

    final hours = diff.inHours;
    final minutes = diff.inMinutes.remainder(60);
    final days = hours ~/ 24; // truncate

    String result = '';

    if (days > 0) {
      result += '${days}d ';
    }
    if (hours > 0 && days == 0) {
      result += '${hours}h ';
    }
    if (minutes > 0) {
      result += '${minutes}min';
    }

    if (result.endsWith(' ')) {
      result = result.substring(0, result.length - 1);
    }

    return result;
  }

  /// April 04, 2024
  static String calendarDate(DateTime? date) {
    if (date == null) return "";
    return DateFormat('MMMM, yyyy', 'en_US').format(date);
  }

  // Duration to 00:00:00
  static String formatSmartDuration(Duration? duration) {
    if (duration == null) return "N/A";

    String twoDigits(int n) => n.toString().padLeft(2, "0");

    String hours = twoDigits(duration.inHours);
    String minutes = twoDigits(duration.inMinutes.remainder(60));
    String seconds = twoDigits(duration.inSeconds.remainder(60));

    if (duration.inHours > 0) {
      return "$hours:$minutes:$seconds";
    } else {
      return "$minutes:$seconds"; // Si no hay horas, solo minutos y segundos
    }
  }
}
