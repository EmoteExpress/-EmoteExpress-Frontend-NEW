import 'dart:io';
import 'dart:developer';

import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:emote_express/models/generic/photo_model.dart';

class ImageUtils {
  //
  static Future<void> getImageFromCamera({
    required void Function(PhotoModel) onGetImage,
    void Function(String)? onError,
    List<String> allowedExtensions = const ["jpg", "jpeg", "png", "heic"],
  }) async {
    try {
      final permissionStatus = await Permission.camera.status;

      // Validando permisos del dispostivo
      if (permissionStatus.isGranted) {
        final xfile = await ImagePicker().pickImage(source: ImageSource.camera);

        // Evaluando si un archivo ha sido seleccionado
        if (xfile != null) {
          log("Path: ${xfile.path}");
          final fileExtension = xfile.path.split('.').last.toLowerCase();

          // Validando extension del archivo
          if (allowedExtensions.contains(fileExtension)) {
            final photo = PhotoModel(
              file: File(xfile.path),
              id: DateTime.now().toIso8601String(),
            );
            // Enviando objeto por parametro
            onGetImage(photo);
          } else {
            if (onError != null) onError("Extension not allowed.");
          }
        }
      } else {
        // Solicitando permisos
        final permission = await Permission.camera.request();

        if (permission.isGranted) {
          getImageFromCamera(
            onGetImage: onGetImage,
            onError: onError,
            allowedExtensions: allowedExtensions,
          );
        } else {
          // Los permisos no han sido aprobados
          if (onError != null) onError("Permission is not granted.");
        }
      }
    } catch (e) {
      if (onError != null) onError(e.toString());
    }
  }

  //
  static Future<void> getImageFromGallery({
    required void Function(PhotoModel) onGetImage,
    void Function(String)? onError,
    List<String> allowedExtensions = const ["jpg", "jpeg", "png", "heic"],
  }) async {
    try {
      final xfile = await ImagePicker().pickImage(source: ImageSource.gallery);

      if (xfile != null) {
        log("Path: ${xfile.path}");
        final fileExtension = xfile.path.split('.').last.toLowerCase();

        // Validando extension del archivo
        if (allowedExtensions.contains(fileExtension)) {
          final photo = PhotoModel(
            file: File.fromUri(Uri(path: xfile.path)),
            id: DateTime.now().toIso8601String(),
          );
          // Enviando objeto por parametro
          onGetImage(photo);
        } else {
          if (onError != null) onError("Extension not allowed.");
        }
      }
    } catch (e) {
      if (onError != null) onError(e.toString());
    }
  }
}
