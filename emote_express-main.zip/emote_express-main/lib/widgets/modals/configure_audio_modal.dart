import 'dart:async';

import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:emote_express/utils/generic_utils.dart';
import 'package:emote_express/widgets/buttons/generic_button.dart';
import 'package:emote_express/core/constants/constants_colors.dart';
import 'package:emote_express/models/posts/post_response_model.dart';
import 'package:emote_express/widgets/generic/loading_indicator.dart';
import 'package:emote_express/models/posts/list_audios_response_model.dart';

class ConfigureAudioModal extends StatefulWidget {
  const ConfigureAudioModal({
    super.key,
    required this.scrollController,
    required this.audio,
  });

  final GalleryAudioModel? audio;
  final ScrollController scrollController;

  @override
  State<ConfigureAudioModal> createState() => _ConfigureAudioModalState();
}

class _ConfigureAudioModalState extends State<ConfigureAudioModal> {
  RangeValues _selectedRange = const RangeValues(0, 15);

  int _selectedDuration = 15;
  final List<int> _durations = [15, 30, 40, 50, 60];

  late AudioPlayer _player;
  double _maxAudioLength = 120;
  StreamSubscription? _positionSub;

  // late PlayerController _waveformController;
  // bool _isWaveformReady = false;

  @override
  void initState() {
    super.initState();
    _player = AudioPlayer();
    // _waveformController = PlayerController();
    _initAudio();
  }

  @override
  void dispose() {
    // 1. Detenemos el audio de just_audio
    _player.stop();

    // 2. Detenemos el controlador de ondas antes de disponerlo
    // _disposeWaveform();

    _positionSub?.cancel();
    _player.dispose();
    super.dispose();
  }

  void _initAudio() async {
    final url = widget.audio?.previews?.previewHqMp3;
    if (url == null || url.isEmpty) return;

    try {
      // 1. Cargar el audio para reproducción (Just Audio)
      await _player.setUrl(widget.audio!.previews!.previewHqMp3!);

      if (!mounted) return;

      // 2. Preparar el controlador de ondas (Audio Waveforms)
      // await _waveformController.preparePlayer(
      //   path: url,
      //   shouldExtractWaveform: true,
      // );

      if (_player.duration != null) {
        setState(() {
          // _isWaveformReady = true;

          // Obtenemos la duración real al cargar
          _maxAudioLength = _player.duration!.inSeconds.toDouble();

          // Si el rango actual (0-15) es mayor que la duración real (ej. 10),
          // ajustamos el rango inmediatamente para que sea válido.
          if (_selectedRange.end > _maxAudioLength) {
            _selectedRange = RangeValues(
              0,
              _selectedDuration.toDouble().clamp(0, _maxAudioLength),
            );
          }
        });
      }

      _positionSub = _player.positionStream.listen((currentPosition) {
        // Usamos una pequeña tolerancia (500ms) para que el corte sea fluido
        if (currentPosition.inMilliseconds >=
            (_selectedRange.end * 1000).toInt()) {
          _player.pause();
          _player.seek(Duration(seconds: _selectedRange.start.toInt()));
        }
      });
    } catch (e) {
      debugPrint("Error inicializando audio/ondas: $e");
    }
  }

  void _updateRange(RangeValues values) {
    double newStart = values.start;
    double newEnd = values.end;

    // Si intentan agrandar o achicar el rango manualmente,
    // nosotros forzamos que se mantenga la duración seleccionada
    if ((newEnd - newStart).round() != _selectedDuration) {
      if (newStart != _selectedRange.start) {
        // El usuario movió el inicio, ajustamos el fin
        newEnd = (newStart + _selectedDuration).clamp(0, _maxAudioLength);
        newStart = (newEnd - _selectedDuration).clamp(0, _maxAudioLength);
      } else {
        // El usuario movió el fin, ajustamos el inicio
        newStart = (newEnd - _selectedDuration).clamp(0, _maxAudioLength);
        newEnd = (newStart + _selectedDuration).clamp(0, _maxAudioLength);
      }
    }

    setState(() {
      _selectedRange = RangeValues(newStart, newEnd);
    });

    _player.seek(Duration(seconds: newStart.toInt()));
  }

  // Future<void> _disposeWaveform() async {
  //   try {
  //     await _waveformController.stopPlayer();
  //     _waveformController.dispose();
  //   } catch (e) {
  //     debugPrint("Error silencioso al cerrar ondas: $e");
  //   }
  // }

  @override
  Widget build(BuildContext context) {
    return ListView(
      controller: widget.scrollController,
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
      children: [
        const Center(
          child: Text(
            "Configure Sound",
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
        ),
        const SizedBox(height: 24),

        Row(
          spacing: 12,
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Flexible(
              child: const Text(
                "Clip Duration",
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(color: Colors.white70),
              ),
            ),
            Text(
              (_player.duration != null)
                  ? GenericUtils.formatSmartDuration(_player.duration)
                  : "",
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(color: Colors.white70),
            ),
          ],
        ),
        const SizedBox(height: 8),

        // Listado de opciones para la duracion
        Wrap(
          spacing: 8,
          children: _durations.map((d) {
            bool isTooLong = d > _maxAudioLength;

            return ChoiceChip(
              showCheckmark: false,
              label: Text(
                "${d}s",
                style: (_selectedDuration == d)
                    ? TextStyle(color: Colors.white)
                    : null,
              ),
              surfaceTintColor: Colors.green,
              selectedColor: ConstantColors.cffF6912E,
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(100)),
                side: BorderSide(color: Colors.white),
              ),
              selected: (_selectedDuration == d),
              onSelected: isTooLong
                  ? null
                  : (selected) {
                      setState(() {
                        _selectedDuration = d;
                        // Ajustar rango manteniendo el inicio pero clamp en el final
                        double newEnd = (_selectedRange.start + d).clamp(
                          0,
                          _maxAudioLength,
                        );
                        double newStart = (newEnd - d).clamp(
                          0,
                          _maxAudioLength,
                        );
                        _selectedRange = RangeValues(newStart, newEnd);
                      });
                    },
            );
          }).toList(),
        ),
        const SizedBox(height: 24),

        // Boton de reproducción
        Container(
          height: 100,
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.05),
            borderRadius: BorderRadius.circular(20),
          ),
          child: StreamBuilder<PlayerState>(
            stream: _player.playerStateStream,
            builder: (context, snapshot) {
              final isPlaying = snapshot.data?.playing ?? false;
              final processingState = snapshot.data?.processingState;

              // Si está cargando, mostramos un indicador de progreso
              if (processingState == ProcessingState.loading ||
                  processingState == ProcessingState.buffering) {
                return Center(child: LoadingIndicator());
              }

              return IconButton(
                iconSize: 64,
                icon: Icon(
                  isPlaying
                      ? Icons.pause_circle_filled
                      : Icons.play_circle_filled,
                ),
                onPressed: () {
                  if (isPlaying) {
                    _player.pause();
                  } else {
                    // Antes de sonar, saltamos exactamente al inicio que eligió el usuario
                    _player.seek(
                      Duration(seconds: _selectedRange.start.toInt()),
                    );
                    _player.play();
                  }
                },
              );
            },
          ),
        ),
        const SizedBox(height: 8),

        // 2. Selector de Segmento (RangeSlider)
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text(
              "Set Clip Segment",
              style: TextStyle(color: Colors.white70),
            ),
            Text(
              (_player.duration != null)
                  ? "${_selectedRange.start.round()}s - ${_selectedRange.end.round()}s"
                  : "",
              style: const TextStyle(color: Colors.cyanAccent),
            ),
          ],
        ),

        // 3. Selector de Segmento con Ondas
        // Column(
        //   mainAxisSize: MainAxisSize.min,
        //   children: [
        //     Stack(
        //       alignment: Alignment.center,
        //       children: [
        //         // La Onda de Audio (Fondo)
        //         if (_isWaveformReady)
        //           AudioFileWaveforms(
        //             size: Size(MediaQuery.of(context).size.width, 60),
        //             playerController: _waveformController,
        //             enableSeekGesture: false, // El slider manejará los gestos
        //             waveformType: WaveformType.fitWidth,
        //             playerWaveStyle: const PlayerWaveStyle(
        //               fixedWaveColor: Colors.white24,
        //               liveWaveColor: Colors.cyanAccent,
        //               waveThickness: 2,
        //             ),
        //           )
        //         else
        //           const SizedBox(
        //             height: 60,
        //             child: Center(child: LoadingIndicator()),
        //           ),
        //
        //         // El Slider (Encima)
        //         // Usamos un SliderTheme para que el slider sea transparente y solo se vean los botones
        //         if (_maxAudioLength > 0)
        //           SliderTheme(
        //             data: SliderTheme.of(context).copyWith(
        //               activeTrackColor: Colors.transparent,
        //               inactiveTrackColor: Colors.transparent,
        //               thumbColor: Colors.cyanAccent,
        //               rangeThumbShape: const RoundRangeSliderThumbShape(
        //                 enabledThumbRadius: 10,
        //               ),
        //               overlayColor: Colors.cyanAccent.withOpacity(0.2),
        //             ),
        //             child: RangeSlider(
        //               values: _selectedRange,
        //               min: 0,
        //               max: _maxAudioLength,
        //               divisions: _maxAudioLength.toInt(),
        //               onChanged: _updateRange,
        //             ),
        //           ),
        //       ],
        //     ),
        //     // ... Texto de segundos abajo
        //   ],
        // ),

        // Solo dibuja el slider si tenemos una duración válida
        if (_maxAudioLength > 15 && _player.duration != null)
          RangeSlider(
            values: _selectedRange,
            min: 0,
            max: _maxAudioLength,
            divisions: _maxAudioLength.toInt(),
            activeColor: Colors.white,
            labels: RangeLabels(
              "${_selectedRange.start.round()}s",
              "${_selectedRange.end.round()}s",
            ),
            onChanged: _updateRange,
          ),
        const SizedBox(height: 8),

        Text(
          "Clip Name: ${widget.audio?.cleanName}",
          style: TextStyle(color: Colors.white70),
        ),
        const SizedBox(height: 24),

        GenericButton(
          text:
              "Use Sound (${(_selectedRange.end - _selectedRange.start).round()}s)",
          onTap: () {
            if (widget.audio?.id == null) return;
            if (widget.audio?.cleanName == null) return;
            if (_positionSub == null) return;

            Navigator.pop(
              context,
              AudioModel(
                id: widget.audio!.id!,
                name: widget.audio!.cleanName,
                url: widget.audio?.previews?.previewHqMp3,
                initSecond: _selectedRange.start.round(),
                endSecond: _selectedRange.end.round(),
              ),
            );
          },
        ),
      ],
    );
  }
}
