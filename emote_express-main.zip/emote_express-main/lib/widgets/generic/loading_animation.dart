import 'package:flutter/material.dart';
import 'package:emote_express/core/constants/constants_images.dart';

class LoadingAnimation extends StatelessWidget {
  const LoadingAnimation({super.key});

  @override
  Widget build(BuildContext context) {
    return Image.asset(ConstantImages.loadingAnimation);
  }
}
