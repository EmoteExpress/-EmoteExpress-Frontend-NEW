import 'package:flutter/material.dart';
import 'package:emote_express/widgets/generic/generic_network_image.dart';

class ProfileImageComponent extends StatelessWidget {
  const ProfileImageComponent({super.key, this.path, this.size = 100});

  final String? path;
  final double size;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: const BoxDecoration(
        color: Color(0xFF828282),
        shape: BoxShape.circle,
      ),
      child: (path == null)
          ? const Icon(
              Icons.person_outline_rounded,
              size: 52,
              color: Color(0xFF282828),
            )
          : GenericNetworkImage(path: path, border: 100),
    );
  }
}
