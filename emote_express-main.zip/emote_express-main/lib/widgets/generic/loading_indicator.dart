import 'package:flutter/material.dart';
import 'package:emote_express/core/constants/constants_colors.dart';

class LoadingIndicator extends StatelessWidget {
  const LoadingIndicator({
    super.key,
    this.value,
    this.color = ConstantColors.cffFFBE26,
  });

  final double? value;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return CircularProgressIndicator(
      value: value,
      color: color,
      strokeWidth: 4,
      valueColor: AlwaysStoppedAnimation<Color>(color),
    );
  }
}
