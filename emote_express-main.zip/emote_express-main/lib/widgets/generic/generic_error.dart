import 'package:flutter/material.dart';

class GenericError extends StatelessWidget {
  const GenericError({
    super.key,
    this.text = "An unknown error has occurred.",
  });

  final String? text;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Padding(
          padding: const EdgeInsets.all(20),
          child: Text(
            ((text ?? "").isNotEmpty)
                ? text!
                : "An unknown error has occurred.",
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: Colors.white,
            ),
          ),
        ),
      ],
    );
  }
}
