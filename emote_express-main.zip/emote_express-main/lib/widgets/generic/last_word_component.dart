import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:emote_express/core/constants/constants_icons.dart';

class LastWordComponent extends StatelessWidget {
  const LastWordComponent({super.key, this.word});

  final String? word;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        SvgPicture.asset(ConstantIcons.logoWhite, height: 22, width: 23),
        const SizedBox(width: 8),
        Flexible(
          child: Text(
            word ?? "N/A",
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: Color(0xFFA9A9A9),
              fontWeight: FontWeight.w400,
            ),
          ),
        ),
      ],
    );
  }
}
