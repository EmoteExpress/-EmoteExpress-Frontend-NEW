import 'dart:io';

import 'package:flutter/material.dart';
import 'package:emote_express/utils/validators.dart';
import 'package:cached_network_image/cached_network_image.dart';

class GenericNetworkImage extends StatelessWidget {
  final String? path;
  final BoxFit fit;
  final IconData? defaultIcon;
  final double? sizeDefaultIcon;
  final Color iconDefaultColor;

  final double? size;
  final double? height;
  final double? width;
  final double border;
  final double opacity;

  final double? heightLoading;

  final bool needsFullScreen;

  const GenericNetworkImage({
    this.fit = BoxFit.cover,
    super.key,
    this.path,
    this.size,
    this.width,
    this.height,
    this.border = 20,
    this.opacity = 1.0,
    this.defaultIcon,
    this.heightLoading,
    this.sizeDefaultIcon,
    this.iconDefaultColor = Colors.white,
    this.needsFullScreen = false,
  });

  @override
  Widget build(BuildContext context) {
    if (path?.isNotEmpty ?? false) {
      if (Validators.isValidUrl(path!)) {
        return GestureDetector(
          onTap: (needsFullScreen)
              ? () {
                  //Navigator.of(context).push<void>(
                  //  MaterialPageRoute(
                  //      builder: (context) => FullScreenImage(
                  //            path: path ?? "",
                  //          )),
                  //);
                }
              : null,
          child: CachedNetworkImage(
            imageUrl: path!,
            width: width ?? size,
            height: height ?? size,
            fit: fit,
            imageBuilder: (context, imageProvider) {
              return Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.all(Radius.circular(border)),
                  image: DecorationImage(
                    image: imageProvider,
                    opacity: opacity,
                    fit: fit,
                  ),
                ),
              );
            },
            progressIndicatorBuilder: (_, url, progress) {
              return SizedBox(
                height: heightLoading,
                child: const Center(
                  child: CircularProgressIndicator(
                      color: Colors.blueAccent, strokeWidth: 2),
                ),
              );
            },
            errorWidget: (context, url, error) => _errorWidget(),
          ),
        );
      }
      return ClipRRect(
        borderRadius: BorderRadius.all(Radius.circular(border)),
        child: Image.file(
          File(path!),
          width: width ?? size,
          height: height ?? size,
          fit: fit,
          filterQuality: FilterQuality.high,
          errorBuilder: (context, error, stackTrace) => _errorWidget(),
        ),
      );
    }
    return _errorWidget();
  }

  Widget _errorWidget() {
    return Icon(
      defaultIcon ?? Icons.error_rounded,
      size: sizeDefaultIcon ?? 50,
      color: iconDefaultColor,
    );
  }
}
