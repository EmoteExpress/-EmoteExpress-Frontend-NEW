import 'package:flutter/material.dart';
import 'package:emote_express/core/constants/constants_images.dart';

class GenericLayout extends StatelessWidget {
  const GenericLayout({super.key, required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        SizedBox(
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height,
          child: Image.asset(ConstantImages.shape, fit: BoxFit.cover),
        ),
        //SvgPicture.asset(
        //  ConstantIcons.shape1,
        //  fit: BoxFit.cover,
        //),
        //BackdropFilter(
        //  filter: ImageFilter.blur(sigmaX: 44, sigmaY: 44),
        //  child: Container(
        //    color: Colors.black.withOpacity(0.1),
        //  ),
        //),
        child,
      ],
    );
  }
}
