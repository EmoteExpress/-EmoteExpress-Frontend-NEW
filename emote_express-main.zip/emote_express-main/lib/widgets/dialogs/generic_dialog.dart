import 'package:flutter/material.dart';
import 'package:emote_express/utils/navigator_utils.dart';
import 'package:emote_express/widgets/buttons/generic_button.dart';
import 'package:emote_express/core/constants/constant_settings.dart';
import 'package:emote_express/core/constants/constants_colors.dart';

class GenericDialog extends StatelessWidget {
  const GenericDialog({
    super.key,
    this.title = "Something went wrong",
    this.description,
    this.isErrorDialog = false,
    this.onAccept,
  });

  final String title;
  final String? description;
  final bool isErrorDialog;

  final VoidCallback? onAccept;

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: (isErrorDialog) ? false : true,
      child: Dialog(
        shadowColor: Colors.black,
        backgroundColor: ConstantColors.cff111114,
        shape: const RoundedRectangleBorder(
          side: BorderSide(color: Colors.white),
          borderRadius: BorderRadius.all(Radius.circular(16)),
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 30),
          child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  title,
                  textAlign: TextAlign.center,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  description ?? "N/A",
                  textAlign: TextAlign.center,
                  maxLines: 6,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Color(0xFF848484),
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 28),
                GenericButton(
                  text: "Done",
                  onTap: onAccept ??
                      () {
                        // Verificando si es necesario redireccionar al Login
                        if (description ==
                                ConstantSettings.expiredTokenMessage &&
                            isErrorDialog) {
                          NavigatorUtils.resetSession(context);
                        } else {
                          Navigator.pop(context);
                        }
                      },
                ),
              ]),
        ),
      ),
    );
  }
}
