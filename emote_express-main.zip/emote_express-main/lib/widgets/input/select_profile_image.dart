import 'package:flutter/material.dart';
import 'package:emote_express/utils/image_utils.dart';
import 'package:emote_express/widgets/generic/generic.dart';
import 'package:emote_express/models/generic/photo_model.dart';
import 'package:emote_express/core/constants/constants_colors.dart';

class SelectProfileImage extends StatelessWidget {
  const SelectProfileImage({super.key, this.path, required this.onGetImage});

  final String? path;
  final Function(PhotoModel) onGetImage;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();

        showModalBottomSheet<void>(
          context: context,
          isScrollControlled: true,
          builder: (BuildContext context) {
            return UploadImageModal(
              onSelected: (image) {
                onGetImage(image);
                Navigator.pop(context);
              },
            );
          },
        );
      },
      child: Center(
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            Container(
              height: 100,
              width: 100,
              decoration: BoxDecoration(
                color: const Color.fromARGB(47, 40, 40, 40),
                borderRadius: const BorderRadius.all(Radius.circular(100)),
                border: Border.all(color: ConstantColors.cffF6912E),
              ),
              child: (path != null)
                  ? GenericNetworkImage(
                      path: path,
                      border: 100,
                      heightLoading: 5,
                      fit: BoxFit.cover,
                      defaultIcon: Icons.add_photo_alternate_rounded,
                    )
                  : const Icon(
                      Icons.camera_alt_outlined,
                      size: 30,
                      color: ConstantColors.cffF6912E,
                    ),
            ),
            Positioned(
              top: -5,
              left: 70,
              child: Container(
                padding: const EdgeInsets.all(5),
                decoration: const BoxDecoration(
                  color: ConstantColors.cffF6912E,
                  borderRadius: BorderRadius.all(Radius.circular(100)),
                ),
                child: const Icon(
                  Icons.add_outlined,
                  size: 20,
                  color: Colors.white,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class UploadImageModal extends StatelessWidget {
  const UploadImageModal({super.key, required this.onSelected});

  final void Function(PhotoModel) onSelected;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 12),
      decoration: const BoxDecoration(
        color: ConstantColors.cff111114,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(0),
          topRight: Radius.circular(0),
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 50,
            height: 4,
            decoration: const BoxDecoration(
              color: Color(0xFF292929),
              borderRadius: BorderRadius.all(Radius.circular(100)),
            ),
          ),
          const SizedBox(height: 14),
          const Text(
            'Upload Picture',
            style: TextStyle(
              fontSize: 20,
              color: Colors.white,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              _OptionComponent(
                title: "Camera",
                icon: Icons.camera_alt_outlined,
                onPressed: () async {
                  await ImageUtils.getImageFromCamera(onGetImage: onSelected);
                },
              ),
              const SizedBox(width: 20),
              _OptionComponent(
                title: "Gallery",
                icon: Icons.image_outlined,
                onPressed: () async {
                  await ImageUtils.getImageFromGallery(onGetImage: onSelected);
                },
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _OptionComponent extends StatelessWidget {
  const _OptionComponent({
    required this.title,
    required this.icon,
    required this.onPressed,
  });

  final String title;
  final IconData icon;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return Column(mainAxisSize: MainAxisSize.min, children: [
      ElevatedButton(
        onPressed: onPressed,
        style: const ButtonStyle(
          backgroundColor: WidgetStatePropertyAll(Color(0xFF292929)),
          shape: WidgetStatePropertyAll(
            RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
          ),
          padding: WidgetStatePropertyAll(EdgeInsets.all(25)),
        ),
        child: Icon(
          icon,
          color: Colors.white,
          size: 25,
        ),
      ),
      const SizedBox(height: 10),
      Text(
        title,
        style: const TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w600,
          color: Colors.white,
        ),
      )
    ]);
  }
}
