import 'package:emote_express/core/constants/constants_colors.dart';
import 'package:flutter/material.dart';

class CommentInput extends StatelessWidget {
  const CommentInput({super.key, this.controller, this.onChanged});

  final TextEditingController? controller;
  final void Function(String?)? onChanged;

  @override
  Widget build(BuildContext context) {
    return TextField(
      maxLines: 1,
      minLines: 1,
      textInputAction: TextInputAction.done,
      textCapitalization: TextCapitalization.sentences,
      controller: controller,
      onChanged: (value) => onChanged?.call(value),
      style: const TextStyle(fontWeight: FontWeight.w400, color: Colors.white),
      decoration: const InputDecoration(
        filled: true,
        isDense: false,
        fillColor: ConstantColors.cff1F2128,
        hintText: "Leave a comment",
        hintStyle: TextStyle(fontWeight: FontWeight.w400, color: Colors.grey),
        border: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
      ),
    );
  }
}
