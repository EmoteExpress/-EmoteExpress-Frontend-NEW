import 'dart:async';

import 'package:flutter/material.dart';

class SearchInput extends StatefulWidget {
  const SearchInput(
      {super.key, this.hintText, this.textController, this.onChanged});

  final String? hintText;
  final TextEditingController? textController;
  final void Function(String?)? onChanged;

  @override
  State<SearchInput> createState() => _SearchInputState();
}

class _SearchInputState extends State<SearchInput> {
  Timer? debounce;

  @override
  void dispose() {
    debounce?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return TextField(
      maxLines: 1,
      minLines: 1,
      textInputAction: TextInputAction.done,
      textCapitalization: TextCapitalization.sentences,
      controller: widget.textController,
      onChanged: (value) {
        if (debounce?.isActive ?? false) {
          debounce?.cancel();
        }
        debounce = Timer(const Duration(milliseconds: 500), () {
          widget.onChanged?.call(value);
        });
      },
      style: const TextStyle(fontWeight: FontWeight.w400, color: Colors.white),
      decoration: InputDecoration(
        filled: true,
        isDense: false,
        fillColor: const Color(0xFF292929),
        hintText: widget.hintText,
        suffixIcon: IconButton(
          icon: const Icon(Icons.search_rounded),
          onPressed: () {},
        ),
        suffixIconColor: const Color(0xFF757575),
        hintStyle:
            const TextStyle(fontWeight: FontWeight.w400, color: Colors.grey),
        border: const OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(20)),
        ),
        enabledBorder: const OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(20)),
        ),
        focusedBorder: const OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(20)),
        ),
        errorBorder: const OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(20)),
        ),
      ),
    );
  }
}
