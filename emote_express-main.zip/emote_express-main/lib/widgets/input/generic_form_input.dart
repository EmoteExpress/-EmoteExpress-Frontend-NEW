import 'package:flutter/material.dart';
import 'package:emote_express/core/constants/constants.dart';

class GenericFormInput extends StatelessWidget {
  const GenericFormInput({
    super.key,
    this.hintText,
    this.textCapitalization = TextCapitalization.none,
    this.textInputType = TextInputType.text,
    this.textInputAction = TextInputAction.done,
    this.prefixIcon,
    this.sufixIcon,
    this.obscureText = false,
    this.textController,
    this.onChanged,
    this.validator,
    this.suffixPasswordIcon,
    this.maxLines = 1,
    this.minLines = 1,
  });

  final String? hintText;
  final int maxLines;
  final int minLines;
  final TextCapitalization textCapitalization;
  final TextInputAction textInputAction;
  final TextInputType textInputType;
  final String? Function(String?)? validator;

  final IconData? prefixIcon;
  final IconData? sufixIcon;
  final Widget? suffixPasswordIcon;
  final bool obscureText;

  final TextEditingController? textController;
  final void Function(String?)? onChanged;

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      //readOnly: readOnly,
      maxLines: maxLines,
      minLines: minLines,
      validator: validator,
      obscureText: obscureText,
      //textAlign: TextAlign.start,
      keyboardType: textInputType,
      textInputAction: textInputAction,
      textCapitalization: textCapitalization,
      controller: textController,
      onChanged: onChanged,
      style: const TextStyle(fontWeight: FontWeight.w400, color: Colors.white),
      decoration: InputDecoration(
        filled: true,
        isDense: false,
        fillColor: ConstantColors.cff1F2128,
        prefixIcon: (prefixIcon != null) ? Icon(prefixIcon) : null,
        prefixIconColor: Colors.white,
        suffixIcon: (suffixPasswordIcon != null)
            ? suffixPasswordIcon
            : (sufixIcon != null)
                ? IconButton(
                    icon: Icon(sufixIcon),
                    onPressed: () {},
                  )
                : null,
        suffixIconColor: Colors.white,
        hintText: hintText,
        hintStyle:
            const TextStyle(fontWeight: FontWeight.w400, color: Colors.grey),
        border: const OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(8)),
        ),
        enabledBorder: const OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(8)),
        ),
        focusedBorder: const OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(8)),
        ),
        errorBorder: const OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.all(Radius.circular(8)),
        ),
      ),
    );
  }
}
