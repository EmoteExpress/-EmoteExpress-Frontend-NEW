import 'package:flutter/material.dart';
import 'package:emote_express/core/constants/constants.dart';

class GenericButton extends StatelessWidget {
  final String text;
  final Color color;
  final VoidCallback? onTap;

  const GenericButton({
    super.key,
    required this.text,
    this.color = ConstantColors.cffF6912E,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: MediaQuery.of(context).size.width,
      child: ElevatedButton(
        onPressed: onTap,
        style: ButtonStyle(
          minimumSize: const WidgetStatePropertyAll(Size(0, 52)),
          shape: const WidgetStatePropertyAll(
            RoundedRectangleBorder(
                side: BorderSide(color: ConstantColors.white, width: 1),
                borderRadius: BorderRadius.all(Radius.circular(8))),
          ),
          backgroundColor:
              (onTap != null) ? WidgetStatePropertyAll(color) : null,
        ),
        child: Text(
          text,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w700,
            color: (onTap != null) ? ConstantColors.white : Colors.grey,
          ),
        ),
      ),
    );
  }
}
