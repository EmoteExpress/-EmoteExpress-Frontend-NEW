import 'package:flutter/material.dart';
import 'package:emote_express/core/constants/constants_colors.dart';

class GenericTextIconButton extends StatelessWidget {
  const GenericTextIconButton({
    super.key,
    required this.text,
    required this.icon,
    this.borderRadius = 8,
    this.backgroundColor = ConstantColors.cff1F2128,
    this.textColor = Colors.white,
    this.iconColor = Colors.white,
    this.onPressed,
  });

  final String text;
  final IconData icon;
  final double borderRadius;
  final Color backgroundColor;
  final Color textColor;
  final Color iconColor;
  final VoidCallback? onPressed;

  @override
  Widget build(BuildContext context) {
    return ElevatedButton.icon(
      onPressed: onPressed,
      icon: Icon(icon),
      style: ButtonStyle(
        minimumSize: const WidgetStatePropertyAll(Size(0, 42)),
        iconSize: const WidgetStatePropertyAll(20),
        iconColor: WidgetStatePropertyAll(iconColor),
        elevation: const WidgetStatePropertyAll(0.0),
        shape: WidgetStatePropertyAll(
          RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(borderRadius)),
          ),
        ),
        overlayColor: WidgetStatePropertyAll(
          Colors.white.withValues(alpha: 0.2),
        ),
        backgroundColor: WidgetStatePropertyAll(backgroundColor),
      ),
      label: Text(
        text,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(fontWeight: FontWeight.w600, color: textColor),
      ),
    );
  }
}
