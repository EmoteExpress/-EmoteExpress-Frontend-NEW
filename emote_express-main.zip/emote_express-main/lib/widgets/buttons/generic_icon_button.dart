import 'package:emote_express/core/constants/constants.dart';
import 'package:flutter/material.dart';

class GenericIconButton extends StatelessWidget {
  const GenericIconButton({super.key, required this.icon, this.onPressed});

  final IconData icon;
  final VoidCallback? onPressed;

  @override
  Widget build(BuildContext context) {
    return IconButton.filled(
      onPressed: onPressed,
      color: Colors.white,
      disabledColor: Colors.grey,
      style: ButtonStyle(
        backgroundColor: WidgetStateProperty.all(ConstantColors.cff1F2128),
        shape: const WidgetStatePropertyAll(
          RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(8))),
        ),
      ),
      icon: Icon(icon),
    );
  }
}
