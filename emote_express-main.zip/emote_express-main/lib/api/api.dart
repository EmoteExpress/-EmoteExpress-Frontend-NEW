import 'dart:developer';
import 'package:dio/dio.dart';
import 'package:emote_express/utils/local_storage.dart';
import 'package:emote_express/core/constants/constants.dart';

class Api {
  final tokenDio = createTokenDio();
  final dioFormData = createDioFormData();

  static Dio createTokenDio() {
    var dio = Dio(
      BaseOptions(
        baseUrl: ConstantApi.url,
        receiveTimeout: const Duration(minutes: 3),
        connectTimeout: const Duration(minutes: 3),
        sendTimeout: const Duration(minutes: 3),
      ),
    );
    dio.interceptors.addAll({AppInterceptors(dio)});
    return dio;
  }

  static Dio createDioFormData() {
    var dio = Dio(
      BaseOptions(
        baseUrl: ConstantApi.url,
        connectTimeout: const Duration(hours: 2),
        receiveTimeout: const Duration(hours: 2),
        sendTimeout: const Duration(hours: 2),
      ),
    );
    dio.interceptors.addAll({AppInterceptors(dio)});
    return dio;
  }
}

class AppInterceptors extends Interceptor {
  final Dio dio;

  AppInterceptors(this.dio);

  @override
  void onRequest(RequestOptions options, RequestInterceptorHandler handler) {
    var accessToken = LocalStorage.getToken();

    log("${options.method} ${options.uri}");
    log("Token de acceso -> $accessToken");

    if (accessToken != null) {
      options.headers['Authorization'] = 'Bearer $accessToken';
    }
    return handler.next(options);
  }

  @override
  void onError(DioException err, ErrorInterceptorHandler handler) {
    log("====================================================================");
    log(err.message.toString());
    log(err.response.toString());
    handler.next(err);
  }
}
