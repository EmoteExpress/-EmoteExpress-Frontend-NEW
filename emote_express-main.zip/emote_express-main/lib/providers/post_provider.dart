import 'package:dio/dio.dart';
import 'package:dartz/dartz.dart';
import 'package:emote_express/api/api.dart';
import 'package:emote_express/models/models.dart';
import 'package:emote_express/core/constants/end_point_constant.dart';

class PostProvider {
  Future<Either<DataException, String>> createPost({
    required String emotion,
    required String url,
    required String description,
    AudioModel? audio,
  }) async {
    try {
      final Map<String, dynamic> data = {
        "emotion": emotion,
        "url_emotion": url,
        "description": description,
      };

      if (audio != null) data.addAll({"audio": audio.toJson()});

      final response = await Api().dioFormData.post(
        EndPointConstant.posts,
        data: data,
      );

      return Right(response.data.toString());
    } on DioException catch (e) {
      return Left(
        DataException(
          details: (e.response?.data is Map<String, dynamic>)
              ? e.response?.data["detail"].toString()
              : "An unknown error has occurred.",
        ),
      );
    } catch (e) {
      return Left(DataException(details: e.toString()));
    }
  }

  Future<Either<DataException, ListPostsResponseModel>> getPosts({
    int page = 1,
    int? userId,
  }) async {
    try {
      final params = {"page": page};
      if (userId != null) params.addAll({"user_id": userId});

      final response = await Api().tokenDio.get(
        EndPointConstant.posts,
        queryParameters: params,
      );

      return Right(ListPostsResponseModel.fromJson(response.data));
    } on DioException catch (e) {
      return Left(
        DataException(
          details: (e.response?.data is Map<String, dynamic>)
              ? e.response?.data["detail"].toString()
              : "An unknown error has occurred.",
        ),
      );
    } catch (e) {
      return Left(DataException(details: e.toString()));
    }
  }

  Future<Either<DataException, PostResponseModel>> getPost(int id) async {
    try {
      final response = await Api().tokenDio.get(
        "${EndPointConstant.posts}$id/",
      );

      return Right(PostResponseModel.fromJson(response.data));
    } on DioException catch (e) {
      return Left(
        DataException(
          details: (e.response?.data is Map<String, dynamic>)
              ? e.response?.data["detail"].toString()
              : "An unknown error has occurred.",
        ),
      );
    } catch (e) {
      return Left(DataException(details: e.toString()));
    }
  }

  Future<Either<DataException, String>> deletePost(int id) async {
    try {
      final response = await Api().dioFormData.delete(
        "${EndPointConstant.posts}$id/",
      );

      return Right(response.data.toString());
    } on DioException catch (e) {
      return Left(
        DataException(
          details: (e.response?.data is Map<String, dynamic>)
              ? e.response?.data["detail"].toString()
              : "An unknown error has occurred.",
        ),
      );
    } catch (e) {
      return Left(DataException(details: e.toString()));
    }
  }

  Future<Either<DataException, String>> updatePost({
    required int id,
    required String url,
    required String description,
  }) async {
    try {
      final data = {"url_emo": url, "des_emo": description};

      final response = await Api().dioFormData.put(
        "${EndPointConstant.posts}$id/",
        data: data,
      );

      return Right(response.data.toString());
    } on DioException catch (e) {
      return Left(
        DataException(
          details: (e.response?.data is Map<String, dynamic>)
              ? e.response?.data["detail"].toString()
              : "An unknown error has occurred.",
        ),
      );
    } catch (e) {
      return Left(DataException(details: e.toString()));
    }
  }

  Future<Either<DataException, String>> followUser({
    required int userId,
  }) async {
    try {
      final response = await Api().tokenDio.post(
        "${EndPointConstant.follow}$userId/",
      );

      return Right(response.data.toString());
    } on DioException catch (e) {
      return Left(
        DataException(
          details: (e.response?.data is Map<String, dynamic>)
              ? e.response?.data["detail"].toString()
              : "An unknown error has occurred.",
        ),
      );
    } catch (e) {
      return Left(DataException(details: e.toString()));
    }
  }

  Future<Either<DataException, ListUsersResponseModel>> getProfileFollowers({
    int page = 1,
    String query = "",
    required int userId,
    required bool isFollowers,
  }) async {
    try {
      final data = {
        "page": page,
        "search": query,
        "user_id": userId,
        "type_request": (isFollowers) ? "followers" : "followed",
      };

      final response = await Api().tokenDio.get(
        EndPointConstant.profileFollowers,
        queryParameters: data,
      );

      return Right(ListUsersResponseModel.fromJson(response.data));
    } on DioException catch (e) {
      return Left(
        DataException(
          details: (e.response?.data is Map<String, dynamic>)
              ? e.response?.data["detail"].toString()
              : "An unknown error has occurred.",
        ),
      );
    } catch (e) {
      return Left(DataException(details: e.toString()));
    }
  }

  Future<Either<DataException, String>> toggleLikePost(int id) async {
    try {
      final response = await Api().dioFormData.post(
        "${EndPointConstant.toggleLikePost}$id/",
      );

      return Right(response.data.toString());
    } on DioException catch (e) {
      return Left(
        DataException(
          details: (e.response?.data is Map<String, dynamic>)
              ? e.response?.data["detail"].toString()
              : "An unknown error has occurred.",
        ),
      );
    } catch (e) {
      return Left(DataException(details: e.toString()));
    }
  }

  Future<Either<DataException, String>> toggleFavoritePost(int id) async {
    try {
      final response = await Api().dioFormData.post(
        "${EndPointConstant.favoritePost}$id/",
      );

      return Right(response.data.toString());
    } on DioException catch (e) {
      return Left(
        DataException(
          details: (e.response?.data is Map<String, dynamic>)
              ? e.response?.data["detail"].toString()
              : "An unknown error has occurred.",
        ),
      );
    } catch (e) {
      return Left(DataException(details: e.toString()));
    }
  }

  Future<Either<DataException, ListRecommendedEmotionsResponseModel>> getFeed({
    int page = 1,
    Gender? gender,
  }) async {
    try {
      final params = {
        "page": page,
        "search_query": gender?.toEndpointGallery() ?? "",
      };

      final response = await Api().tokenDio.get(
        EndPointConstant.feed,
        queryParameters: params,
      );

      return Right(
        ListRecommendedEmotionsResponseModel.fromJson(response.data),
      );
    } on DioException catch (e) {
      return Left(
        DataException(
          details: (e.response?.data is Map<String, dynamic>)
              ? e.response?.data["detail"].toString()
              : "An unknown error has occurred.",
        ),
      );
    } catch (e) {
      return Left(DataException(details: e.toString()));
    }
  }

  Future<Either<DataException, ListUsersResponseModel>> getLikes({
    required int id,
    int page = 1,
  }) async {
    try {
      final params = {"page": page};

      final response = await Api().tokenDio.get(
        "${EndPointConstant.getLikes}$id/",
        queryParameters: params,
      );

      return Right(ListUsersResponseModel.fromJson(response.data));
    } on DioException catch (e) {
      return Left(
        DataException(
          details: (e.response?.data is Map<String, dynamic>)
              ? e.response?.data["detail"].toString()
              : "An unknown error has occurred.",
        ),
      );
    } catch (e) {
      return Left(DataException(details: e.toString()));
    }
  }

  Future<Either<DataException, ListPostsResponseModel>> getFavorites({
    int page = 1,
  }) async {
    try {
      final params = {"page": page, "search_query": ""};

      final response = await Api().tokenDio.get(
        EndPointConstant.favoritePost,
        queryParameters: params,
      );

      return Right(ListPostsResponseModel.fromJson(response.data));
    } on DioException catch (e) {
      return Left(
        DataException(
          details: (e.response?.data is Map<String, dynamic>)
              ? e.response?.data["detail"].toString()
              : "An unknown error has occurred.",
        ),
      );
    } catch (e) {
      return Left(DataException(details: e.toString()));
    }
  }

  // ========================================================================
  // Audios
  // ========================================================================

  Future<Either<DataException, ListAudiosResponseModel>> getAudios({
    int page = 1,
    String query = "",
  }) async {
    try {
      final params = {"page": page, "search": query};

      final response = await Api().tokenDio.get(
        EndPointConstant.audios,
        queryParameters: params,
      );

      return Right(ListAudiosResponseModel.fromJson(response.data));
    } on DioException catch (e) {
      return Left(
        DataException(
          details: (e.response?.data is Map<String, dynamic>)
              ? e.response?.data["detail"].toString()
              : "An unknown error has occurred.",
        ),
      );
    } catch (e) {
      return Left(DataException(details: e.toString()));
    }
  }
}
