import 'package:dio/dio.dart';
import 'package:dartz/dartz.dart';
import 'package:emote_express/api/api.dart';
import 'package:emote_express/models/calendar/calendar.dart';
import 'package:emote_express/core/constants/end_point_constant.dart';
import 'package:emote_express/models/generic/data_exception_model.dart';

class CalendarProvider {
  Future<Either<DataException, List<CalendarDayModel>>> getCalendar(
      {required DateTime date}) async {
    try {
      final params = {"month": date.month, "year": date.year};
      final response = await Api()
          .tokenDio
          .get(EndPointConstant.calendar, queryParameters: params);

      return Right(
        ((response.data ?? []) as List)
            .map<CalendarDayModel>((e) => CalendarDayModel.fromJson(e))
            .toList(),
      );
    } on DioException catch (e) {
      return Left(DataException(
          details: (e.response?.data is Map<String, dynamic>)
              ? e.response?.data["detail"].toString()
              : "An unknown error has occurred."));
    } catch (e) {
      return Left(DataException(details: e.toString()));
    }
  }

  /// ```
  /// value: 0 -> week
  /// value: 1 -> month
  /// value: 2 -> year
  /// ```
  Future<Either<DataException, CalendarChartResponseModel>> getChart(
      {required int value}) async {
    try {
      final params = {
        "search_time": (value == 0)
            ? "week"
            : (value == 1)
                ? "month"
                : "year"
      };
      final response = await Api()
          .tokenDio
          .get(EndPointConstant.chart, queryParameters: params);

      return Right(CalendarChartResponseModel.fromJson(response.data));
    } on DioException catch (e) {
      return Left(DataException(
          details: (e.response?.data is Map<String, dynamic>)
              ? e.response?.data["detail"].toString()
              : "An unknown error has occurred."));
    } catch (e) {
      return Left(DataException(details: e.toString()));
    }
  }

  Future<Either<DataException, EmotionDescriptionResponseModel>>
      getEmotionDescription({required int id}) async {
    try {
      final params = {"id_emotion": id};
      final response = await Api()
          .tokenDio
          .get(EndPointConstant.emotionDescription, queryParameters: params);

      return Right(EmotionDescriptionResponseModel.fromJson(response.data));
    } on DioException catch (e) {
      return Left(DataException(
          details: (e.response?.data is Map<String, dynamic>)
              ? e.response?.data["detail"].toString()
              : "An unknown error has occurred."));
    } catch (e) {
      return Left(DataException(details: e.toString()));
    }
  }

  // ========================================================================
  // Face & Gallery
  // ========================================================================

  Future<Either<DataException, FaceGalleryResponseModel>>
      getFaceGallery() async {
    try {
      final response = await Api().tokenDio.get(EndPointConstant.faceGallery);

      return Right(FaceGalleryResponseModel.fromJson(response.data));
    } on DioException catch (e) {
      return Left(DataException(
          details: (e.response?.data is Map<String, dynamic>)
              ? e.response?.data["detail"].toString()
              : "An unknown error has occurred."));
    } catch (e) {
      return Left(DataException(details: e.toString()));
    }
  }

  // ========================================================================
  // Image Symbols
  // ========================================================================

  Future<Either<DataException, ImageSymbolListResponseModel>> getImageSymbols(
      {int page = 1, String? query}) async {
    final params = {"page": page, "search_emotion": query};
    try {
      final response = await Api()
          .tokenDio
          .get(EndPointConstant.imageSymbols, queryParameters: params);

      return Right(ImageSymbolListResponseModel.fromJson(response.data));
    } on DioException catch (e) {
      return Left(DataException(
          details: (e.response?.data is Map<String, dynamic>)
              ? e.response?.data["detail"].toString()
              : "An unknown error has occurred."));
    } catch (e) {
      return Left(DataException(details: e.toString()));
    }
  }

  Future<Either<DataException, String>> createImageSymbol(
      {required ImageSymbolRequestModel data}) async {
    try {
      var map = await data.toJson();

      final response = await Api()
          .tokenDio
          .post(EndPointConstant.imageSymbols, data: FormData.fromMap(map));

      return Right(response.data.toString());
    } on DioException catch (e) {
      return Left(DataException(
          details: (e.response?.data is Map<String, dynamic>)
              ? e.response?.data["detail"].toString()
              : "An unknown error has occurred."));
    } catch (e) {
      return Left(DataException(details: e.toString()));
    }
  }
}
