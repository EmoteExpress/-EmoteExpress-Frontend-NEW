import 'package:dio/dio.dart';
import 'package:dartz/dartz.dart';
import 'package:emote_express/api/api.dart';
import 'package:emote_express/models/activity/activity.dart';
import 'package:emote_express/core/constants/end_point_constant.dart';
import 'package:emote_express/models/generic/data_exception_model.dart';

class ActivityProvider {
  Future<Either<DataException, ListThreadsResponseModel>> getThreads({
    int page = 1,
  }) async {
    try {
      final response = await Api().dioFormData.get(
        EndPointConstant.chatbot,
        queryParameters: {"page": page},
      );

      return Right(ListThreadsResponseModel.fromJson(response.data));
    } on DioException catch (e) {
      return Left(
        DataException(
          details: (e.response?.data is Map<String, dynamic>)
              ? e.response?.data["detail"].toString()
              : "An unknown error has occurred.",
        ),
      );
    } catch (e) {
      return Left(DataException(details: e.toString()));
    }
  }

  Future<Either<DataException, ListMessagesResponseModel>> getThreadMessages({
    int page = 1,
    required String idThread,
  }) async {
    try {
      final response = await Api().dioFormData.get(
        "${EndPointConstant.chatbot}$idThread/",
        queryParameters: {"page": page},
      );

      return Right(ListMessagesResponseModel.fromJson(response.data));
    } on DioException catch (e) {
      return Left(
        DataException(
          details: (e.response?.data is Map<String, dynamic>)
              ? e.response?.data["detail"].toString()
              : "An unknown error has occurred.",
        ),
      );
    } catch (e) {
      return Left(DataException(details: e.toString()));
    }
  }

  Future<Either<DataException, SendMessageModel>> sendMessage({
    required String message,
    String? idThread,
  }) async {
    try {
      final data = {"prompt": message};
      final response = await Api().dioFormData.post(
        EndPointConstant.chatbot,
        data: FormData.fromMap(data),
        queryParameters: ((idThread ?? "").isNotEmpty)
            ? {"id_thread": idThread}
            : null,
      );

      return Right(SendMessageModel.fromJson(response.data));
    } on DioException catch (e) {
      return Left(
        DataException(
          details: (e.response?.data is Map<String, dynamic>)
              ? e.response?.data["detail"].toString()
              : "An unknown error has occurred.",
        ),
      );
    } catch (e) {
      return Left(DataException(details: e.toString()));
    }
  }

  Future<Either<DataException, dynamic>> deleteThread(String idThread) async {
    try {
      final response = await Api().dioFormData.delete(
        "${EndPointConstant.chatbot}$idThread/",
      );

      return Right(response.data.toString());
    } on DioException catch (e) {
      return Left(
        DataException(
          details: (e.response?.data is Map<String, dynamic>)
              ? e.response?.data["detail"].toString()
              : "An unknown error has occurred.",
        ),
      );
    } catch (e) {
      return Left(DataException(details: e.toString()));
    }
  }
}
