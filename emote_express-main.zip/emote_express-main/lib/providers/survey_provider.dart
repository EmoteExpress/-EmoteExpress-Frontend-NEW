import 'package:dio/dio.dart';
import 'package:dartz/dartz.dart';
import 'package:emote_express/api/api.dart';
import 'package:emote_express/models/models.dart';
import 'package:emote_express/core/constants/end_point_constant.dart';

class SurveyProvider {
  Future<Either<DataException, String>> setQuiz(
      {required String feeling,
      required String emotion,
      required bool isComfortable}) async {
    try {
      final data = {
        "question_1": feeling,
        "question_2": emotion,
        "question_3": isComfortable
      };
      final response =
          await Api().dioFormData.post(EndPointConstant.quiz, data: data);

      return Right(response.data.toString());
    } on DioException catch (e) {
      return Left(DataException(
          details: (e.response?.data is Map<String, dynamic>)
              ? e.response?.data["detail"].toString()
              : "An unknown error has occurred."));
    } catch (e) {
      return Left(DataException(details: e.toString()));
    }
  }

  Future<Either<DataException, List<FeelingResponseModel>>>
      getFeelingsList() async {
    try {
      final response = await Api().tokenDio.get(EndPointConstant.feelingsList);

      return Right((response.data as List)
          .map((e) => FeelingResponseModel.fromJson(e))
          .toList());
    } on DioException catch (e) {
      return Left(DataException(
          details: (e.response?.data is Map<String, dynamic>)
              ? e.response?.data["detail"].toString()
              : "An unknown error has occurred."));
    } catch (e) {
      return Left(DataException(details: e.toString()));
    }
  }

  Future<Either<DataException, ListEmotionsResponseModel>> getEmotionList(
      {int page = 1, String query = "", bool extend = false}) async {
    try {
      final params = {"page": page, "search_query": query, "extend": extend};
      final response = await Api()
          .tokenDio
          .get(EndPointConstant.emotionsList, queryParameters: params);

      return Right(ListEmotionsResponseModel.fromJson(response.data));
    } on DioException catch (e) {
      return Left(DataException(
          details: (e.response?.data is Map<String, dynamic>)
              ? e.response?.data["detail"].toString()
              : "An unknown error has occurred."));
    } catch (e) {
      return Left(DataException(details: e.toString()));
    }
  }
}
