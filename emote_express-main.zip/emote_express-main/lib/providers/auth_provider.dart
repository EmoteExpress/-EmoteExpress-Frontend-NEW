import 'package:dio/dio.dart';
import 'package:dartz/dartz.dart';
import 'package:emote_express/api/api.dart';
import 'package:emote_express/core/constants/end_point_constant.dart';
import 'package:emote_express/models/generic/data_exception_model.dart';
import 'package:emote_express/models/authentication/authentication.dart';

class AuthProvider {
  // Log In
  Future<Either<DataException, LoginResponseModel>> login(
      {required String email, required String password}) async {
    try {
      final data = {"email": email, "password": password};
      final response = await Api()
          .dioFormData
          .post(EndPointConstant.login, data: FormData.fromMap(data));

      return Right(LoginResponseModel.fromJson(response.data));
    } on DioException catch (e) {
      return Left(DataException(
          details: (e.response?.data is Map<String, dynamic>)
              ? e.response?.data["detail"].toString()
              : "An unknown error has occurred."));
    } catch (e) {
      return Left(DataException(details: e.toString()));
    }
  }

  // Sign In
  Future<Either<DataException, LoginResponseModel>> register(
      {required RegisterRequestModel data}) async {
    try {
      var map = await data.toJson();

      final response = await Api()
          .dioFormData
          .post(EndPointConstant.register, data: FormData.fromMap(map));

      return Right(LoginResponseModel.fromJson(response.data));
    } on DioException catch (e) {
      return Left(DataException(
          details: (e.response?.data is Map<String, dynamic>)
              ? e.response?.data["detail"].toString()
              : "An unknown error has occurred."));
    } catch (e) {
      return Left(DataException(details: e.toString()));
    }
  }

  // Forgot Password
  Future<Either<DataException, String>> forgotPassword(
      {required String email}) async {
    try {
      final data = {"email": email};

      final response = await Api()
          .dioFormData
          .post(EndPointConstant.forgotPassword, data: FormData.fromMap(data));

      return Right(response.data.toString());
    } on DioException catch (e) {
      return Left(DataException(
          details: (e.response?.data is Map<String, dynamic>)
              ? e.response?.data["detail"].toString()
              : "An unknown error has occurred."));
    } catch (e) {
      return Left(DataException(details: e.toString()));
    }
  }

  // Log Out
  Future<Either<DataException, String>> logOut() async {
    try {
      final response = await Api().dioFormData.post(EndPointConstant.logout);

      return Right(response.data.toString());
    } on DioException catch (e) {
      return Left(DataException(
          details: (e.response?.data is Map<String, dynamic>)
              ? e.response?.data["detail"].toString()
              : "An unknown error has occurred."));
    } catch (e) {
      return Left(DataException(details: e.toString()));
    }
  }
}
