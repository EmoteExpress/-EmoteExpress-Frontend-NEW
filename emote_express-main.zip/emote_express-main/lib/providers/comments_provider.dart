import 'package:dio/dio.dart';
import 'package:dartz/dartz.dart';
import 'package:emote_express/api/api.dart';
import 'package:emote_express/models/posts/posts.dart';
import 'package:emote_express/core/constants/end_point_constant.dart';
import 'package:emote_express/models/generic/data_exception_model.dart';

class CommentsProvider {
  Future<Either<DataException, ListCommentsResponseModel>> getComments(
      {required int postId, int page = 1}) async {
    try {
      final response =
          await Api().tokenDio.get("${EndPointConstant.comments}$postId/");

      return Right(ListCommentsResponseModel.fromJson(response.data));
    } on DioException catch (e) {
      return Left(DataException(
          details: (e.response?.data is Map<String, dynamic>)
              ? e.response?.data["detail"].toString()
              : "An unknown error has occurred."));
    } catch (e) {
      return Left(DataException(details: e.toString()));
    }
  }

  Future<Either<DataException, CommentModel>> postComment(
      {required int postId, required String comment}) async {
    final data = {"comment": comment};
    try {
      final response = await Api()
          .dioFormData
          .post("${EndPointConstant.comments}$postId/", data: data);

      return Right(CommentModel.fromJson(response.data));
    } on DioException catch (e) {
      return Left(DataException(
          details: (e.response?.data is Map<String, dynamic>)
              ? e.response?.data["detail"].toString()
              : "An unknown error has occurred."));
    } catch (e) {
      return Left(DataException(details: e.toString()));
    }
  }

  Future<Either<DataException, String>> deleteComment(
      {required int commentId}) async {
    try {
      final response = await Api()
          .dioFormData
          .delete("${EndPointConstant.comments}$commentId/");

      return Right(response.data.toString());
    } on DioException catch (e) {
      return Left(DataException(
          details: (e.response?.data is Map<String, dynamic>)
              ? e.response?.data["detail"].toString()
              : "An unknown error has occurred."));
    } catch (e) {
      return Left(DataException(details: e.toString()));
    }
  }

  Future<Either<DataException, String>> updateComment(
      {required int commentId, required String comment}) async {
    final data = {"comment": comment};
    try {
      final response = await Api()
          .dioFormData
          .put("${EndPointConstant.comments}$commentId/", data: data);

      return Right(response.data.toString());
    } on DioException catch (e) {
      return Left(DataException(
          details: (e.response?.data is Map<String, dynamic>)
              ? e.response?.data["detail"].toString()
              : "An unknown error has occurred."));
    } catch (e) {
      return Left(DataException(details: e.toString()));
    }
  }

  Future<Either<DataException, bool>> likeComment(
      {required int commentId}) async {
    try {
      final response = await Api()
          .dioFormData
          .post("${EndPointConstant.toggleLikeComment}$commentId/");

      return Right(response.data["like"]);
    } on DioException catch (e) {
      return Left(DataException(
          details: (e.response?.data is Map<String, dynamic>)
              ? e.response?.data["detail"].toString()
              : "An unknown error has occurred."));
    } catch (e) {
      return Left(DataException(details: e.toString()));
    }
  }
}
