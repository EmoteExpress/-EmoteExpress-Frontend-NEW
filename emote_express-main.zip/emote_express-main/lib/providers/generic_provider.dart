import 'package:dio/dio.dart';
import 'package:dartz/dartz.dart';
import 'package:emote_express/api/api.dart';
import 'package:emote_express/models/models.dart';
import 'package:emote_express/core/constants/end_point_constant.dart';

class GenericProvider {
  // =========================================================================
  // Home
  // =========================================================================

  Future<Either<DataException, HomeResponseModel>> getHome() async {
    try {
      final response = await Api().tokenDio.get(EndPointConstant.home);

      return Right(HomeResponseModel.fromJson(response.data));
    } on DioException catch (e) {
      return Left(DataException(
          details: (e.response?.data is Map<String, dynamic>)
              ? e.response?.data["detail"].toString()
              : "An unknown error has occurred."));
    } catch (e) {
      return Left(DataException(details: e.toString()));
    }
  }

  Future<Either<DataException, ListSearchEmotionsResponseModel>> searchEmotions(
      {int page = 1, String? query}) async {
    try {
      final params = {"page": page, "search_emotion": query ?? ""};
      final response = await Api()
          .tokenDio
          .get(EndPointConstant.searchEmotion, queryParameters: params);

      return Right(ListSearchEmotionsResponseModel.fromJson(response.data));
    } on DioException catch (e) {
      return Left(DataException(
          details: (e.response?.data is Map<String, dynamic>)
              ? e.response?.data["detail"].toString()
              : "An unknown error has occurred."));
    } catch (e) {
      return Left(DataException(details: e.toString()));
    }
  }

  Future<Either<DataException, ListRecommendedEmotionsResponseModel>>
      getRecommendations({int page = 1}) async {
    try {
      final params = {"page": page};

      final response = await Api().tokenDio.get(
          EndPointConstant.emotionRecommendations,
          queryParameters: params);

      return Right(
          ListRecommendedEmotionsResponseModel.fromJson(response.data));
    } on DioException catch (e) {
      return Left(DataException(
          details: (e.response?.data is Map<String, dynamic>)
              ? e.response?.data["detail"].toString()
              : "An unknown error has occurred."));
    } catch (e) {
      return Left(DataException(details: e.toString()));
    }
  }

  // =========================================================================
  // Menu
  // =========================================================================

  Future<Either<DataException, UserDetailResponseModel>>
      getUserDetails() async {
    try {
      final response = await Api().tokenDio.get(EndPointConstant.detailUser);

      return Right(UserDetailResponseModel.fromJson(response.data));
    } on DioException catch (e) {
      return Left(DataException(
          details: (e.response?.data is Map<String, dynamic>)
              ? e.response?.data["detail"].toString()
              : "An unknown error has occurred."));
    } catch (e) {
      return Left(DataException(details: e.toString()));
    }
  }

  Future<Either<DataException, UserDetailResponseModel>> updateUserDetails(
      {required RegisterRequestModel detail}) async {
    try {
      var formData = await detail.toJsonUpdate();

      final response = await Api()
          .dioFormData
          .patch(EndPointConstant.updateDetailUser, data: formData);

      return Right(UserDetailResponseModel.fromJson(response.data));
    } on DioException catch (e) {
      return Left(DataException(
          details: (e.response?.data is Map<String, dynamic>)
              ? e.response?.data["detail"].toString()
              : "An unknown error has occurred."));
    } catch (e) {
      return Left(DataException(details: e.toString()));
    }
  }

  Future<Either<DataException, String>> updateUserPrivacy() async {
    try {
      final response =
          await Api().dioFormData.post(EndPointConstant.updatePrivacy);

      return Right(response.data.toString());
    } on DioException catch (e) {
      return Left(DataException(
          details: (e.response?.data is Map<String, dynamic>)
              ? e.response?.data["detail"].toString()
              : "An unknown error has occurred."));
    } catch (e) {
      return Left(DataException(details: e.toString()));
    }
  }
}
