package com.dev735.emote_express

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
